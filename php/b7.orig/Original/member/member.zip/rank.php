<?php 
$ranktitle[1] = "Member";
$ranktitle[2] = "Privileged Member";
$ranktitle[10] = "Moderator";
$ranktitle[20] = "Info Team";
$ranktitle[21] = "Info Team | Mod";
$ranktitle[30] = "M7 Team";
$ranktitle[31] = "M7 Team | Mod";
$ranktitle[80] = "Staff Member";
$ranktitle[81] = "Staff | M7";
$ranktitle[90] = "Administrator";
$ranktitle[91] = "Admin | M7";
$ranktitle[98] = "Webmaster";
$ranktitle[99] = "Sensei";
?>