<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

if ( !isset ( $user_info[user_id] ) ) {
header ( "Location: $site_path/login" );
ob_end_flush();
} 

$file_title = "PM Compose";
$send_limit = 5;
$nid = time();
$to = mysql_real_escape_string ( $_GET['to'] );
$reply = mysql_real_escape_string ( $_GET['reply'] );
$pm_sendto = mysql_real_escape_string ( $_POST['pm_sendto'] );

echo "<table width='100%' cellpadding='0' cellspacing='0' class='main'><tr><td><form name='comment_form' method='post'>";


if ( isset ( $reply ) && !empty ( $reply ) ) {
$result_reply = mysql_query ( "SELECT id, subject FROM pm WHERE id='$reply' AND sent_to='$user_info[username]'" );
$pm_reply = mysql_fetch_array ( $result_reply );
}

function DisplayErrors () {
global $errors;
if ( count ( $errors ) == 1 ) {
echo "<b>The following error was found:</b>";
} else {
echo "<b>The following errors were found:</b>";
}
echo "<ul type='square'>";
foreach ( $errors as $var ) {
echo "<li>$var</li>";
}
echo "</ul>";
}

if ( isset ( $_POST[pm_send] ) ) {

$pm_sendto = trim ( mysql_real_escape_string ( htmlspecialchars ( $_POST[pm_sendto], ENT_QUOTES ) ) );
$pm_subject = mysql_real_escape_string ( htmlspecialchars ( $_POST[pm_subject], ENT_QUOTES ) );
$pm_msg = mysql_real_escape_string ( htmlspecialchars ( $_POST[comment_post], ENT_QUOTES ) );

if ( !ereg ( ",", $pm_sendto ) ) {
$pm_array[] = $pm_sendto;
} elseif ( ereg ( ",", $pm_sendto ) ) {
$pm_array = explode ( ",", $pm_sendto );
} elseif ( ereg ( ",", $pm_sendto ) ) {
$pm_array = explode ( ",", $pm_sendto );
}

if ( count ( $pm_array ) > $send_limit ) {
$errors[] = "You cannot send more than <u>$send_limit</u> messages at a time.";
} else {
if ( empty ( $pm_sendto ) ) {
$errors[] = "You must input a recipient.";
} elseif ( empty ( $comment_post ) ) {
$errors[] = "You must input a message.";
} else {
for ( $x = 0; $x <= ( count ( $pm_array ) - 1 ); $x++ ) {
$result = mysql_query( "SELECT username FROM users WHERE username='$pm_array[$x]'" );
if ( mysql_num_rows ( $result ) <= 0 ) {
$pm_success = "false";
$errors[] = "Recipient ".($x+1).": <u>$pm_array[$x]</u> does not exist.<br>";
$x = count ( $pm_array );
} else {
$pm_success = "true";
$pm_array_final[] = "$pm_array[$x]";
}
}
}
}

if ( $pm_success == "true" ) {
for ( $x = 0; $x <= ( count ( $pm_array_final ) - 1 ); $x++ ) {
if ( empty ( $pm_subject ) ) {
$pm_subject = "None:";
}
$insert_pm = mysql_query ( "INSERT INTO pm ( id, sent_by, sent_to, subject, message, status ) VALUES ( '$nid', '$user_info[username]', '$pm_array_final[$x]', '$pm_subject', '$pm_msg', '3' )" );
}
echo "<script>alert( 'PM(s) successfully sent' )</script>";
echo "<script>document.location='$site_path/pm_compose'</script>";
} 

}

if ( $handle = opendir ( "$script_folder/images/smilies" ) ) {
while ( false !== ( $file = readdir ( $handle ) ) ) { 
if ( $file != "." && $file != ".." && ereg ( ".gif", $file ) ) { 
$smile_name = str_replace ( ".gif", "", $file );
$smilies_array[] = $smile_name;
} 
}
closedir( $handle ); 
}
?>

<script>
click_count = 0;

function InsertSmile( expression ) 
{
	document.comment_form.comment_post.value += ' :'+expression+' ';
}

function ClickTracker() 
{
	click_count++;
	if ( click_count == 1 ) 
	{
		document.comment_form.submit();
	} 
	if ( click_count >= 2 ) 
	{
		alert ( "Please do not try to submit the form more than once" );
	return false;
	}
}

function InsertBold()
{
	document.comment_form.comment_post.value += ' [b] [/b] ';
}

function InsertItalic()
{
	document.comment_form.comment_post.value += ' [i] [/i] ';
}

function InsertUnderline()
{
	document.comment_form.comment_post.value += ' [u] [/u] ';
}

function InsertSpoiler()
{
	document.comment_form.comment_post.value += ' [spoiler] [/spoiler] ';
}

function InsertURL()
{
	urllink = prompt ("Enter the url you want to insert.");
	urltext = prompt ("Enter the text you want to have in place of the url");
	document.comment_form.comment_post.value += ' [url='+urllink+']'+urltext+'[/url] ';
}

function InsertColor()
{
	colorlink = prompt ("Enter the color you want to insert.");
	colortext = prompt ("Enter the text you want to have in place of the color");
	document.comment_form.comment_post.value += ' [color='+colorlink+']'+colortext+'[/color] ';
}

function InsertHL()
{
	hllink = prompt ("Enter the highlight you want to insert.");
	hltext = prompt ("Enter the text you want to have in place of the highlight");
	document.comment_form.comment_post.value += ' [hl='+hllink+']'+hltext+'[/hl] ';
}

function ViewAllSmilies() 
{
	window.open("<?php echo "$site_url/$script_folder/smilies.php" ?>","legend","width=170,height=500,left=0,top=0,resizable=yes,scrollbars=yes"); 
}
</script>
<?php
if ( count ( $errors ) > 0 ) {
DisplayErrors();
}
?>
<table width="100%" cellpadding="0" cellspacing="0" class="main">
<tr><td valign="top"><b>Recipient Username(s):</b><br><input type="text" name="pm_sendto" value="<?php 
if ( isset ( $_GET[to] ) ) {
echo $_GET[to];
} elseif ( isset ( $pm_sendto ) ) {
echo $pm_sendto;
}
?>" style="width: 330px" class="form"><br>You may send up to <b><?php echo $send_limit ?></b> message(s) at a time.<br>Seperate each username with a comma.</td></tr>
<tr><td height="5"></td></tr>
<tr><td valign="top"><b>Subject:</b><br><input type="text" name="pm_subject" value="
<?php 
if ( !empty ( $pm_reply[subject] ) ) {
echo "RE: ".stripslashes ( $pm_reply[subject] )."";
} else {
echo $pm_subject; 
}
?>" style="width: 330px" class="form"></td></tr>
<tr><td height="5"></td></tr>
<tr><td>
<center><input type="button" value="Bold" class="form" onclick="InsertBold()"> <input type="button" value="Italic" class="form" onclick="InsertItalic()"> <input type="button" value="Underline" class="form" onclick="InsertUnderline()"> <input type="button" value="Color" class="form" onclick="InsertColor()"> <input type="button" value="Highlight" class="form" onclick="InsertHL()"> <input type="button" value="URL" class="form" onclick="InsertURL()"> <input type="button" value="Spoiler" class="form" onclick="InsertSpoiler()"></center></td></tr>
<tr><td valign="top"><b>Message:</b><br>

<table cellpadding="0" cellspacing="0"><tr><td valign="top">
<textarea name="comment_post" style="width: 330px; height: 185px; overflow: auto" class="form"><?php echo $_POST[comment_post] ?></textarea>
</td>
<td width="10"></td>
<td valign="top">
<fieldset>
<table cellpadding="0" cellspacing="0"><tr><td height="110">
<?php
echo "<table cellpadding='5' cellspacing='0'><tr>";
sort ( $smilies_array );
for ( $x = 1; $x <= 28; $x++ ) {
echo "<td><a href='#insertsmile' onclick='InsertSmile( \"$smilies_array[$x]\" )'><img src='$site_url/$script_folder/images/smilies/$smilies_array[$x].gif' border='0'></a></td>";
if ( !is_float ( $x/4 ) ) {
echo "</tr><tr>";
}
}
echo "</table>";
echo "<table align='center' class='main'><tr><td align='center'><a href='#viewall' onclick='ViewAllSmilies()'>View All</a></td></tr></table>";
?>
</td></tr></table>
</fieldset>
</td></tr></table>
<input type="hidden" name="pm_send">
<p><center><input type="button" value="Send PM" class="form" onclick="ClickTracker()">   <input type="button" value="Back To Inbox" class="form" onclick="document.location='<?php echo "$site_path/pm_inbox" ?>'"></center>

</td></tr>
</table>

</td></tr></form></table>


