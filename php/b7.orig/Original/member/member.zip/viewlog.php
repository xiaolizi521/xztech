<?php

if ( isset ( $user_info['user_id'] ) ) {
	if ( $user_info['type'] >= 3 ) {
	

echo "<p align=\"left\"><B> :: Logs :: </B><BR><BR>
<small>Note that these are log messages - only <b>some</b> are errors<BR>
Messages occuring due to a user that is not logged in show as 'By: - ', otherwise shows Mods/Admin name.</small> </p><BR>";

$query = "SELECT * FROM error_logs ORDER BY id DESC";
$r = mysql_query ($query);
echo "<ul>";
while ($e = mysql_fetch_array ($r)) {
	if($e['type']=="error"){
		echo '<font color="#ff0000">';
	}
	echo "<li><div class=\"mBox\">Log id:<b>" . $e['id'] . "</b>  Occured at: " . $e['date'] . "  ";

	echo "<br>";
	echo $e['type'] .": ". $e['message'] . "<BR>";
	echo "From: ".$e['source'] ." By: ".$e['user'] ."</div></li>";
	if($e['type']=="error"){
		echo '<font color="#ff0000">';
	}
}
echo "</ul>
<BR>";

	}else{ //if user is not logged on
	print "Only moderators and above may access this facility.";
	}

}else{ //if user is not logged on
 print "please log in to use this facility";
}

?>
