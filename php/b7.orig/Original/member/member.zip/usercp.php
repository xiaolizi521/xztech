<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

$file_title = "User Control Panel";

echo "<fieldset><table cellpadding='5' cellspacing='0' class='main' align='center'><tr><td>
<a href='$site_path/usercp&do=editprofile'><b>Edit Profile</b></a> |
<a href='$site_path/usercp&do=editoptions'><b>Edit Options</b></a> | 
<a href='$site_path/usercp&do=editavatar'><b>Edit Avatar</b></a> | 
<a href='$site_path/usercp&do=editpassword'><b>Edit Password</b></a>
</td></tr></table></fieldset><table height='7' cellpadding='0' cellspacing='0'><tr><td></td></tr></table>";

include ( "$script_folder/profile.php" );
?>
