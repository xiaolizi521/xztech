<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

if ( ereg ( "/register.php", "$_SERVER[SCRIPT_NAME]" ) ) {
echo "<script>document.location.href='$site_url/$main_filename?page=register'</script>";
}

$file_title = "Registration";
$register_form = "true";

echo "<table width='100%' cellpadding='0' cellspacing='0' class='main'><tr><td><form method='post'>";

if ( !isset ( $user_info[user_id] ) ) {
if ( isset ( $_POST[submit] ) ) {
$username = stripslashes( $_POST[username] ); 
$password = stripslashes( $_POST[password] ); 
$re_password = stripslashes( $_POST[re_password] ); 
$email_address = stripslashes( $_POST[email_address] ); 
$re_email_address = stripslashes( $_POST[re_email_address] ); 
$verification = stripslashes( $_POST[verification] );
$email_msg = "Welcome $username,\n\nThank you for taking your time to register at $sitetitle. You are now officially a member and we are glad to have you as one. Your username and password are as follows:\n\nUsername: $username\nPassword: $password\n\nOnce again, thank you for joining $sitetitle and we hope that you'll enjoy your stay.\n\n$sitetitle\n$site_url";

if ( strlen ( $username ) < 3 || strlen ( $username ) > 20 ) {
$errors[] = "Username must be between 3 to 20 characters long";
}
if ( !eregi ( "^[a-z0-9\-_\.]+$", $username ) ) {
$errors[] = "Username must be alphanumeric";
}
if ( strlen ( $password ) < 3 || strlen ( $password ) > 20 ) {
$errors[] = "Password must be between 3 to 20 characters long";
}
if ( !eregi ( "^[a-z0-9\-_\.]+$", $password ) ) {
$errors[] = "Password must be alphanumeric";
}
if ( $password != $re_password ) {
$errors[] = "The passwords don't match";
}
if ( empty ( $email_address ) ) {
$errors[] = "You cannot leave the Email Address field empty";
} 
if ( $email_address != $re_email_address ) {
$errors[] = "The email addresses don't match";
}
if ( !eregi('^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$', $email_address ) ) {
$errors[] = "You must enter a valid email address";
}

if ( count ( $errors ) > 0 ) {
if ( count ( $errors ) == 1 ) {
echo "<b>The following error was found:</b>";
} else {
echo "<b>The following errors were found:</b>";
}
echo "<ul type='square'>";
foreach ( $errors as $var ) {
echo "<li>$var</li>";
}
echo "</ul>";
} else {

$result_email_check = mysql_query( "SELECT email_address FROM users WHERE email_address='$email_address'" ); 
$result_username_check = mysql_query( "SELECT username FROM users WHERE username='$username'" ); 

$email_check = mysql_num_rows( $result_email_check ); 
$username_check = mysql_num_rows( $result_username_check ); 

if ( $email_check > 0 ) { 
$errors[] = "That email address has already been registered with by another user";
}
if ( $username_check > 0 ) { 
$errors[] = "That username has already been registered with by another user";
}

if ( count ( $errors ) > 0 ) {
if ( count ( $errors ) == 1 ) {
echo "<b>The following error was found:</b>";
} else {
echo "<b>The following errors were found:</b>";
}
echo "<ul type='square'>";
foreach ( $errors as $var ) {
echo "<li>$var</li>";
}
echo "</ul>";
} else {
mail ( "$email_address", "Welcome To $sitetitle!", "$email_msg", "From: $sitetitle <$contact_email>" );
$password = md5 ( $password );
$insert_users = mysql_query( "INSERT INTO users ( username, password, email_address, type, registered_on, timezone, dst, ip_address, category ) VALUES ( '$username', '$password', '$email_address', '1', $timenow, '$timezone', '$dst', '$_SERVER[REMOTE_ADDR]', '0' )" );

echo "<center><b>You have been successfully registered!</b>";
echo "<table height='10'><tr><td></td></tr></table>";
echo "<a href='$site_url/$main_filename'>Click here to continue</a></center>";
$register_form = "false";
}

}

}

} else {
$register_form = "false";
echo "<center><b>You are already registered</b>";
echo "<table height='10'><tr><td></td></tr></table>";
echo "<a href='$site_url/$main_filename'>Click here to continue</a></center>";
}

if ( $register_form == "true" ) {
echo $verify_new_string;
?><fieldset>
<legend class="main">Username</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr><td>
<b>*Username:<br><input type="text" name="username" maxlength="30" value="<?php echo $_POST[username] ?>" style="width: 300px" class="form">
</td></tr></table>
</fieldset>


<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend class="main">Password</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr>
<td><b>*Password:<br><input type="password" name="password" maxlength="20" style="width: 200px" class="form"></td>
<td width="5"></td>
<td><b>*Confirm Password:<br><input type="password" name="re_password" maxlength="20" style="width: 200px" class="form"></td>
</tr></table>
</fieldset>

<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend class="main">Email Address</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr>
<td><b>*Email Address:<br><input type="text" name="email_address" value="<?php echo $_POST[re_email_address] ?>" style="width: 200px" class="form"></td>
<td width="5"></td>
<td><b>*Confirm Email Address:<br><input type="text" name="re_email_address" value="<?php echo $_POST[re_email_address] ?>" style="width: 200px" class="form"></td>
</tr></table>
</fieldset>

<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend class="main">Timezone</legend>
<table cellpadding="0" cellspacing="0" class="main">
<tr><td class="main"><b>Timezone:<br>
<select name="timezone" class="form">
<option value="-12">(GMT -12:00) Eniwetok, Kwajalein</option>
<option value="-11">(GMT -11:00) Midway Island, Samoa</option>
<option value="-10">(GMT -10:00) Hawaii</option>
<option value="-9">(GMT -9:00) Alaska</option>
<option value="-8">(GMT -8:00) Pacific Time (US &amp; Canada)</option>
<option value="-7">(GMT -7:00) Mountain Time (US &amp; Canada)</option>
<option value="-6">(GMT -6:00) Central Time (US &amp; Canada), Mexico City</option>
<option value="-5" selected>(GMT -5:00) Eastern Time (US &amp; Canada), Bogota, Lima</option>
<option value="-4">(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz</option>
<option value="-3.5">(GMT -3:30) Newfoundland</option>
<option value="-3">(GMT -3:00) Brazil, Buenos Aires, Georgetown</option>
<option value="-2">(GMT -2:00) Mid-Atlantic</option>
<option value="-1">(GMT -1:00 hour) Azores, Cape Verde Islands</option>
<option value="0">(GMT) Western Europe Time, London, Lisbon, Casablanca</option>
<option value="1">(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris</option>
<option value="2">(GMT +2:00) Kaliningrad, South Africa</option>
<option value="3">(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg</option>
<option value="3.5">(GMT +3:30) Tehran</option>
<option value="4">(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi</option>
<option value="4.5">(GMT +4:30) Kabul</option>
<option value="5">(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent</option>
<option value="5.5">(GMT +5:30) Bombay, Calcutta, Madras, New Delhi</option>
<option value="6">(GMT +6:00) Almaty, Dhaka, Colombo</option>
<option value="7">(GMT +7:00) Bangkok, Hanoi, Jakarta</option>
<option value="8">(GMT +8:00) Beijing, Perth, Singapore, Hong Kong</option>
<option value="9">(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option>
<option value="9.5">(GMT +9:30) Adelaide, Darwin</option>
<option value="10">(GMT +10:00) Eastern Australia, Guam, Vladivostok</option>
<option value="11">(GMT +11:00) Magadan, Solomon Islands, New Caledonia</option>
<option value="12">(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka</option>
</select>
</td></tr>
<tr><td height="10"></td></tr>
<tr><td><b>DST Options:<br>
<select name="dst" class="form">
<option value="1" <?php if ( $user_info[dst] == "1" ) { echo "selected"; } ?>>Turn Daylight Savings Time On</option>
<option value="0" <?php if ( $user_info[dst] == "0" ) { echo "selected"; } ?>>Turn Daylight Savings Time Off</option>
</select>
</td></tr>
</table>
</fieldset>


<?php
/*
?>

<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend>Image Verification</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr>
<?php
for ( $p = 0; $p <= 5; $p++ ) {
echo "<td><img src='script/verification.php?code=$v&p=$p'></td>";
echo "<td width='5'></td>";
}
?>
<td><input type="text" name="verification" size="16" maxlength="6" class="form"></td>
</tr></table>
</fieldset>


<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend>Gender</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr><td>
<select name="gender" class="form">
<option selected value="n">Not Telling</option>
<option value="m">Male</option>
<option value="f">Female</option>
</select>
</td></tr></table>
</fieldset>

<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend>Birthday</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr>
<td>Month:<br><select name="bday_month" class="form">
<option>-</option>
<?php
$bday_month_array = array ( "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" );
foreach ( $bday_month_array as $var ) {
echo "<option value='$var'>$var</option>";
}
?>
</select></td>
<td width="5"></td>
<td>Day:<br><select name="bday_day" class="form">
<option>-</option>
<?php
for ( $x = 1; $x <= 12; $x++ ) {
echo "<option value='$x'>$x</option>";
}
?>
</select></td>
<td width="5"></td>
<td>Year:<br><input type="text" name="bday_year" size="10" maxlength="4" class="form"></td>
</tr></table>
</fieldset>

<table height="10"><tr><td></td></tr></table>

<fieldset>
<legend>Location</legend>
<table cellpadding="0" cellspacing="0" class="main"><tr><td>
<select name="location" class="form">
<option value="0">Choose A Country</option>
<option value="United States">United States</option>
<option value="Canada">Canada</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="American Samoa">American Samoa</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antigua">Antigua</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Barbuda">Barbuda</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bonaire">Bonaire</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="Virgin islands">British Virgin Islands</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Channel Islands">Channel Islands</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Colombia">Colombia</option>
<option value="Congo">Congo</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Croatia">Croatia</option>
<option value="Curacao">Curacao</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Faeroe Islands">Faeroe Islands</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="French Polynesia">French Polynesia</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Gemany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Great Britain">Great Britain</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guadeloupe">Guadeloupe</option>
<option value="Guam">Guam</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guinea Bissau">Guinea Bissau</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Irak">Irak</option>
<option value="Iran">Iran</option>
<option value="Ireland">Ireland</option>
<option value="Northern Ireland">Ireland, Northern</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Ivory Coast">Ivory Coast</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Liberia">Liberia</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macau">Macau</option>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall isl">Marshall Islands</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia">Micronesia</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montserrat">Montserrat</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar">Myanmar/Burma</option>
<option value="Namibia">Namibia</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="Netherlands Antilles">Netherlands Antilles</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Reunion">Reunion</option>
<option value="Rwanda">Rwanda</option>
<option value="Saba">Saba</option>
<option value="Saipan">Saipan</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Scotland">Scotland</option>
<option value="Senegal">Senegal</option>
<option value="Seychelles>Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovac Republic">Slovak Republic</option>
<option value="Slovenia">Slovenia</option>
<option value="South Africa">South Africa</option>
<option value="South Korea">South Korea</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Taiwan">Taiwan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Togo">Togo</option>
<option value="Trinidad-Tobago">Trinidad-Tobago</option>
<option value="Tunesia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="U.S. Virgin Islands">U.S. Virgin Islands</option>
<option value="Uganda">Uganda</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Urugay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Vatican City">Vatican City</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Wales">Wales</option>
<option value="Yemen">Yemen</option>
<option value="Zaire">Zaire</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>
</select> 
</td></tr></table>
</fieldset>
<?php
*/
?>

<center><p><input type="submit" name="submit" value="Register" class="form">   <input type="button" value="Reset Fields" class="form"></center>
<?php
} else {
echo "";
}
?>

</td></tr></form></table>


