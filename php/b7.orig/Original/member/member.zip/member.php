<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

$id = mysql_real_escape_string ( $_GET['id'] );

if ( isset ( $id ) ) {
$result = mysql_query ( "SELECT * FROM users WHERE username='$id'" );
$member = mysql_fetch_array ( $result );
}

$file_title = "Member Profile:split:$member[username]";

function DisplayInfo( $header, $content ) {
global $sitetitle, $member;

echo "<tr><td><b>$header</b></td><td width='3'></td><td>";

if ( empty ( $member[$content] ) ) {
echo "Not Available";
} else {

switch ( $content ) {
case "registered_on":
echo DisplayDate( "$member[registered_on]", "d M y, h:i A", "1"  );
break;

case "last_activity_time":
echo DisplayDate( "$member[last_activity_time]", "d M y, h:i A", "1" );
break;

case "timezone":
if ( $member[dst] == 1 ) {
$timezone = ($member[timezone]+date("I"));
} elseif ( $member[dst] == 0 ) {
$timezone = $member[timezone];
}
$zone = 3600*$timezone;
echo gmdate ( 'h:i A', time() + $zone );
break;

case "last_activity_url":
if ( ( time() - $member[last_activity_time] ) <= 300 ) {
echo "<font color='green'>Online</font>";
} else {
echo "<font color='red'>Offline</font>";
}
break;

case "email_address":
echo "<a href='mailto: $member[email_address]'>Send an Email</a>";
break;

case "website":
if ( ereg ( "www.|http://.", $member['website'] ) ) {
echo "<a href='$member[website]' target='_blank'>Visit</a>";
} else {
echo "<a href='http://$member[website] target='_blank'>Visit</a>";
}
break;

case "aim":
$user_aim = str_replace ( " ", "+", $member[aim] );
$aim_site_name = str_replace ( " ", "+", $sitetitle );
echo "<a href='aim:goim?screenname=$user_aim&message=Hi!+I+saw+you+from+$aim_site_name'>$member[aim]</a>";
break;

case "gender":
if ( $member[gender] == "m" ) {
echo "Male";
} elseif ( $member[gender] == "f" ) {
echo "Female";
} else {
echo "Not Telling";
}
break;

case "bday_month":
if ( ( $member[bday_month] == "-" && $member[bday_day] == "-" ) || ( $member[bday_month] != "-" && $member[bday_day] == "-" ) ) {
echo "Not Available";
} elseif ( $member[bday_month] == "-" && $member[bday_day] != "-" ) {
echo $member[bday_month];
} else {
echo "$member[bday_month] $member[bday_day]";
}
if ( !empty ( $member[bday_year] ) ) {
echo ", $member[bday_year]";
}
break;

default:
echo "$member[$content]";
} 
echo "</td></tr>";
}

}

if ( isset ( $id ) && !empty ( $id ) && mysql_num_rows ( $result ) > 0 && ( eregi ( "^[a-z0-9\-_\.]+$", $id ) ) ) {
echo "<center><b>Viewing Profile: $member[username]</b><p>";
//check if the user is banned or not.
//if the function returns true (if a row is sent back) show the pwned picture
if (isbanned($show_comments['user_id'] )) {
$member_avatar = "<img src='member/images/avatars/pwnd.jpg' width='60' height='60'>";

	} else {
if ( empty ( $member[avatar] ) ) {
echo "<img src='$site_url/$script_folder/images/avatars/none.gif' width='60' height='60'>";
} else {
list ( $avatar_width, $avatar_height ) = getimagesize ( "$member[avatar]" );
if ( $avatar_width > 60 || $avatar_height > 60 ) {
echo "<img src='$member[avatar]' width='60' height='60'>";
} else {
echo "<img src='$member[avatar]'>";
}
}//show banned avatar end
}
echo "<p></center>";
?>
<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="49%">

<fieldset>
<legend class="main">Statistics</legend>
<table cellpadding="0" cellspacing="5" class="main" align="center">
<?php 
DisplayInfo( $header="Joined", $content="registered_on" ); 
DisplayInfo( $header="Referrals", $content="referrals" );
DisplayInfo( $header="Posts", $content="posts" ); 
DisplayInfo( $header="Last Active", $content="last_activity_time" ); 
DisplayInfo( $header="Status", $content="last_activity_url" );

?>
</table>
</fieldset>

</td>
<td width="5"></td>
<td width="49%">

<fieldset>
<legend class="main">Contact Information</legend>
<table cellpadding="0" cellspacing="5" class="main" align="center">
<?php 
DisplayInfo( $header="Email", $content="email_address" ); 
DisplayInfo( $header="Website", $content="website" ); 
DisplayInfo( $header="MSN", $content="msn" ); 
DisplayInfo( $header="AIM", $content="aim" ); 
echo "<tr><td><b>PM</b></td><td width='3'></td><td><a href='$site_path/pm_compose&to=$member[username]'>Send PM</a><td></tr>";
?>
</table>
</fieldset>

</td>
</tr></table>


<table height="7"><tr><td></td></tr></table>


<table width="100%" cellpadding="0" cellspacing="0"><tr>
<td width="49%">

<fieldset>
<legend class="main">Personal Information</legend>
<table cellpadding="0" cellspacing="5" class="main" align="center">
<?php 
DisplayInfo( $header="Gender", $content="gender" ); 
DisplayInfo( $header="Birthday", $content="bday_month" ); 
DisplayInfo( $header="Location", $content="location" );
DisplayInfo( $header="User's Time", $content="timezone" );
?>
</table>
</fieldset>

</td>
<td width="5"></td>
<td width="49%" valign="top">

<fieldset>
<legend class="main">Additional Information</legend>
<table height="55" cellpadding="0" cellspacing="5" class="main" align="center">
<?php 
if ( empty ( $member[biography] ) ) {
echo "<tr><td style='text-align: justify'>$member[username] has not written anything about ";
if ( $member[gender] == "m" ) {
echo "himself";
} elseif ( $member[gender] == "f" ) {
echo "herself";
} else {
echo "himself/herself";
}
echo ".</td></tr>";
} else {
echo "<tr><td style='text-align: justify'>$member[biography]<td></tr>";
}
?>
</table>
</fieldset>

</td>
</tr></table>
<?php
} else {
echo "<center>There are no users in our database with that username</center>";
}
?>
