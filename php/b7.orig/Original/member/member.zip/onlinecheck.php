<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

include ( "db.php" );
include ( "settings.php" );

$site_path = "$site_url/$main_filename?$ident=$script_folder";
$timeout = 600;
$timenow = time();

$result_membercount = mysql_query ( "SELECT 'user_id' FROM users" );
$result_onlinecheck_users = mysql_query ( "SELECT * FROM users WHERE $timenow - last_activity_time <= $timeout" );
$result_onlinecheck_guests = mysql_query ( "SELECT * FROM guests WHERE $timenow - last_activity_time <= $timeout" );

$onlinecheck_admins = 0;
$onlinecheck_members = 0;
$onlinecheck_guests = 0;

while ( $onlinecheck1 = mysql_fetch_array ( $result_onlinecheck_users ) ) {
if ( $onlinecheck1['type'] == "90" || $onlinecheck1['type'] == "91" ||  $onlinecheck1['type'] == "98" ||  $onlinecheck1['type'] == "90" ) {
$onlinecheck_admins++;
} 
if ( $onlinecheck1['type'] == "1" || $onlinecheck1['type'] == "2" ||  $onlinecheck1['type'] == "10" ||  $onlinecheck1['type'] == "11" 
||  $onlinecheck1['type'] == "20" ||  $onlinecheck1['type'] == "21" ||  $onlinecheck1['type'] == "30" ||  $onlinecheck1['type'] == "31" 
||   $onlinecheck1['type'] == "80" ||  $onlinecheck1['type'] == "81" ) {
$onlinecheck_members++;
} 
}

while ( $onlinecheck2 = mysql_fetch_array ( $result_onlinecheck_guests ) ) {
$onlinecheck_guests++;
}

while ( $onlinecheck3 = mysql_fetch_array ( $result_membercount ) ) {
$onlinecheck_mem++;
}

$onlinecheck_total = ( $onlinecheck_admins + $onlinecheck_members + $onlinecheck_guests );

$onlinelist = "<b>&nbsp;&nbsp;&nbsp;Members Statistics</b><br />
&nbsp;&nbsp;&nbsp;- Admins Online: <a href=\"?page=member/online\"><b>$onlinecheck_admins</b></a><br />
&nbsp;&nbsp;&nbsp;- Members Online: <a href=\"?page=member/online\"><b>$onlinecheck_members</b></a><br />
&nbsp;&nbsp;&nbsp;- Guests Online: <a href=\"?page=member/online\"><b>$onlinecheck_guests</b></a><br />
&nbsp;&nbsp;&nbsp;- Total Users Online: <a href=\"?page=member/online\"><b>$onlinecheck_total</b></a><br />
&nbsp;&nbsp;&nbsp;- Total Members: <a href=\"?page=member/memberlist\"><b>$onlinecheck_mem</b></a><br />";

( $fp = fopen ( "onlinelist.php", "w" ) ) or die ( "couldn't open" );
fwrite ( $fp, "$onlinelist" );
fclose ( $fp );
?>
