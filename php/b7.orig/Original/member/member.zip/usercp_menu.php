<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

if ( isset ( $user_info['user_id'] ) ) {
$result_pm_count_cp = mysql_query ( "SELECT sent_to FROM pm WHERE sent_to='$user_info[username]'" );
$pm_count_cp = mysql_num_rows ( $result_pm_count_cp );
if ( !ereg ( "/pm_", $GLOBALS['QUERY_STRING'] ) ) {
$result_pm_status = mysql_query ( "SELECT * FROM pm WHERE sent_to='$user_info[username]' AND status='3'" );
$pm_count_status = mysql_num_rows ( $result_pm_status );
while ( $pm_status = mysql_fetch_array ( $result_pm_status ) ) {
if ( $pm_count_status > 0 ) {
$pm_status_date = DisplayDate( "$pm_status[id]", "M d Y, h:i A", "0" );
echo "<script>alert('You have recieved a new PM from $pm_status[sent_by] on $pm_status_date')</script>";
$update_pm_status_recieved = mysql_query ( "UPDATE pm SET status='2' WHERE id='$pm_status[id]' AND status='3'" );
}
}
}

echo "&nbsp;&nbsp;&nbsp;Welcome <b>$user_info[username]</b>!<br />";
if ( $user_info['type'] == 20 || $user_info['type'] == 21 || $user_info['type'] == 30 || $user_info['type'] == 31 || 
	$user_info['type'] == 80 || $user_info['type'] == 81 || $user_info['type'] == 90 || $user_info['type'] == 91 || 
	$user_info['type'] == 98 || $user_info['type'] == 99 ) {
echo "&nbsp;&nbsp;&nbsp;- <a href=\"$site_url/$script_folder/admin/index.php\" target=\"_blank\">Admin Control Panel</a><br />";
}
if ( $user_info['type'] == 10 || $user_info['type'] == 21 || $user_info['type'] == 31 || $user_info['type'] == 80 || 
	$user_info['type'] == 81 || $user_info['type'] == 90 || $user_info['type'] == 91 || $user_info['type'] == 98 || 
	$user_info['type'] == 99 ) {
	echo "&nbsp;&nbsp;&nbsp;- <a href=\"?page=member/bancomments\">Ban/Unban</a><br />";
	echo "&nbsp;&nbsp;&nbsp;- <a href=\"?page=member/viewlog\">View Log</a><br />";
}
echo "&nbsp;&nbsp;&nbsp;- <a href=\"?page=member/usercp&amp;do=editprofile\">Edit Profile</a><br />";
echo "&nbsp;&nbsp;&nbsp;- <a href=\"?page=member/pm_inbox\">PM Inbox ($pm_count_cp)</a><br />";
echo "&nbsp;&nbsp;&nbsp;- <a href=\"?page=member/logout\">Logout</a>";
} else {
include ( "$script_folder/login_form2.php" );
}
?>