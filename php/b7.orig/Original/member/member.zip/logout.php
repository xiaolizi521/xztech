<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

$file_title = "Logout";

function Logout() {
global $site_url, $main_filename;
echo "<center><b>Successfully Logged Out!</b>";
echo "<table height='10'><tr><td></td></tr></table>";
if ( !isset ( $GLOBALS[HTTP_REFERER] ) || !ereg( "login", "$_SERVER[SCRIPT_NAME]" ) || !ereg( "logout", "$_SERVER[SCRIPT_NAME]" ) ) {
echo "<a href='$GLOBALS[HTTP_REFERER]'>Click here go back to where you came from</a><br>";
}
echo "<a href='$site_url/$main_filename'>Click here to go back to the frontpage</a></center>";
}

if ( isset ( $user_info[user_id] ) ) {
Logout();
setcookie( "user_id", "", time()-60*60*24*30, "/", "$_SERVER[HTTP_HOST]", 0 );
setcookie( "password", "", time()-60*60*24*30, "/", "$_SERVER[HTTP_HOST]", 0 );
ob_end_flush();
} else {
include ( "member/login_form.php" );
ob_end_flush();
}
?>