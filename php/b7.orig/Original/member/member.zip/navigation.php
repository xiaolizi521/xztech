							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Main Navigation</span><b>]</b><br />
							&nbsp;&nbsp; &#187; <a href="<?php echo $site_url; ?>"  class="OnWhite">FrontPage</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=contact" class="OnWhite">Contact Us</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleachforums.com" class="OnWhite" target="_blank">BleachForums.com</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=linkus" class="OnWhite">Link To Bleach7.com</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=supportus" class="OnWhite">Support Bleach7.com</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=rotation" class="OnWhite">Banner Rotation</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.lik-sang.com/" class="OnWhite" target="_blank">Lik-Sang</a><br />
							<br />
							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Bleach Information</span><b>]</b><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/authorkubotite" class="OnWhite2">Author: Kubo Tite</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bios/main" class="OnWhite2">Biographies</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bleachanimeguide" class="OnWhite2">Bleach Anime Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bleachcaptainsguide" class="OnWhite2">Bleach Zanpaktou Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/encyclopedia" class="OnWhite2">Bleach Encyclopedia</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/summaries/anime" class="OnWhite2">Bleach Episode Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/factoids" class="OnWhite2">Bleach Factoids</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bleachgameguide" class="OnWhite2">Bleach Game Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bleachitemguide" class="OnWhite2">Bleach Item Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/locations" class="OnWhite2">Bleach Locations</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bleachmangaguide" class="OnWhite2">Bleach Manga Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/bleachspellguide" class="OnWhite2">Bleach Spell Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/weapons" class="OnWhite2">Bleach Weapon Guide</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/miscellaneous" class="OnWhite2">Miscellaneous</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=information/tvtokyo" class="OnWhite2">TV Tokyo Information</a><br />
							<br />
							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Bleach Multimedia</span><b>]</b><br />
							&nbsp;&nbsp; &#187; <a href="?page=media/torrents/ripper" class="OnBlack">Bleach BitTorrent</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=" class="OnBlack">Bleach Image Gallery</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=media/raw" class="OnBlack">Bleach RAW Manga</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=media/manga" class="OnBlack">Bleach Manga Downloads</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=media/music" class="OnBlack">Bleach Music Downloads</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=media/wallpapers" class="OnBlack">Bleach Wallpapers</a><br />
							<br />
							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Fan Interaction</span><b>]</b><br />
							&nbsp;&nbsp; &#171; <a href="irc://bleach7@irc.irchighway.net/" class="OnWhite">Bleach7 IRC Room</a><br />
							&nbsp;&nbsp; &#171; <a href="http://bleach7.com/cgi-bin/gtchat/chat.pl" class="OnWhite">Chat Room</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=fan/fanart" class="OnBlack2a">Fan Art</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=fan/fanfiction" class="OnBlack2a">Fan Fictions</a><br />
							&nbsp;&nbsp; &#171; <a href="?page=stb" class="OnWhite">Spread the Bleach!</a><br />
							<br />
							&nbsp; <b>[</b><span style="text-decoration: underline">Help Section</span><b>]</b><br />
							&nbsp;&nbsp; &#187; <a href="?page=about" class="OnWhite2">About Bleach7.com</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=faq/faqcentral" class="OnWhite2">FAQ Central</a> <br />
							&nbsp;&nbsp; &#187; <a href="?page=editorials/index" class="OnWhite2">From Our Staff</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=legaldisclaimer" class="OnWhite">Legal Disclaimer</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=privacypolicy" class="OnBlack">Privacy Policy</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=statistics" class="OnBlack">Statistics</a><br />
							&nbsp;&nbsp; &#187; <a href="?page=termsofuse" class="OnWhite2">Terms of Use</a><br />
							<br />
							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Good Buddies</span><b>]</b><br />
							&nbsp;&nbsp; &#171; <a href="http://www.anime-divx.com/" class="OnWhite3" target="_blank">Anime-Divx</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.animestocks.com/" class="OnWhite3" target="_blank">Anime Stocks</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.combovideos.com/" class="OnWhite3" target="_blank">Combo Videos</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.cosmocanyon.com/" class="OnWhite3 target="_blank"">Cosmo Canyon</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.maximum7.com/" class="OnWhite3" target="_blank">Maximum7</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.moonbeanmanga.net" class="OnWhite3" target="_blank">Moonbean Manga</a><br />
       						&nbsp;&nbsp; &#171; <a href="http://www.naruto-bunshin.com" class="OnWhite3" target="_blank">Naruto Bunshin</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.narutocentral.com/" class="OnWhite3" target="_blank">Naruto Central</a><br />
							&nbsp;&nbsp; &#171; <a href="http://www.national-anime.net/" class="OnWhite3" target="_blank">National Anime</a><br />
							&nbsp;&nbsp; &#171; <i><a href="?page=goodbuddies">COMPLETE LIST</a></i><br />
							<br />
							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Bleach Fansites</span><b>]</b><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleach8.com" class="OnWhite4" target="_blank">Bleach8 (Chinese)</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleachcommunity.net" class="OnWhite4" target="_blank">Bleach Community</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleachdj.com" class="OnWhite4" target="_blank">Bleach DJ</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.code-master.net/bleach/" class="OnWhite4" target="_blank">Bleach Info</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleachlegacy.com" class="OnWhite4" target="_blank">Bleach Legacy</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleachportal.net" class="OnWhite4" target="_blank">Bleach Portal</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleach-society.com/" class="OnWhite4" target="_blank">Bleach Society</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.bleachtv.com/" class="OnWhite4" target="_blank">Bleach TV</a><br />
							&nbsp;&nbsp; &#187; <a href="http://bleachx.com/" class="OnWhite4" target="_blank">Bleach X</a><br />
							&nbsp;&nbsp; &#187; <a href="http://bleach.animewtf.com" class="OnWhite4" target="_blank">Bleach WTF</a><br />
							&nbsp;&nbsp; &#187; <a href="http://shinigamicentral.savefile.com/" class="OnWhite4" target="_blank">Shinigami Central</a><br />
							&nbsp;&nbsp; &#187; <a href="http://www.livejournal.com/community/soul_society/" class="OnWhite4" target="_blank">Soul_Society (LJournal)</a><br />
							&nbsp;&nbsp; &#187; <i><a href="?page=fansitelist">COMPLETE LIST</a></i><br />
							<br />
							&nbsp;&nbsp;<b>[</b><span style="text-decoration: underline">Members Area</span><b>]</b><br />