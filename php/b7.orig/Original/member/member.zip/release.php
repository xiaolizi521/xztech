				<div class="release">
				<table id="AutoNumber3">
					<tr>
						<td class="latrelspace1">&nbsp;</td>
						<td class="latrelmain">
							&nbsp; RAW: <a href="?page=">Bleach Episode #<?php echo "$anime_raw"; ?></a><br />
							&nbsp; SUB: &nbsp;<a href="?page=">Bleach Episode #<?php echo "$anime_sub"; ?></a><br />
							&nbsp;&nbsp;&nbsp; - - - - - - - - - - - - - - - <br />
							&nbsp; RAW: <a href="?page=media/rawlatest">Bleach Chapter #<?php echo "$manga_raw"; ?></a><br />
							&nbsp; SUB: &nbsp;<a href="?page=media/mangalatest">Bleach Chapter #<?php echo "$manga_sub"; ?></a></td>
						<td class="latrelspace2">&nbsp;</td>
					</tr>
				</table>
				</div>