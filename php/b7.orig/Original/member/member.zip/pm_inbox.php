<?php
####################################################################
# AR Memberscript 				                                   #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
# Copyright Anime Reporter. All Rights Reserved.                   # 
# THIS IS A PAID SCRIPT AND MAY NOT BE REDISTRIBUTED TO OTHERS.    #
####################################################################

if ( !isset ( $user_info[user_id] ) ) {
header ( "Location: $site_path/login" );
ob_end_flush();
} 

$x = 1;

if ( $user_info[type] == 1 || $user_info[type] == 2 ) {
$limit = 50;
} elseif ( $user_info[type] == 10 ) {
$limit = 100;
} elseif ( $user_info[type] == 20 || $user_info[type] == 21 || $user_info[type] == 30 || $user_info[type] == 31 
	|| $user_info[type] == 80 || $user_info[type] == 81 ) {
$limit = 150;
} elseif ( $user_info[type] >= 90 ) {
$limit = 200;
} 

echo "<table width='100%' cellpadding='0' cellspacing='0' class='main'><tr><td><form name='pm_form' method='post'>";
if ( !isset ( $id ) && empty ( $id ) ) {
$file_title = "PM Inbox";
$result = mysql_query( "SELECT * FROM pm WHERE sent_to='$user_info[username]' ORDER BY id DESC" );
$result_countunread = mysql_query( "SELECT status FROM pm WHERE sent_to='$user_info[username]' AND NOT (status='1') ORDER BY id DESC" );

if ( mysql_num_rows ( $result ) > 0 ) {

if ( mysql_num_rows ( $result ) > $limit ) {
$delete_pm_select = mysql_query( "SELECT * FROM pm WHERE sent_to='$user_info[username]' ORDER BY id ASC" );
$delete = mysql_fetch_array( $delete_pm_select );
$delete_pm = mysql_query ( "DELETE FROM pm WHERE id='$delete[id]' AND sent_to='$user_info[username]'" );
echo "<script>alert( 'You have exceeded the limit of $limit messages. The oldest 
message will be deleted' )</script>";
echo "<script>document.location.href='$site_path/pm_inbox'</script>";
}
?>
<script type="text/javascript">
function CheckAll(checkWhat) {
  // Find all the checkboxes...
  var inputs = document.getElementsByTagName("input");

  // Loop through all form elements (input tags)
  for(index = 0; index < inputs.length; index++)
  {
    // ...if it's the type of checkbox we're looking for, toggle its checked status
    if(inputs[index].id == checkWhat)
      if(inputs[index].checked == 0)
      {
        inputs[index].checked = 1;
      }
      else if(inputs[index].checked == 1)
      {
        inputs[index].checked = 0;
      }
  }
}
</script>
<table width="100%" cellpadding="3" cellspacing="0" border="0" class="main" style="border-bottom: 1px solid #C3C3C3"><tr>
<td width="20"><a href="<?php echo "$site_path/pm_compose" ?>"><img src="<?php echo "$site_url/$script_folder/images/pm/msg_new.gif" ?>" alt="Compose A PM" border="0"></a></td>
<td width="1"><input type="checkbox" onClick="CheckAll('pm_delete')"></td>
<td width="45%"><b><u>Subject</u></b></td>
<td width="20%"><b><u>From</u></b></td>
<td><b><u>Date</u></b></td>
</tr></table>
<?php
while ( $pm = mysql_fetch_array ( $result ) ) {
$pm_subject = stripslashes ( "$pm[subject]" );
echo "<table width='100%' cellpadding='3' cellspacing='0' class='main' style='border-bottom: 1px solid #C3C3C3'>";
$date = DisplayDate( "$pm[id]", "M d Y, h:i A", "1" );
echo "<tr>
<td width='20'>";
if ( $pm[status] > 1 ) {
echo "<img src='$site_url/$script_folder/images/pm/msg_new.gif' alt='Unread Message' />";
} else {
echo "<img src='$site_url/$script_folder/images/pm/msg_old.gif' alt='Read Message' />";
} 
echo "</td>
<td width='1'><input type='checkbox' id='pm_delete' name='pm_delete[]' value='$pm[id]'></td>
<td width='45%'>";
if ( $pm[status] > 1 ) {
echo "<a href='$site_path/pm_inbox&id=$pm[id]'><b>$pm_subject</b></a>";
} else {
echo "<a href='$site_path/pm_inbox&id=$pm[id]'>$pm_subject</a>";
}
echo "</td>
<td width='20%'><a href='$site_path/member&id=$pm[sent_by]'>$pm[sent_by]</a></b></td>
<td>$date</td>
</tr>";
$x++;
echo "</table>";
}

} else {

echo "<table width='100%' cellpadding='3' cellspacing='0' class='main' style='border-bottom: 1px solid #666666; border-top: 1px solid #666666'><tr>";
echo "<td align='center'><b>You have no messages in your inbox</b></td>";
echo "</tr></table>";

}

if ( isset ( $_POST[submit] ) ) {
for ( $i = 0; $i <= ( count ( $pm_delete ) - 1 ); $i++ ) {
$delete_pm = mysql_query ( "DELETE FROM pm WHERE id='$pm_delete[$i]' AND sent_to='$user_info[username]'" );
}
echo "<script>document.location='$site_path/pm_inbox'</script>";
}

?>
<table width="100%" cellpadding="3" cellspacing="0" class="main">
<tr><td height="5"></td></tr>
<tr>
<td align="center"><?php echo "<b>".mysql_num_rows ( $result )."</b> Message(s), <b>".mysql_num_rows ( $result_countunread )."</b> Unread out of a maximum <b>$limit</b>" ?></td>
</tr>
<tr>
<td align="center"><input type="submit" name="submit" value="Delete PM(s)" class="form">   <input type="button" value="Compose PM" class="form" onclick="document.location='<?php echo "$site_path/pm_compose" ?>'"></td>
</tr></table>
<?php
} else {
$file_title = "PM Message";
$id = mysql_real_escape_string ( $_GET['id'] );

$result = mysql_query( "SELECT pm.*, users.* FROM pm LEFT JOIN users ON (pm.sent_by=users.username) WHERE pm.id='$id' AND pm.sent_to='$user_info[username]'" );
$pm = mysql_fetch_array ( $result );

if ( isset ( $_POST[pm_delete_submit] ) ) {
$delete_pm = mysql_query ( "DELETE FROM pm WHERE id='$id' AND sent_to='$user_info[username]'" );
echo "<script>document.location='$site_path/pm_inbox'</script>";
}

if ( mysql_num_rows ( $result ) == 0 ) {
echo "<center><b>There are no messages with that ID</b></center>";
} else {

if ( ereg ( "id=$id", $GLOBALS[QUERY_STRING] ) && ( $pm[status] > 1 ) ) {
$result_changestatus = mysql_query ( "UPDATE pm SET status='1' WHERE id='$id' AND sent_to='$user_info[username]'" );
} 

if ( $handle = opendir ( "$script_folder/images/smilies" ) ) {
while ( false !== ( $file = readdir ( $handle ) ) ) { 
if ( $file != "." && $file != ".." && ereg ( ".gif", $file ) ) { 
$smile_name = str_replace ( ".gif", "", $file );
$smilies_array[] = $smile_name;
} 
}
closedir( $handle ); 
}
?>
<script>
function DeletePM() {
if (confirm('Are you sure you want to delete this private message?')) {
document.pm_form.submit();
return true;
} else {
return false;
}
}
</script>
<?php
$member_username = "<a href='$site_path/member&id=$pm[username]'><b><u>$pm[username]</u></b></a>";
$pm_date = DisplayDate( "$pm[id]", "M d Y, h:i A", "1" );
$pm_options = "<a href='$site_path/pm_compose&to=$pm[sent_by]&reply=$pm[id]'>Reply</a> | <a href='#deletepm' onclick='DeletePM()'>Delete</a>";
if ( empty ( $pm[avatar] ) ) {
$member_avatar = "<img src='$site_url/$script_folder/images/avatars/none.gif' alt='none' width='60' height='60'>";
} else {
list ( $avatar_width, $avatar_height ) = getimagesize ( "$pm[avatar]" );
if ( $avatar_width > 60 || $avatar_height > 60 ) {
$member_avatar = "<img src='$pm[avatar]' alt='$pm[username]' width='60' height='60' />";
} else {
$member_avatar = "<img src='$pm[avatar]' alt='$pm[username]' />";
}
} 
if ( $pm[type] == 1 || $pm[type] == 2 ) {
$member_type = "Member";
} elseif ( $pm[type] == 10 ) {
$member_type = "Moderator";
} elseif ( $pm[type] == 20 ) {
$member_type = "Info Team";
} elseif ( $pm[type] == 21) {
$member_type = "Info Team | Mod";
} elseif ( $pm[type] == 30 ) {
$member_type = "M7 Team";
} elseif ( $pm[type] == 31 ) {
$member_type = "M7 Team | Mod";
} elseif ( $pm[type] == 80 ) {
$member_type = "Staff Member";
} elseif ( $pm[type] == 81 ) {
$member_type = "Staff | Admin";
} elseif ( $pm[type] == 90 ) {
$member_type = "Administrator";
} elseif ( $pm[type] == 91 ) {
$member_type = "Admin | M7";
} elseif ( $pm[type] == 98 ) {
$member_type = "Webmaster";
} elseif ( $pm[type] == 99 ) {
$member_type = "Sensei";
} 


$joindate = DisplayDate( "$pm[registered_on]", "m/d/y", "0" );
$member_joindate = "Joined: $joindate";
$member_posts = "Posts: $pm[posts]";
$member_num = "Member No. $pm[user_id]";
if ( ( time() - $pm[last_activity_time] ) <= 300 ) {
$member_online = "Status: <font color='green'>Online</font>";
} else {
$member_online = "Status: <font color='red'>Offline</font>";
}
$pm_subject = "Subject: ".stripslashes ( $pm[subject] )."";
$pm_message = stripslashes ( nl2br ( $pm[message] ) );
$pm_message = ParseMessage ( "$pm_message" );

include ( "templates/pm.php" );

echo "<input type='hidden' name='pm_delete_submit'>";

}

echo "<p><center><input type='button' value='Back To Inbox' class='form' onclick='document.location=\"$site_path/pm_inbox\"' class='form'>   <input type='button' value='Compose PM' class='form' onclick='document.location=\"$site_path/pm_compose\"' class='form'></center>";

}

echo "</td></tr></form></table>";
?>