<?PHP
$file_title = 'Kubo Tite';
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Kubo Tite</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Author of Bleach Manga: Kubo Tite</b></span><br />
<br />
<img src="information/Tite.jpg" alt="Kubo Tite" align="right" />

<div><span class="VerdanaSize1Main"><b>Also known as:</b>&nbsp; Kubo Taito<br />
<b>Family name (in kanji):</b>&nbsp; &#20037;&#20445;<br />
<b>Given name (in kanji):</b>&nbsp; &#24111;&#20154;<br />
<b>Real name:</b>&nbsp; Noriaki (&#23459;&#31456;) Kubo (&#20037;&#20445;)<br />
<br /><b>Date of birth:</b>&nbsp; 1977-06-26<br />
<b>Hometown:</b>&nbsp; Hiroshima prefecture, Japan<br />
<br />
Biography:<br />
<br />
Kubo was born in Hiroshima, Japan on June 26, 1977 as  Noriaki Kubo. Though his birth name was Noriaki Kubo, he is known by Kubo Tite, Kubo Taito, Kubotite, as well as Taito Kubo. Though not  much information is given about his family background, we do know he has a younger sister named Hiromi and a younger brother whose name is unknown at the  moment. Kubo began creating manga during high school (in his school anime club) where he made his first series <i>&quot;Zombie Powder&quot;</i> during his third year. He submitted <i>Zombie Powder</i> to The Weekly Shonen Jump (Shonen Jump)  but it was rejected. He was later contacted by Shonen Jump editors and  managed to improve the series and got <i>Zombie Powder</i> published in Shonen Jump in 1999. But unfortunately for Kubo, it was stopped after 4 books  due to unpopularity and high sexual content. He did manage to make some short stories as well which are featured in the back of the <i>Zombie Powder</i> volumes. The titles are: <i>Ultra Unholy Hearted Machine</i>, <i>Rune Master Urara</i>, and <i>Bad Shield United</i>.<br />
<br />
<br />
Kubo later began working on the series <i>Bleach</i> in hopes that he would finally get one of his own manga accepted by Shonen Jump, but it was sadly rejected as well. This was due to its similarities to the series <i>Yu Yu Hakusho</i> by Yoshihiro  Togashi. Times got very depressing for Kubo at this point  until he receive a letter of encouragement from Akira Toriyama, the creator of the hit series <i>Dragon Ball</i>. It was then that Kubo found renewed hope and in 2002 <i>Bleach</i> was finally published and began serialization in Shonen Jump. The manga has risen to the tops of the charts and is now known worldwide. This led to the production of the anime series, which is now over 90 episodes long! Kubo says he will not release a live action version of Bleach because it was meant to be manga and anime, and  nothing more. Surprisingly, he draws all of the character designs for the anime  series instead of letting his editors and workers do the job. <i>Bleach's</i> popularity has been skyrocketing, and shows no signs of slowing down.</span></div>