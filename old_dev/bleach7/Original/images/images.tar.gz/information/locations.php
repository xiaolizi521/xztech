<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Locations</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Locations:</b></span><span class="VerdanaSize1Main"><br />
<br />
<b><i>Soul Society vs. Earth:</i></b><br />
<br />
Soul Society is the place where spirits live, only souls can enter it: it is an afterlife world. Spirits don't have a material body, that's why it is impossible for humans to access it. Humans' and souls' worlds are separated by the Dangai. Except hollows, if one enters it, it is impossible to get out of it. It is a tunnel, and if you're caught inside, you won't be able to move anymore.<br />
<br />
Soul Society consists of two main parts, the Seireitei in the center, where the shinigami live and the Rukongai where all the other spirits dwell, the latter can't enter the Seireitei which have 4 gates, protected by the elite shinigami. In addition to that, it is also protected by a sphere shaped barrier that blocks any spiritual energy. It is a very vast world, thus, it is very hard for two souls who knew each other in their human lives to find each other.<br />
<br />
Like the Earth, Soul Society has laws, institutes, a government; however, their rules are made in order to protect human spirits, whether they are on Earth or in Soul Society. Souls, like humans, need to eat, especially if they hold spiritual powers. However, the appearance they have is the one they had the moment they died as humans, thus, it is hard to know who is older than who: a child could be older than an adult if he died before the adult. The length of days and night, the time, is the same in each world.<br />
<br />
Earth in Bleach is our modern days world, it has TV, computers, etc. However, even if the system is similar in Soul Society, they don't have the same technology. Souls' world could be compared to our world during the Middle Ages. The lifestyle of ordinary souls in the Rukongai could be compared to a peasant's life, but it's sure not as tough, they live peacefully. They do not forget their human lives, thus, souls know humans' world whereas very few humans know the existence of Soul Society, there are only references to it as "Heaven". No human really knows nor believe it until he dies. A lot of humans live in fear of death, but souls, being already dead, don't have to fear anything of this kind. They enter Soul Society accompagnied by a shinigami, they cannot leave it unless they want to reincarnate.<br />
<br />
An average soul living peacefully in Soul Society feels light, don't age and don't die. According to Rukia, "Soul Society is 9 times out of 10 better than Earth." Even if they're different and separated, they're actually strongly bound: there must be a balance between the number of souls in each world, else it would create a chaos and provoke the end of everything.</span>