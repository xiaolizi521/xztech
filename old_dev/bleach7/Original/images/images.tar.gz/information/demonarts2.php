<?php
$DemonArts_Bakudou_sql = mysql_query ( "SELECT * FROM information_arts WHERE `group` = \"Bakudou\" ORDER BY `Number` ASC" );

$DemonArts_Hadou_sql = mysql_query ( "SELECT * FROM information_arts WHERE `group` = \"Hadou\" ORDER BY `Number` ASC" );

$DemonArts_Other_sql = mysql_query ( "SELECT * FROM information_arts WHERE `group` = \"Other\" ORDER BY `Name` ASC" );

?>
<br /><b>Bleach 7 &gt; Information &gt; Weapons &gt; Demon Arts</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Demon Arts</b></span><span class="VerdanaSize1Main"><br />
<br />
Demon arts are spells used by shinigami to do various things such as binding, attacking, and healing. Only upper level shinigami can use them after sufficient training.  There are two types of Demon Arts: Bakudou (&quot;binding spell&quot;) and Hadou (&quot;blast spell&quot;).  Demon Arts are classified by power and difficulty of casting in a numbering scheme from 1 through 99, with power and difficulty increasing with the number.  If a shinigami masters demon arts, they will gain the ability to bypass the incantation while casting spells.<br />
<br />
<span class="artstitle"><b>Known Demon Arts</b></span>: (current as of 06/24/06)<br />
<br />
<b><span style="text-decoration: underline;">Bakudou</span>:</b><br />
<?php
while ( $DemonArts_Bakudou_list = mysql_fetch_array ( $DemonArts_Bakudou_sql ) ) {
	$Number = $DemonArts_Bakudou_list['Number'];
	$Style = $DemonArts_Bakudou_list['Style'];
	$Name = $DemonArts_Bakudou_list['Name'];
	$Trans = $DemonArts_Bakudou_list['Trans'];
	$Group = $DemonArts_Bakudou_list['Group'];
	$Desc = $DemonArts_Bakudou_list['Desc'];
	$Incan1 = $DemonArts_Bakudou_list['Incantation1'];
	$Incan2 = $DemonArts_Bakudou_list['Incantation2'];

	echo "<b>$Group #$Number";
	if ( $Style > 1 ) {
		echo " Style $Style</b>"
	}
	else {
		echo "</b>";
	}
	echo " - $Name (&quot;$Trans&quot;) $Desc<br />
";

	if ( !empty ( $Incan1 ) && !empty ( $Incan2 ) ) {
		echo "<i>Initial Spell Incantation: $Incan1<br />
Continuation Spell Incantation: $Incan2</i><br />
";
	}
	elseif ( !empty ( $Incan1 ) ) {
		echo "<i>Incantation: $Incan1</i><br />
";
	}
}
?>
<br />
<b><span style="text-decoration: underline;">Hadou</span>:</b><br />
<?php
while ( $DemonArts_Hadou_list = mysql_fetch_array ( $DemonArts_Hadou_sql ) ) {
	$Number = $DemonArts_Bakudou_list['Number'];
	$Style = $DemonArts_Bakudou_list['Style'];
	$Name = $DemonArts_Bakudou_list['Name'];
	$Trans = $DemonArts_Bakudou_list['Trans'];
	$Group = $DemonArts_Bakudou_list['Group'];
	$Desc = $DemonArts_Bakudou_list['Desc'];
	$Incan1 = $DemonArts_Bakudou_list['Incantation1'];
	$Incan2 = $DemonArts_Bakudou_list['Incantation2'];

	echo "<b>$Group #$Number";
	if ( $Style > 1 ) {
		echo " Style $Style</b>"
	}
	else {
		echo "</b>";
	}
	echo " - $Name (&quot;$Trans&quot;) $Desc<br />
";

	if ( !empty ( $Incan1 ) && !empty ( $Incan2 ) ) {
		echo "<i>Initial Spell Incantation: $Incan1<br />
Continuation Spell Incantation: $Incan2</i><br />
";
	}
	elseif ( !empty ( $Incan1 ) ) {
		echo "<i>Incantation: $Incan1</i><br />
";
	}
}
?>
<br />
<span class="artstitle"><b>Other classes of Demon Arts</b></span>:<br />
<?php
while ( $DemonArts_Other_list = mysql_fetch_array ( $DemonArts_Other_sql ) ) {
	$Name = $DemonArts_Bakudou_list['Name'];
	$Trans = $DemonArts_Bakudou_list['Trans'];
	$Group = $DemonArts_Bakudou_list['Group'];
	$Desc = $DemonArts_Bakudou_list['Desc'];
	$Incan1 = $DemonArts_Bakudou_list['Incantation1'];
	$Incan2 = $DemonArts_Bakudou_list['Incantation2'];

	echo "<b>$Name (&quot;$Trans&quot;)</b>: $Desc<br />
";

	if ( !empty ( $Incan1 ) && !empty ( $Incan2 ) ) {
		echo "<i>Initial Spell Incantation: $Incan1<br />
Continuation Spell Incantation: $Incan2</i><br />
";
	}
	elseif ( !empty ( $Incan1 ) ) {
		echo "<i>Incantation: $Incan1</i><br />
";
	}
}
?>
<br />
<br />
<br />
If you would like to help out with this section by creating clips of the spells being cast or finding pictures of these spells in the anime and/or the manga, let me know by <a href='?page=member/pm_compose&amp;to=bulbasoarr'>PM</a> or by <a href="mailto: bulbasoarr@yahoo.com?subject=Bleach7 Kidou Guide">email</a>.<br />
<?php
if ( $user_info['type'] == 20 || $user_info['type'] == 21 || $user_info['type'] >= 80 ) {
?>
<br />
<fieldset>
<legend class="main">Demon Arts Edit Section</legend>
	<form name="DemonArts" method="post" action="?page=information/info">
		<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;">
	        <tr>
				<td style="width: 33%"><label><input type="radio" name="DemonArtsGroup" value="radio" checked="checked" />Bakudou</label></td>
				<td style="width: 33%"><label><input type="radio" name="DemonArtsGroup" value="radio" />Hadou</label></td>
				<td style="width: 34%"><label><input type="radio" name="DemonArtsGroup" value="radio" />Other</label></td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;">
			<tr>
				<td style="width: 15%;">Number</td>
				<td style="width: 35%;"><input name="Number" type="text" maxlength="2" style="width: 100%;" /></td>
				<td style="width: 20%;">Style Number</td>
				<td style="width: 30%;"><input name="Style" type="text" style="width: 100%;" value="1" maxlength="2" /></td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;">
			<tr>
				<td style="width: 15%;">Name</td>
				<td style="width: 35%;"><input name="Name" type="text" style="width: 100%;" /></td>
				<td style="width: 20%;">Translation</td>
				<td style="width: 30%;"><input name="Trans" type="text" style="width: 100%;" /></td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;">
			<tr>
				<td style="width: 25%;">Description</td>
				<td style="width: 100%;"><textarea name="Desc" cols="" rows="4" style="width: 100%;"></textarea></td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;">
			<tr>
				<td style="width: 25%;">Incantation</td>
				<td style="width: 100%;"><textarea name="Incan1" cols="" rows="4" style="width: 100%;"></textarea></td>
			</tr>
			<tr>
				<td style="width: 25%;">Incantation Part 2</td>
				<td style="width: 100%;"><textarea name="Incan1" cols="" rows="4"style="width: 100%;"></textarea></td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" style="width: 100%; border: none;">
			<tr>
				<td align="center"><input type="submit" value="Submit Changes" name="DemonArts_submit" class="form" /></td>
			</tr>
		</table>
	</form>
</fieldset>
<?php
}
?>