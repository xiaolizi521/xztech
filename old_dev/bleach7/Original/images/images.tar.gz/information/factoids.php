<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Factoids</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Factoids:</b></span><span class="VerdanaSize1Main"><br />
<br />
Do you have the same birthday as a Bleach character?  Find out! <br />
<br />
<b>January</b><br />
01: Shihouin Yoruichi<br />
08: Ikkanzaka Jiroubou<br />
10: Ikkanzaka Jidanbou<br />
14: Kuchiki Rukia<br />
21: Yamamoto Genryuusai Shigekuni<br />
31: Kuchiki Byakuya<br />
<br />
<b>February</b><br />
11: Soi Fong<br />
12: Kusajishi Yachiru<br />
29: Yasochika Iemura<br />
<br />
<b>March</b><br />
03: Ogawa Michiru<br />
14: Ishida Ryuuken<br />
22: Ishida Souken<br />
23: Don Kanonji<br />
27: Kira Izuru<br />
30: Kurotsuchi Mayuri<br />
30: Kurotsuchi Nemu<br />
<br />
<b>April</b><br />
01: Asano Keigo<br />
01: Yamada Hanatarou<br />
04: Hanakari Jinta<br />
07: Sado Yasutora<br />
13: Honshou Chizuru<br />
14: Ogidou Harunobu<br />
21: Unohana Retsu<br />
<br />
<b>May</b><br />
05: Oomaeda Marechiyo<br />
05: Toono Midoriko<br />
06: Kurosaki Karin<br />
06: Kurosaki Yuzu<br />
12: Tsukabishi Tessai<br />
18: Kunieda Ryou<br />
23: Kojima Mizuiro<br />
29: Aizen Sousuke<br />
<br />
<b>June</b><br />
03: Hinamori Momo<br />
09: Kurosaki Masaki<br />
25: Kurumadani Zennosuke<br />
<br />
<b>July</b><br />
07: Ise Nanao<br />
08: Enjouji Tatsufusa<br />
11: Kyouraku Shunsui<br />
15: Kurosaki Ichigo<br />
17: Arisawa Tatsuki<br />
18: Iba Tetsuzaemon<br />
<br />
<b>August</b><br />
02: Kotetsu Isane<br />
07: Natsui Mahana<br />
14: Hisagi Shuuhei<br />
23: Komamura Sajin<br />
31: Abarai Renji<br />
<br />
<b>September</b><br />
03: Inoue Orihime<br />
09: Tsumugiya Ururu<br />
10: Ichimaru Gin<br />
13: Ochi Misato<br />
19: Ayasegawa Yumichika<br />
22: Kotsubaki Sentarou<br />
22: Kotetsu Kiyone<br />
29: Matsumoto Rangiku<br />
<br />
<b>October</b><br />
01: Shiba Kuukaku<br />
15: Shiba Ganju<br />
27: Shiba Kaien<br />
<br />
<b>November</b><br />
04: Sasakibe Choujirou<br />
06: Ishida Uryuu<br />
09: Madarame Ikkaku<br />
13: Tousen Kaname<br />
19: Zaraki Kenpachi<br />
<br />
<b>December</b><br />
10: Kurosaki Isshin<br />
20: Hitsugaya Toushirou<br />
21: Ukitake Juushirou<br />
30: Kon<br />
31: Urahara Kisuke<br /><br /></span>