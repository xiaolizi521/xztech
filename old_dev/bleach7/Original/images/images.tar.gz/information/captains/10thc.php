<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Hitsugaya Toushirou</b><br />
<br />
</font><font face="Verdana" size="2"><b>Hitsugaya Toushirou</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/10th-c.gif" alt="Hitsugaya Toushirou" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Hitsugaya Toushirou<br />
      Division: 10th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He�s known as a genius because he�s captain at his young age. His soul cutter is <i>Hyourinmaru</i>, it can control the weather, and has water/ice power. To release it "Soar in the frozen sky." He protects Hinamori Momo, the vice-captain of 5<sup>th</sup> division and as Aizen Sousuke, he suspects Ichimaru Gin of some evil plan.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different
captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>