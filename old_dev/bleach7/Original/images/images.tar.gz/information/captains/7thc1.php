<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Komamura Sajin</b><br />
<br />
</font><font face="Verdana" size="2"><b>Komamura Sajin</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/7th-c.gif" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Komamura Sajin<br />
      Division: 7th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He says that he owes a debt to Genryuusai Yamamoto, the general-captain, because he accepted him in spite of his appearance. Actually, his body was burnt in some accident and he has the head of a fox, that�s why he always wears a helmet. His soul cutter is <i>Tenken</i> and its Ban Kai form is <i>Kokujyou Tenken Myouou</i>. To release it, he says "Go forth".</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>