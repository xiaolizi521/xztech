<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Aizen Sousuke</b><br>
<br>
</font><font face="Verdana" size="2"><b>Aizen Sousuke</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/5th-c.gif" alt="Aizen Sousuke" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br>
      <br>
      Name: Aizen Sousuke<br>
      Division: 5th<br>
      Rank: Captain<br>
      Special Rank: None<br>
      <br>
      *Dead?<br>
      <br>
      Short Info:<br>
      He appeared to be killed before we could see him fighting, thus, his soul cutter is unknown. He looks intelligent and gentle. He seems to appreciate night walks. He suspected Ichimaru Gin, captain of the 3<sup>rd</sup> division of some evil plan but he was killed before we could know the truth.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br>
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br>
<br>
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>