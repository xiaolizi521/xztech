<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Ise Nanao</b><br />
<br />
</font><font face="Verdana" size="2"><b>Ise Nanao</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/8th-cc.gif" alt="Ise Nanao" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Ise Nanao<br />
      Division: 8th<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      She must have a soul cutter but it�s still unknown, she also uses demon art to fight. Actually, she has the look of a secretary with her glasses. She gets along well with her captain.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>