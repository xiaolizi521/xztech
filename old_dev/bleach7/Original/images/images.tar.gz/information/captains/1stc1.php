<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Yamamoto Genryuusai</b><br />
<br />
</font><font face="Verdana" size="2"><b>Yamamoto Genryuusai</b></font><font face="Verdana" size="1"><br />
<br />

<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><img border="0" src="images/1st-c.gif" alt="Yamamoto Genryuusai" width="199" height="276" /></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Yamamoto Genryuusai<br />
      Division: 1st<br />
      Rank: Captain<br />
      Special Rank: General Captain (over all other captains)<br />
      <br />
      Short Info:<br />
      He is also the general-captain of Gotei 13. He has the look of a very old man and very little is known about him. His vice-captain is still unknown but a man with a mustache often appears behind him.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>