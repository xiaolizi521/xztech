<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Abarai Renji</b><br />
<br />
</font><font face="Verdana" size="2"><b>Abarai Renji</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/6th-cc.gif" alt="Abarai Renji" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Abarai Renji<br />
      Division: 6th<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He was born in Area 78, Inuzuri, also known as the South Alley of flowing spirit, a place ruled by misery. He's Rukia's childhood friend and he's a graduate of the 2066<sup>th</sup> year of Shinigami School. He was first in 5<sup>th</sup> division but he was transferred to the 11<sup>th</sup> division because of his combat strength, finally, he was promoted as the vice-captain of 6<sup>th</sup> division. Unfortunately, he despises Byakuya Kuchiki. His soul cutter is <i>Zabimaru</i>, which is used like a whip. To release it, "<i>Roar</i>". Its Ban Kai form is Baboon king Zabimaru or Hihiou Zabimaru, it looks like some snake skeleton, it seems to be made of bones, and actually, it�s connected to his spiritual power, so it can't be destroyed unless he�s near death.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>