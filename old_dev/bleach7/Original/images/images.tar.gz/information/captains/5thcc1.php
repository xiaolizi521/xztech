<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Hinamori Momo</b><br />
<br />
</font><font face="Verdana" size="2"><b>Hinamori Momo</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/5th-cc.gif" alt="Hinamori Momo" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Hinamori Momo<br />
      Division: 5th<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      This little girl looks pretty weak but she specializes in demon arts. She admires Aizen a lot and wants to avenge his death. Her soul cutter is <i>Tobiume</i> and to release it, she says "Burst" She seems close to 10<sup>th</sup> division captain, Hitsugaya and 3<sup>rd</sup> division vice-captain Ijiru Kira.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>