<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Kyouraku Shunsui</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kyouraku Shunsui</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/8th-c.gif" alt="Kyouraku Shunsui" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Kyouraku Shunsui<br />
      Division: 8th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      His soul cutter name is unknown but he doesn�t seem to need it a lot, likewise, his movements are very fast, he prefers peace and sake; he�s a rather simple man. He�s always seen wearing a straw hat. He likes to tease his vice-captain, calling her "My little Nanao".</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>