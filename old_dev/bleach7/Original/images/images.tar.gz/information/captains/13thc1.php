<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Ukitate Jyuushiro</b><br />
<br />
</font><font face="Verdana" size="2"><b>Ukitate Jyuushiro</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/13th-c.gif" width="199" alt="Ukitate Jyuushiro" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Ukitate Jyuushiro<br />
      Division: 13th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He seems to suffer of a strange disease. He can't fight for a long time and coughs a lot. His soul cutter is unknown but he looks pretty powerful, being able to stop an attack from Byakuya Kuchiki. He�s Rukia's captain.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>