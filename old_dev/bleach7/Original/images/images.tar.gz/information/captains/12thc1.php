<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Kurotshuchi Mayuri</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kurotshuchi Mayuri</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/12th-c.gif" alt="Kurotshuchi Mayuri" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Kurotshuchi Mayuri<br />
      Division: 12th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He�s also the President of the research institute of technology, successor to Kisuke Urahara. He�s a mad scientist, cruel on top of that. During battle, he can modify his body: extending his arm, cutting it, growing it back. His soul cutter is <i>Ashisogi Jizou</i>, it can paralyze the enemy or transform anything he cuts into liquid. Its Ban Kai form is <i>Golden Ashisogi Jizou</i>, it sucks its owner blood and transform it into poison. To release it, he says "Pillage".</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>