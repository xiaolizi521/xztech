<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Weapons &gt; Cane</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Cane (Urahara's)</b></span><span class="VerdanaSize1Main"><br />
<br />
Owned by Urahara, a former Shinigami turned store owner, this special cane has 3 known uses. 1. To be used as a regular walking cane. 2. To house a his Soul Slayer, Benihime (which symbolizes that Urahara was once a shinigami). and 3. To separate souls from a body, similar to the way [<a href="?page=information/skullglove">Rukia's skull glove</a>] does.</span>