<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Weapons &gt; Skull Glove</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Skull Glove (Rukia's)</b></span><span class="VerdanaSize1Main"><br />
<br />
Owned by Rukia (a shinigami), this special glove is only worn and used for separating souls from their respective bodies. To use, the shinigami/user would put the glove on, and push/hit/shove the target/body, and the soul is &quot;pushed&quot; out of the body. This is similar in use as [<a href="?page=information/cane">Urahara's Cane</a>]'s 3rd listed use.</span>