<link rel="stylesheet" type="text/css" href="css/transition2.css" />
<br /><b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Episode List</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach TV Episode List</b></span><span class="VerdanaSize1Main"><br />
<br />
001. The Day He Became Shinigami<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinigami ni natchatta hi &#12300;&#27515;&#31070;&#12395;&#12394;&#12387;&#12385;&#12419;&#12387;&#12383;&#26085;&#12301;
<br />
002. The Shinigami`s work<br />
<br />
003. The older brother`s wish, the younger sister`s wish<br />
<br />
004. Curse of the parakeet<br />
<br />
005. Beat the Invisible Enemy!<br />
<br />
006. Mortal Combat! Ichigo vs Ichigo<br />
<br />
007. Greeting From a Stuffed Toy<br />
<br />
008. June 17, Memory of Rain<br />
<br />
009. Unbeatable Enemy<br />
<br />
010. Assault on Trip at Sacred Ground!<br />
<br />
011. Legendary Quincy<br />
<br />
012. Gentle Right Arm<br />
<br />
013. Flower and Hollow<br />
<br />
014. Struggling Together<br />
<br />
015. Kon`s Big Operation<br />
<br />
016. Abarai Renji, Arrives!<br />
<br />
017. Ichigo, Dying<br />
<br />
018. Regain it! Shinigami`s Power!<br />
<br />
019. Ichigo, Degrade into a Hollow!<br />
<br />
020. The Shadow of Ichimaru Gin<br />
<br />
021. Sudden Entry! The World of Shinigami<br />
<br />
022. The Man Who Hates Shinigami<br />
<br />
023. 14 Days Before Rukia`s Execution<br />
<br />
024. Assemble! The 13 Divisions<br />
<br />
025. Break through the Center with the Gigantic Shell?<br />
<br />
026. Formation! The Worst Tag<br />
<br />
027. Sure Kill Blow Release!<br />
<br />
028. Targeted Orihime<br />
<br />
029. Breakthrough! The Shinigamis` Encompassing Net<br />
<br />
030. Renji`s Confrontation<br />
<br />
031. The Resolution to Kill<br />
<br />
032. The Star and the Stray Dog<br />
<br />
033. Miracle! New Hero of Enigma<br />
<br />
034. Tragedy of Dawn<br />
<br />
035. Aizen Assassination! The Creeping Darkness<br />
<br />
036. Zaraki Kenpachi, Drawing Close<br />
<br />
037. The Reason for Fists<br />
<br />
038. Driven into a Corner! Broken Zangetsu<br />
<br />
039. Immortal Man<br />
<br />
040. The Shinigami Ganju Saw<br />
<br />
041. Reunion, Ichigo and Rukia<br />
<br />
042. Shunshin (God of Flash) Yoruichi, Dance!<br />
<br />
043. Vicious Shinigami<br />
<br />
044. Ishida, Extreme Limits of his Power!<br />
<br />
045. Exceeding the Limits!<br />
<br />
046. Authentication! The School of Shinigami<br />
<br />
047. The Things for Revenge<br />
<br />
048. Hitsugaya, Howl<br />
<br />
049. Rukia`s Nightmare<br />
<br />
050. The Awakening Lion<br />
<br />
051. Morning of the Sentence<br />
<br />