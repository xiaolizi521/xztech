<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Kotsubaki Sentarou</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kotsubaki Sentarou</b></font><font face="Verdana" size="1"><br />
<br />
Division: 13<sup>th</sup><br />
Rank: 3<sup>rd</sup> seat (#1)<br />
Zanpakuto: unknown<br />
<br />
Kotsubaki Sentarou is one of two officers that share the 3<sup>rd</sup> seat of the 13<sup>th</sup> division; it is most likely that they received this promotion after Shiba Kaiens wife had passed away as she was the previous 3<sup>rd</sup> seated officer of the divison. As a result of having to share the 3<sup>rd</sup> seat Sentarou and Kiyone are constantly competing with each other in very loud and vocal ways they both completely idolise their captain and are always doing their best to gain his favour. Not much is known about Sentarou�s past except for the fact that like Rukia, Sentarou is also from Rukongai</font>