<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Inoue, Orihime</b><br />
<br />
</font><font face="Verdana" size="2"><b>Inoue, Orihime</b></font><font face="Verdana" size="1"><br />
<br />
Height: 157 cm (5'2&quot;)<br />
Weight: 45 kg (99 lbs)<br />
Blood Type: B<br />
DOB: September 3<br />
<br />
- Likes Asian and flower prints<br />
- Likes comedies<br />
- Mouth is open when daydreaming<br />
- Likes cheese and butter<br />
- Is a student health advisor<br />
- Status of parents unknown; supported by relatives<br />
<i>Theme Song:</i> &quot;T'en va Pas&quot; by Elsa on &quot;L'Essential Elsa 1986-1993&quot;<br />
<br />
Orihime is a student at Karakura High School in Ichigo's class. She is a very heavy daydreamer, and this can sometimes make her seem a little flighty. Her best friend is Tatsuki, and she has a big crush on Ichigo. Her apartment number is 202, and she and her stuffed bear Enraku live there supported by relatives.<br />
<br />
Orihime had a brother that was 15 years older than her. According to him, their parents were not very classy folk who were both neglectful and abusive. When he turned 18, he took Orihime and left. However, he died in a car accident when Orihime was 12. Ichigo first saw her when she dragged her brother to the Kurosaki Clinic following the accident. Unfortunately he died before he could be transferred elsewhere. Due to some jealousy issues, her brother turned into a hollow and tried to attack Orihime. However, Orihime and her brother worked through things, and he gave himself up to the shinigami. She now constantly wears the hairpins that he gave her.<br />
<br />
At times she seems a bit spacey and gullible. Her vision of herself in the future includes a robotic body when missiles that fire out of her breasts, and one of her favorite shows is &quot;Ghost Busters&quot; when Don Kanonji. However, she is very sensitive to other people's feelings, especially Ichigo. Around the time of the incident with Don Kanonji, Orihime admits to Tatsuki that she has been kicked out of her apartment and is living in a hotel. During the television broadcast, she can hear the earthbound spirit wailing as it turns into a hollow.<br />
<br />
Orihime performs very well in school, and was near the top of her year in exams. She is also a member of the handy-craft club with Ishida. After the incident with Don Kanonji, some spiritual power had awakened in Orihime. When forced to protect herself and Tatsuki, she discovers her power is manifest in some fairy-like creatures known as the shin shin rikka whom she calls upon to cast spells. Hinagiku, Baigon, and Lily form santen kesshun, or an outer shield. Shonou and Ayame form souten kisshun, or an inner shield. Tsubaki can split an enemy in two in an incantation called koten zanshun.<br />
<br />
When Rukia is taken back to the Soul Society, Orihime is one of the few people that remember Rukia had existed in their world. She then trains with Chad under Yoruichi to heighten her abilities. During this time she tells Tatsuki she is going to stay with her grandmother. Orihime then becomes part of the rescue team that enters the Soul Society. In the Soul Society, Orihime proves herself more than adept at protecting herself and Ishida after they are separated from the rest of the group. Her friendly and outgoing personality have helped her and Ishida make their way through the Soul Society relatively safely.</font>