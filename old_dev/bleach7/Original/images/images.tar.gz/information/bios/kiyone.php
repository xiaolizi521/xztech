<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Kotetsu, Kiyone</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kotetsu, 
Kiyone</b></font><font face="Verdana" size="1"><br />
<br />
Division: 13<sup>th</sup><br />
Rank: 3<sup>rd</sup> seat (#2)<br />
Zanpakuto: unknown<br />
<br />
One of two officers on the 3<sup>rd</sup> seat of the 13<sup>th</sup> division Kotetsu Kiyone is the sister to vice captain of the 4<sup>th</sup> division Kotetsu Isane. Kiyone is extremely devoted to her captain and is always competing with the other 3<sup>rd</sup> seated officer of her division Kotsubaki Sentarou, these two officers never let the captain out of their sight and are always seeking to outdo each other in their assigned tasks in order to gain the captains favour. It's most likely that these two officers were promoted to the 3<sup>rd</sup> seat after Shiba Kaiens wife passed away as she was previously the 3<sup>rd</sup> seated officer of the division.</font>