<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt;
Shun Shun Rikka</b><br />
<br />
</font><font face="Verdana" size="2"><b>Shun Shun Rikka (Shield of 6 dancing flowers)</b></font><font face="Verdana" size="1"><br />
<br />
The Shun Shun Rikka is a unique soul power utilized by Orihime initially to defeat the hollow that killed Tatsuki. This specific soul power is comprised of three teams in the 6 person group, each of which has their own special power. The first group, which consists of Hinagiku, Baigon, and Lily create an outer shield to repel enemy attacks away from the user. This deflected the hollows attack at school and pushed back Seimichio in the Dangai. The next team of Shonou and Ayame materialize an inner shield which sole purpose is to repel damage that has already been received. These two are responsible for bringing Tatsuki back from the dead, reattaching Jidanbou's arm in Soul Society after Ichimaru severed it, and to heal Tsubaki after being carelessly wounded by Kamaitachi Ziroubou. The last team is a one man team of Tsubaki, the scarfed warrior, who's power is to repel the inner shield inside an enemy, thus splitting him down the middle. He used this against the hollow at Karakura High School and killed it instantly. He is currently injured and is healing slowly, but is always up for the task of fighting.<br />
<br />
These tiny, fairy-like fighters all hold their own personalities, but seem to be lead by Tsubaki. The only way Orihime can command these six with her current ability,though, is to recite their names and a special incantation for each. The outer shield incantation is &quot;Santen Kesshun&quot;, the inner shield incantation is &quot;Souten Kishun&quot; and Tsubaki's incantation is &quot;Koten Zanshun.&quot; The Shun Shun Rikka is an extremely useful power because it can virtually do everything and once Orihime can control them without any incantation at all, she will be indispensable in any fight.<br />
<br />
(Yes, technically the 'Shun Shun Rikka' as a collective are not a person requiring a biography. But we decided since they are made of 6 very small people, it deserved to be there anyways. ~Kon)<br />
<br />
<br />
(Written by Dimas Pinzon; aka Peurtoroo)</font>