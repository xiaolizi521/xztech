<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Yasutora, Sado</b><br />
<br />
</font><font face="Verdana" size="2"><b>Yasutora, Sado (Chad)</b></font><font face="Verdana" size="1"><br />
<br />
Height: 197 cm<br />
Weight: 112 kg<br />
Blood Type: AO<br />
DOB: April 7<br />
<br />
- likes flashy shirts with an open collar<br />
- has a tattoo on his left shoulder of a snake wrapped around a heart with wings. There is a ribbon around the snake with the words &quot;Amore e Morte&quot; (love and death).<br />
- like small animals<br />
- favorite food is tomato<br />
<i>Theme Song:</i> &quot;No song unheard&quot; - The Helicopters<br />
<br />
The kind, yet strong-and-silent type Sado Yasutora (commonly known as Chad) is a 15 year old student at Karakura High School, where his class rank is eleventh from the top. The only family that he is know to have had was his grandfather, who instilled great values into his young, impressionable mind. His abuelo, Oscar Joaquin de la Rosa, taught him that although his fists were big and his punches were forceful, he should never use them unless they were for the protection of another. Sado swore to himself and his grandfather that he would never hurt any living being on his own account. Aside from the promise that he made to his grandfather, Sado promised that if Ichigo put his life on the line for a cause, he would do the same. The bond between these two is fraternally strong and both would sacrifice their lives in the interest of the other.<br />
<br />
When Sado is first introduced in the manga, he is offered a &quot;cursed&quot; bird, Shibata Yuichi, and humbly accepts him. From the moment that he accepts the cage and the talking parakeet, his life becomes dangerous. First, a steel I beam falls from a construction site and Sado catches it on his back in order to save the bird and his two friends. Any lesser man would have died, but Yasutora sustained minimal damage. With that said, he walks away from the scene and proceeds to go to school, only to be hit by a speeding motorcycle. Although the bike was no doubt mangled, Sado Yasutora was perfectly fine, except for the minor cuts on his hands. He singlehandedly carried the motorcyclist to the hospital and footed it back to school, arriving late, but just in time to dispense a punk named Ooshima that was picking a fight with Ichigo. Later that day, he arrives at the Kurosaki Clinic to be treated for a massive burn on his back, which Ichigo and Rukia realize it to be a Hollow wound. Escaping from the clinic during the night, he is pursued by the hollow later on in the day and thankfully is spotted by Ichigo.<br />
<br />
Splitting up, Rukia chases Sado and Ichigo takes care of another problem that came up (his sister Karin was sick on the ground). When Rukia catches up to Sado and is attacked by the cocky hollow who claims to have eaten shinigamis galore, Sado fearlessly swings away at an invisible enemy. Never doubting himself for a moment, he rips a telephone pole out of the cement with his raw strength and slams it downwards under Rukia's coordinates, crushing the hollow underneath the splintered wood. Afraid of his brute strength, the hollow uses Shibata in the cage as a hostage and uses the opening to chase Rukia in her weakened gigai. Ichigo comes just in time to fight the hollow, saving Shibata Yuichi, Sado Yasutora, and Kuchiki Rukia all in a days work. Because of this fateful day, Sado is now capable of detecting shinigami, hollows, and any other spirits. He has Ichigo to thank, or blame, for the burden of responsibility associated with this new power.<br />
<br />
Snowballing into a chain of events, Yasutora's new-found technique leads to another dormant ability: The Right Arm of the Giant. His right arm is coated in black armor with two deadly prongs jutting from his shoulder and a white stripe running from his shoulder to the tips of his fingers. This arm can literally crush anything that threatens the security of all he holds dear. To give you an idea of the sheer power that his right arm produces, let's just say that he dispatched a hollow with a single punch, a team of shinigamis with a single punch, and Tatsuhusa Enjyouji, 3rd seat of the 8th Division, with a single punch. But, for every action, there is an equal and opposite reaction, which is the unbelievable energy drained from his hardened body. Before his training with Yoruichi, he was only able to land two punches without passing out, but by the time he squares off with Shunsui Kyouhaku, Captain of the 8th Division, he can piston his arm almost a dozen times before his body collapses.<br />
<br />
A strong and loyal fighter, Sado Yasutora joins the fight to save Kuchiki Rukia from Senzaikyuu merely because Ichigo was willing to die for this woman. A lot can be said by his silence and even more by his actions. He is quick with his fists if it means saving a life and believes that he cannot lose if his cause is just. He fight for Ichigo and Ichigo fights for him. If they make it out of Soul Society alive, Sado will no doubt rub his grandfather's memento between his fingers on the riverbank that he enjoys so peacefully.<br />
<br />
<br />
(Written by Dimas Pinzon; aka Peurtoroo)</font>