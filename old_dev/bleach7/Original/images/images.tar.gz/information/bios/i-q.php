<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Character Biographies &gt; I-Q</b><br />
<br />
</font><font size="2" face="Verdana"><b>Bleach Character Biographies</b></font><font face="Verdana" size="1"><br />
<br /></font>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana">|<a href="index.php?page=information/bios/0-9">#-9</a>| |<a href="index.php?page=information/bios/a-h">A-H</a>| |<a href="index.php?page=information/bios/i-q">I-Q</a>| |<a href="index.php?page=information/bios/r-z">R-Z</a>|</font></td>
	</tr>
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana"><br /></font>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Inoue, Orihime</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Orihime.jpg" alt="Inoue, Orihime" style="width: 50px; height: 50px;" /></td>
					<td width="14%"></td>
					<td width="65%"><font size="1" face="Verdana">Orihime is a student at Karakura High School in Ichigo's class. She is a very heavy daydreamer, and this can sometimes make her seem a little flighty. Her best friend is Tatsuki, and she has a big crush on Ichigo. Her apartment number is 202, and she and her stuffed bear Enraku live there supported by relatives...(<a href="index.php?page=information/bios/orihime">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Ishida, Uryuu</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Ishida.jpg" alt="Ishida, Uryuu" style="width: 50px; height: 50px;" /></font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Ishida is a Quincy, a person who fights hallows. However, unlike shinigami, Quincys kill hollows, not purify them. Because of this, the Quincy were destroyed by the shinigami 200 years before. This was done to keep the balance of souls correct and keep the world from being destroyed. Ishida's sensei and grandfather taught him to love all creatures, but he died without any shinigami there to help him. As a result, Ishida hates all shinigami...(<a href="index.php?page=information/bios/uryuu">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"> Jinta, Hanakari</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/jinta.jpg" alt="Jinta, Hanakari" style="width: 50px; height: 50px;" /></font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">This young, cocky, and rude child is employed at Urahara Shop, but spends most of his time dreaming of being a famous baseball player. While his primary job is sweeping, he makes an occupation out of beating up Ururu, who is three years older than him and he reveals to her that she is below him on a social level.</font><font face="Verdana" size="1">..(<a href="index.php?page=information/bios/hanakarijinta">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Kagine-Sensei</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font size="1" face="Verdana">Image N/A</font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Kagine-Sensei is one of the teachers at Karakura High School, which Kurosaki Ichigo attends. He has the build of the stereotypical military man, muscular with the rectangular haircut and a thin moustache. He is very rough with the male students, calling them morons and bullying them around, but he has a weakness...(<a href="index.php?page=information/bios/kagine">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Kanonji, Don (Kanonji
            Misaomaru)</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="14%"></td>
					<td width="65%"><font size="1" face="Verdana">To Japan, he is "The charismatic spirit medium of the new century! Messenger of Hell! Mister Don Kanonji!" but to Ichigo and Rukia, he is merely a self proclaimed exorcist that believes his own hype. It would be difficult to call him a crock, for he believes that what he does when he encounters a spirit (and he does encounter spirits) is the correct way of sending souls to heaven...(<a href="index.php?page=information/bios/donkanonji">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Keigo, Asano</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/asano.jpg" alt="Keigo, Asano" style="width: 50px; height: 50px;" /></font></td>
					<td width="14%"></td>
					<td width="65%"><font size="1" face="Verdana">One of the more minor characters of the series, he's one of the main sources of comic relief back in the human world. 15-year-old Asano Keigo, along with Kojima Mizuiro, are often seen hanging around with Ichigo...(<a href="index.php?page=information/bios/asano">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Kenpachi, Zaraki</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/zaraki.jpg" alt="Kenpachi, Zaraki" style="width: 50px; height: 50px;" /></font></td>
					<td width="14%"></td>
					<td width="65%"><font size="1" face="Verdana">Zaraki Kenpachi is one of the most interesting captains in the Gotei 13, leading the 11th division. With spiked hair with bells at the end and an eye patch, one may not take him seriously at first. However, he is one of the mightiest and most feared captains in Seireitei. With his incredibly powerful fighting techniques, he heads the 11th division with...(<a href="index.php?page=information/bios/zaraki">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Kogawa, Michiru</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="14%"></td>
					<td width="65%"><font size="1" face="Verdana">Kogawa (or Ogawa) Michiru is a classmate of Kurosaki Ichigo. They are both in Class 3 together. Although Arisawa Tatsuki, another classmate of theirs, had thought that Michiru hated Ichigo, the truth is that Michiru...(<a href="index.php?page=information/bios/michiru">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font size="2" face="Verdana">Kojima, Mizuiro</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Kojima Mizuiro is a classmate of Kurosaki Ichigo.&nbsp; They are both in Class 3 together.&nbsp; He is also fifteen years old.&nbsp; He is one of Ichigo's closest friends, and he goes by Ichigo's house every morning to walk to school together.&nbsp; Ichigo, Mizuiro, and Asano Kiego always hang out together at school....(<a href="index.php?page=information/bios/mizuiro">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Kon</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Kon.jpg" alt="Kon" style="width: 50px; height: 50px;" /></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Kon is a mod konpaku, or mod soul. Mod souls were originally created to possess dead bodies and fight hollows, however the project was scrapped after some shinigami felt this was unsightly. Mod souls were ordered to be destroyed, but one survived in the form of a small pill-sized ball. Mod souls can enhance an aspect of whatever body they possess, and Kon is no exception...(<a href="index.php?page=information/bios/kon">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>
            Kotetsu,</b><b> Kiyone</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">One of two officers on the 3<sup>rd</sup> seat of the 13<sup>th</sup> division Kotetsu Kiyone is the sister to vice captain of the 4<sup>th</sup> division Kotetsu Isane. Kiyone is extremely devoted to her captain and is always competing with the other 3<sup>rd</sup> seated officer of her division Kotsubaki Sentarou, these two officers...(<a href="index.php?page=information/bios/kiyone">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Kotsubaki, Sentarou</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Kotsubaki Sentarou is one of two officers that share the 3<sup>rd</sup> seat of the 13<sup>th</sup> division; it is most likely that they received this promotion after Shiba Kaiens wife had passed away as she was the previous 3<sup>rd</sup> seated officer of the divison. As a result...(<a href="index.php?page=information/bios/sentarou">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Kuchiki, Byakuya</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Byakuya.jpg" alt="Kuchiki, Byakuya" style="width: 50px; height: 50px;" /></font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Kuchiki Byakuya first arrived in Bleach as the silent yet powerful Shinigami sent to Kuraku town alongside Renji to retrieve Rukia and take her back to Soul Society. His power is immediately made evident when he steps in to aid Renji in his fight with Ichigo ending things in a matter of seconds leaving Ichigo bladeless and lying face down on the ground with what he thought was little hope for survival...(<a href="index.php?page=information/bios/byakuya">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Kuchiki, Rukia</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Rukia.jpg" alt="Kuchiki, Rukia" style="width: 50px; height: 50px;" /></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">Rukia is a shinigami from the Soul Society. She first appears in Ichigo's room while chasing a hollow, but when things go wrong her powers get transferred to Ichigo. Without her abilities, she is unable to return to the Soul Society and is forced to inhabit a gigai, or temporary body...(<a href="index.php?page=information/bios/rukia">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Kurosaki, Ichigo</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Ichigo.jpg" alt="Kurosaki, Ichigo" style="width: 50px; height: 50px;" /></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">The main character of Bleach is Kurosaki, Ichigo. The series is named after Ichigo's trademark�and natural�'Bleach' blond hair. However, as a consequence of the outrageous coloring of his hair, he is constantly badgered by adults, who stereotype him as a punk, and other teenagers who think he's copying their own bleached hair...(<a href="index.php?page=information/bios/ichigo">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Oomaede, Marechiyo</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Marechiyo.jpg" alt="Oomaede, Marechiyo" style="width: 50px; height: 50px;" /></font></td>
					<td width="14%"></td>
					<td width="65%"><font face="Verdana" size="1">The Vice-Captain of the 2nd Division. His appearance consist of a gold bracelet, purple scarf, and quite large in size. You can usually find him eating a bag snack, walking behind his Captain, Soi Fong. His personality seems like he is high of himself and no matter what situation he will fallow his Captain's orders. His Zanpakutou's name is Gegetsuburi...(<a href="index.php?page=information/bios/marechiyo">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
			</table>
			<p align="center"><font size="1" face="Verdana"><br /></font></p></td>
	</tr>
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana">|<a href="index.php?page=information/bios/0-9">#-9</a>| |<a href="index.php?page=information/bios/a-h">A-H</a>| |<a href="index.php?page=information/bios/i-q">I-Q</a>| |<a href="index.php?page=information/bios/r-z">R-Z</a>|</font></td>
	</tr>
</table>