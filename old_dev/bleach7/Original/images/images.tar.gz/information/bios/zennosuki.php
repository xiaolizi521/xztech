<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Zennosuke, Kurumandani</b><br />
<br />
</font><font face="Verdana" size="2"><b>Zennosuke, Kurumandani</b></font><font face="Verdana" size="1"><br />
<br />
Zennosuke is the current shinigami replacement for Karakura Town and Kuchiki Rukia. He isn't up to date with the current situation and finds himself to be a &quot;hero without villains to fight.&quot; The reason that the hollows are destroyed before he can even get to them is because of the new hollow fighting force called the Karakura Super Heroes. Of course, Don Kanonji is the leader of this quaint force that showcases Jinta, Ururu, and Kurosaki Karin, each with a characteristic special attack. The afro-headed shinigami is also unaware of people with high spiritual power, which leads us to believe that he is a far weaker shinigami that Kuchiki Rukia. While he is watching the Karakura Super Heroes vanquish a hollow, Tatsuki ambles by, oblivious to the fact that he is a spirit, and accuses him of suspicious intentions because he is watching the kids while hiding. His only appearance thus far in the manga is chapter 88.5 and is used to explain to the fans how the hollows in Karakura Town are being dealt with while Ichigo and Rukia are away.<br />
<br />
<br />
(Written by Dimas Pinzon; aka Puertoroo)</font>