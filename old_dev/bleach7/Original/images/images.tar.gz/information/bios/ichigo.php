<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Kurosaki, Ichigo</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kurosaki, Ichigo</b></font><font face="Verdana" size="1"><br />
<br />
Height: 174 cm<br />
Weight: 61 kg<br />
Blood type: AO<br />
D.O.B: July 7<br />
<br />
- Favorite Style: He likes wearing tight clothes, both top and bottom.<br />
- Favorite Foods: He likes chocolate and spicy foods.<br />
- Favorite Celebrity: Mike Ness and Al Pacino.<br />
- His Hero/Person he looks up to: William Shakespeare<br />
<i>Theme Music:</i> Bad News &quot;News from the front&quot; from stranger than fiction.<br />
<br />
The main character of Bleach is Kurosaki, Ichigo. The series is named after Ichigo's trademark�and natural�'Bleach' blond hair. However, as a consequence of the outrageous coloring of his hair, he is constantly badgered by adults, who stereotype him as a punk, and other teenagers who think he's copying their own bleached hair. Despite his appearance, Ichigo is very intelligent. In order to keep the teachers out of his hair, he spends almost all of his free time studying, since he doesn't do any clubs. If nothing else, his high test scores bring looks of astonishment from friends and teachers alike. However, just like his appearance, Ichigo is one big, tough bad boy. In a fight, even with opponents outnumbering him 3 to 1, it is almost a guarantee that Ichigo will win. His finishing move the &quot;Kurosaki Face Stomp&quot; (a simple, but obviously powerful kick to the face) makes many appearances early on in the manga against your everyday thug.<br />
<br />
However, behind all the brutality, Ichigo is actually a very kind person. He has a penchant for helping those before his eyes. If Ichigo could help you, he would. Of course, if this was the only thing that separated Ichigo from other hero-complex characters, then this would be a very boring and repetitive plot line. However, Ichigo isn�t just another character with a hero-complex. Ichigo can see ghosts, more formally known as Hollows and Pluses. Theories wise, it is a distinct possibility that Ichigo, as well as the rest of the Kurosaki children, inherited this ability from their mother. However, in comparison to most other humans, his family included, Ichigo's spiritual strength is far beyond any human limits. As the story progresses, many of Ichigo's friends develop abilities of their own, or even have their own powers amplified, thanks to the multiple cases of exposure to Shinigami Ichigo. However, even before he had the ability to transform into a shinigami, several of his friends were slowly developing the ability to see spirits. Thus, it is also a possibility that the constant presence of Ichigo�s spiritual strength has enhanced the latent abilities of his friends.<br /> 
<br />
Initially, Ichigo took the shinigami power in order to save his family, but, when the responsibility is thrust onto him, he decided that he would fight for no one else, but himself, and his own principles. However, when presented with the scenario where he must make a decision to save someone, or not, he has always fought to the best of his ability, many times, surpassing all expectations of his abilities. Throughout the story, Ichigo has fought for many things. In his first encounter with a hollow (Fish Bone D), he braved death in order to save his family. Then, he fought to save his friends. Next, he fought for the safety of his town, Karakura, helping to take down Menos Grande in the process. His battle with Grand Fisher to appease his own guilt for his mother�s death has yet to be concluded. Now, he is fighting to save Kuchiki Rukia, forging through spiritual boundaries, to do so.</font>