<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Ishida, Uryuu</b><br />
<br />
</font><font face="Verdana" size="2"><b>Ishida, Uryuu</b></font><font face="Verdana" size="1"><br />
<br />
Height: 171 cm (5'7&quot;)<br />
Weight: 55 kg (121 lbs)<br />
Blood Type: AB<br />
DOB: November 11<br />
<br />
- Hates buttons (likes fasteners)<br />
- Has low blood pressure<br />
- Always tries to play cool<br />
- Favorite food is mackerel miso stew (homemade)<br />
<i>Theme Song:</i> &quot;Idioteque&quot; by Radiohead on &quot;Kid A&quot;<br />
<br />
Ishida is a Quincy, a person who fights allows. However, unlike shinigami, Quincys kill hollows, not purify them. Because of this, the Quincy were destroyed by the shinigami 200 years before. This was done to keep the balance of souls correct and keep the world from being destroyed. Ishida�s sensei and grandfather taught him to love all creatures, but he died without any shinigami there to help him. As a result, Ishida hates all shinigami. <br />
<br />
In school Ishida is at thetop of his class in exams. He is also in the handy-crafts club with Orihime, and appears to be an excellent tailor. He is very sensitive to things of a spiritual nature, and he recognizes Rukia as a shinigami before anyone else knows. Ishida particularly dislikes Ichigo, and challenges him to a hollow killing competition. Using a giant bow and arrow made with his spiritual power, Ishida takes out many of the hollows he attracted to the area. However, when the Menos Grande appears, he is forced to form a temporary alliance with Ichigo. After this battle, Ishida realizes his sensei wanted him to help shinigami, however this doesn�t make his relationship with Ichigo any better.<br />
<br />
When Renji and Byakuya come for Rukia, Ishida immediately comes to her aid. He becomes severely injured in the battle, but Urahara helps him. He then leaves, but he asks Urahara to help Ichigo, as he is the only one who can save Rukia. Ishida declines an opportunity to train with Chad and Orihime under Yoruichi, preferring to train on his own. However, he does travel to the Soul Society to try and rescue Rukia. While in the Soul Society he wears a glove that was given to him by his grandfather. It increases his power, but if he ever removes it he will lose his Quincy abilities. When the group gets separated in the Soul Society, Ishida ends up with Orihime as a traveling companion. They disguise themselves as shinigami to try and avoid fighting. In one battle however, Ishida is forced to remove his glove. It is unclear where his abilities stand</font>