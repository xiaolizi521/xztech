<p /><b><font face="Verdana" size="1">Bleach 7 &gt; Information &gt; Character Biographies &gt; R-Z</b><br />
<br />
</font><font face="Verdana" size="2"><br />Bleach Character Biographies R - Z</font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1">|<a href="?page=information/bios/0-9">#-9</a>|
      |<a href="?page=information/bios/a-h">A-H</a>| |<a href="?page=information/bios/i-q">I-Q</a>|
      |<a href="?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1"><br />
      <br />
      <br />
      </font>
      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Sado, Yasutora (Chad)</font></h1>
          </td>
        </tr>
        <tr>
          <td width="16%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Sado.jpg" alt="" width="50" height="50 /"></font></p></td>
          <td width="15%"></td>
          <td width="69%"><font size="1" face="Verdana">Chad is a large 15-year-old boy who has an apparent affinity for cute, small things. He is extremely strong; he seems relatively unphased when hit by things such as cars and I-beams. He attends Karakura High School and is friends with Ichigo, Kojima, and Asano. He is very intelligent and ranks highly in the class on exams...(<a href="?page=information/bios/sado">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Shiba, Gangyu</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font size="1" face="Verdana">We first meet Shiba Ganjyu as a cocky, flashy fellow whohappens to crash through Elder Dono�fs front door in Soul Society.&nbsp;The reason for his unusual entrance was due to him being thrown off the back of his boar.<span>&nbsp; </span>Nevertheless, he regains his composure long enough to see Ichigo in his shingami garb and rips off his glasses...(<a href="?page=information/bios/ganjyushiba">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Shiba, Kuukaku</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">If there ever was anyone as badass as her, Kuukaku surely would have killed them by now.<span>&nbsp; </span>Not only does she design her own houses (tacky and gaudy though they may be), she is missing her right arm but can still whoop Ganjyu and Ichigo into compliance.<span>&nbsp; </span>She is part of the Shiba family, and since she is the oldest known member, she is also the First Class Fireworks Master...(<a href="?page=information/bios/kuukakashiba">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Shihouin, Yoruichi</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Yorichi.jpg" alt="" width="50" height="50" /><img border="0" src="information/bios/images/Yorichi2.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Taking the form of a black cat, Yoruichi is said to be Urahara�s only relative. She first appears to tell Urahara that Renji and Byakuya have arrived, and they both seem to be expecting this. She trains Chad and Orihime and then enters the Soul Society with the group going to rescue Rukia...(<a href="?page=information/bios/yoruichi">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Shun Shun Rikka</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">The Shun Shun Rikka is a unique soul power utilized by Orihime initially to defeat the hollow that killed Tatsuki. This specific soul power is comprised of three teams in the 6 person group, each of which has their own special power. The first group, which consists of Hinagiku, Baigon, and Lily create an outer shield to repel enemy attacks away from the user.</font>...(<a href="?page=information/bios/shunshunrikka">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Tatsuki, Arisawa</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">More as a background character, Tatsuki is popular because of her renowned fighting techniques and absolute loyalty to Orihime. Had she not had been hit by a car during the semi-finals of the Japanese high school karate tournament, she would have most likely have won first place, but was stuck with runner up and a broken arm....(<a href="?page=information/bios/arisawatatsuki">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Tessai</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Despite his towering height and rock hard muscles, Tessai is a rather peaceful and contemplative man. His rectangular glasses pique his intellectual ability and his silence speaks louder than his deep voice. But this calm image should be taken with a grain of salt, for, when called into action, Tessai's powerfully broad fists are just as threatening as his large jaw, trio of braids, and the thick mustache connected to his dark sideburns...(<a href="?page=information/bios/tessai">read
            more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Urahara, Kisuke</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Urahara.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Urahara is the owner of the aptly named Urahara Shouten. Jinta, Ururu, and Tessai are his three employees. Although his shop is in the living world, it is stocked with goods from the Soul Society. Rukia is seen frequenting his shop when in need of supplies. Urahara is very easy going, although he occasionally shows a more serious side. He is always seen wearing geta (wooden sandals) and a striped hat...(<a href="?page=information/bios/urahara">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">
Yamada, Hanatarou</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Perhaps one of the most overshadowed characters of the series, Hanatarou Yamada is weak of body but strong of heart.&nbsp; He is typically picked on for being a part of the 4th Division, or the weakest division of the Gotei 13.&nbsp; As if being harassed by other divisions wasn't enough, his own division singles him out and he is the brunt of many harsh pranks.&nbsp; His captain is the usual perpetrator of said pranks and sees Hanatarou as a way to vent...(<a href="?page=information/bios/yamadahanatarou">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Zangetsu/Kitsuki</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Zangetsu is the physical manifestation of Ichigo�s soul cutter. He serves as a sort of spiritual guide for Ichigo when he is having problems. Zangetsu first appears to keep Ichigo from turning into hollow during his training with Urahara. His appearance is that of a man with long, dark hair. Ichigo recognizes the man as his uncle Kitsuki...(<a href="?page=information/bios/zangetsu">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Zennosuke, Kurumandani</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font size="1" face="Verdana">Zennosuke is the current shinigami replacement for Karakura Town and Kuchiki Rukia.&nbsp;He isn�ft up to date with the current situation and finds himself to be a ghero without villains to fight.&nbsp; The reason that the hollows are destroyed before he can even get to them is because of the new hollow fighting force called the Karakura Super Heroes...(<a href="?page=information/bios/zennosuki">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
            <p><br />
          </td>
        </tr>
      </table>
      <p align="center"><font face="Verdana" size="1">
      <br />
      <br />
      </font></td>
  </tr>
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1">|<a href="?page=information/bios/0-9">#-9</a>|
      |<a href="?page=information/bios/a-h">A-H</a>| |<a href="?page=information/bios/i-q">I-Q</a>|
      |<a href="?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
</table></font>