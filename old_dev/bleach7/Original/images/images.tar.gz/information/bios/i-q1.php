<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Character Biographies &gt; I-Q</b><br />
<br />
</font><font face="Verdana" size="2">Bleach Character Biographies I - Q</font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1">|<a href="?page=information/bios/0-9">#-9</a>|
      |<a href="?page=information/bios/a-h">A-H</a>| |<a href="?page=information/bios/i-q">I-Q</a>|
      |<a href="?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1"><br />
      <br />
      <br />
      </font>
      <table border="0" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Inoue, Orihime</font></h1>
          </td>
        </tr>
        <tr>
          <td width="16%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Orihime.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="15%"></td>
          <td width="69%"><font size="1" face="Verdana">Orihime is a student at Karakura High School in Ichigo�s class. She is a very heavy daydreamer, and this can sometimes make her seem a little flighty. Her best friend is Tatsuki, and she has a big crush on Ichigo. Her apartment number is 202, and she and her stuffed bear Enraku live there supported by relatives...(<a href="?page=information/bios/orihime">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Ishida, Uryuu</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Ishida.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Ishida is a Quincy, a person who fights hallows. However, unlike shinigami, Quincys kill hollows, not purify them. Because of this, the Quincy were destroyed by the shinigami 200 years before. This was done to keep the balance of souls correct and keep the world from being destroyed. Ishida�s sensei and grandfather taught him to love all creatures, but he died without any shinigami there to help him. As a result, Ishida hates all shinigami...(<a href="?page=information/bios/uryuu">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2"> Jinta, Hanakari</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">This young, cocky, and rude child is employed at Urahara Shop, but spends most of his time dreaming of being a famous baseball player. While his primary job is sweeping, he makes an occupation out of beating up Ururu, who is three years older than him and he reveals to her that she is below him on a social level...(<a href="?page=information/bios/hanakarijinta">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Kanonji, Don (Kanonji Misaomaru)</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1">Image N/A</font></td>
          <td width="14%"></td>
          <td width="65%"><font size="1" face="Verdana">To Japan, he is "The charismatic spirit medium of the new century! Messenger of Hell! Mister Don Kanonji!" but to Ichigo and Rukia, he is merely a self proclaimed exorcist that believes his own hype. It would be difficult to call him a crock, for he believes that what he does when he encounters a spirit (and he does encounter spirits) is the correct way of sending souls to heaven.(<a href="?page=information/bios/donkanonji">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Kon</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Kon.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Kon is a mod konpaku, or mod soul. Mod souls were originally created to possess dead bodies and fight hollows, however the project was scrapped after some shinigami felt this was unsightly. Mod souls were ordered to be destroyed, but one survived in the form of a small pill-sized ball. Mod souls can enhance an aspect of whatever body they possess, and Kon is no exception...(<a href="?page=information/bios/kon">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Kuchiki, Rukia</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Rukia.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">Rukia is a shinigami from the Soul Society. She first appears in Ichigo�s room while chasing a hollow, but when things go wrong her powers get transferred to Ichigo. Without her abilities, she is unable to return to the Soul Society and is forced to inhabit a gigai, or temporary body...(<a href="?page=information/bios/rukia">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <h1 align="center"><font face="Verdana" size="2">Kurosaki, Ichigo</font></h1>
          </td>
        </tr>
        <tr>
          <td width="21%">
            <p align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Ichigo.jpg" alt="" width="50" height="50" /></font></p></td>
          <td width="14%"></td>
          <td width="65%"><font face="Verdana" size="1">The main character of Bleach is Kurosaki, Ichigo. The series is named after Ichigo�s trademark�and natural�&quot;Bleach&quot; blond hair. However, as a consequence of the outrageous coloring of his hair, he is constantly badgered by adults, who stereotype him as a punk, and other teenagers who think he�s copying their own bleached hair...(<a href="?page=information/bios/ichigo">read more</a>)</font></td>
        </tr>
        <tr>
          <td width="100%" colspan="3">
            <hr width="500" noshade size="1" color="#000000">
          </td>
        </tr>
      </table>
      <p align="center"><font size="1" face="Verdana"><br />
      <br />
      <br />
      <br />
      </font></td>
  </tr>
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1">|<a href="?page=information/bios/0-9">#-9</a>|
      |<a href="?page=information/bios/a-h">A-H</a>| |<a href="?page=information/bios/i-q">I-Q</a>|
      |<a href="?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
</table></font>