<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Kon</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kon</b></font><font face="Verdana" size="1"><br />
<br />
<i>(No Personal Information Provided)</i><br />
<br />
Kon is a mod konpaku, or mod soul. Mod souls were originally created to possess dead bodies and fight hollows, however the project was scrapped after some shinigami felt this was unsightly. Mod souls were ordered to be destroyed, but one survived in the form of a small pill-sized ball. Mod souls can enhance an aspect of whatever body they possess, and Kon is no exception. He is an underpod, a mod soul who can enhance leg strength.<br />
<br />
Kon waited day after day for his destruction, but he somehow ended up in some &quot;Soul Candy.&quot; This is how he comes to possess Ichigo�s body for the first time. Knowing that his life is marked, Kon refuses to kill anything and merely wants to live his life. Urahara was going to destroy him, but Rukia took him instead. Rukia and Ichigo searched for a suitable host, and they finally decided on a stuffed bear. Kon has great affection for Rukia, calling her &quot;sister&quot; and declaring himself her disciple. He has a great dislike for Ichigo however.<br />
<br />
Kon has a very fun-loving and relaxed personality. He is particularly attracted to girls, the bustier the better. He has very sensitive feelings though, and even goes so far as to leave Rukia and Ichigo when he feels they do not appreciate him. Kon ran into Orihime, got tossed around by three other girls in Ichigo and Rukia�s class, was chased by Chad, and was finally captured by Yuzu. He eventually returned to Ichigo's room a
much happier bear.<br />
<br />
Kon is often used to possess Ichigo's body while Ichigo is a shinigami. He dislikes doing this though because he finds that Ichigo is too serious. It's difficult for Kon to be that unhappy and worried for so long. When Rukia leaves for the Soul Society, she ties Kon up behind the toilet. Kon manages to interpret Rukia�s coded letter to Ichigo and explain that it must mean Soul Society trouble. Kon is currently playing Ichigo in the living world while Ichigo goes to rescue Rukia.</font>