<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Tatsuki, Arisawa</b><br />
<br />
</font><font face="Verdana" size="2"><b>Tatsuki, Arisawa</b></font><font face="Verdana" size="1"><br />
<br />
Weight: 41 kg<br />
Blood Type: AO<br />
DOB: July 17<br />
<br />
- Karate Club, black belt<br />
- Has known Ichigo since they were 4<br />
- Likes shorts and cargo pants<br />
- Student monitor<br />
- Doesn't feel her name looks cute in Kanji, so when she signs her name, she writes it in Hiragana<br />
- Favorite food: Apple pie<br />
- Theme song: &quot;The Blue Bird No Longer Flies&quot; - H&aacute;l<br />
<br />
More as a background character, Tatsuki is popular because of her renowned fighting techniques and absolute loyalty to Orihime. Had she not had been hit by a car during the semi-finals of the Japanese high school karate tournament, she would have most likely have won first place, but was stuck with runner up and a broken arm. Her reaction to most people is a punch in the stomach or a swift roundhouse kick to the head, but when she's not in the fighting spirit, she is hanging out with Orihime.<br />
<br />
Her relationship with Ichigo goes far back when they met in a karate dojo when they were both 4 years old. She explains to Orihime, upon request, about how she used to beat him all the time and was the first one to ever make him cry. Although she was tough on him back then, it helped him build a callous to all of the other fights that he would engage in as he grew older and was harassed about the color of his hair. Her knowledge of Ichigo and his family is sapped by Orihime when she asks about their tradition of visiting the Kurosaki grave site each year. Even though she has known Ichigo longer, she is closer friends with Orihime mainly due to the fact that her parents refuse to let her go anywhere without supervision if there will be boys and also due to the fact of how they first met. When Orihime was teased, held down, and marred because of her long, beautiful hair, Tatsuki yelled at her for not standing up for herself and accepting that her hair would be short only because others were jealous. Since she couldn't stand up for herself, Tatsuki beat up every single person that ever made Orihime cry and prides herself on this part of their relationship. Orihime knows that she can trust Tatsuki with her life, which is just what happened when they were attacked by a hollow at the school.<br />
<br />
The hollow that spawned at Karakura High School was honed in for Orihime until Tatsuki stepped up and entered the fight. This particular hollow's power was the ability to posses other people with large seeds and control their movement, but this didn't deter Tatsuki from kicking ass. She destroyed the first drove of possessed students easily with her fists and feet, but when the second, larger drove consumed her, the hollow gave her three choices: suicide by hanging after the school boys rape her in turns, suicide by cutting the rope after stripping naked and hanging from the roof, or one way to die of her own choosing. Nonchalantly, she commanded him to shut up and continued the fight despite the seed jutting from her left shoulder. Disliking this rebellion, the hollow shoots a seed which penetrates her forehead, and, as she falls dead, Orihime screams in dismay.<br />
<br />
Tatsuki's death cue's Orihime's soul power, which was earlier influenced by Ichigo, and the Shun Shun Rikka are born from her hair clips. Orihime finishes the fight and revives Tatsuki with the aid of the Shun Shun Rikka. Tatsuki lives to fight another day and Orihime lives to travel to Soul Society (Tatsuki thinks that she is staying over her grandmother's house for summer break) and this is more or less where the Tatsuki storyline drops off.<br />
<br />
Her value to the story is to further the relationship between Ichigo and Orihime, reveal background information of both Ichigo and Orihime, and to add comic relief as well. Once she is incorporated into the story once more, there is no doubt that she will be by Orihime's side, delivering her food that her parents have made for her, and laughing as they joke about life on Orihime's bed.<br />
<br />
<br />
(Written by Dimas Pinzon; aka Peurtoroo)</font>