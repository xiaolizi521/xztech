<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Character Biographies &gt; R-Z</b><br />
<br />
</font><font size="2" face="Verdana"><b>Bleach Character Biographies</b></font><font face="Verdana" size="1"><br />
<br /></font>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana">|<a href="index.php?page=information/bios/0-9">#-9</a>| |<a href="index.php?page=information/bios/a-h">A-H</a>| |<a href="index.php?page=information/bios/i-q">I-Q</a>| |<a href="index.php?page=information/bios/r-z">R-Z</a>|</font></td>
	</tr>
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana"><br /></font>
<?PHP
$file_title = 'Bios';
?>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Retsu, Unohana</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Unohana.jpg" alt="Retsu, Unohana" style="width: 50px; height: 50px;" /></font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Unohana Retsu is the leader of the 4th division, known for their remarkable healing prowess. Although they have relatively weak fighting abilities, the 4th division�s healing powers are invaluable to the rest of the Gotei 13; however, the other divisions fail to see that...(<a href="index.php?page=information/bios/unohana">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Ryou, Kuneida</b></font></h1>
					</td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">A student at Kuraku High, Kuneida is a member of the same class as Ichigo and one of the girls in Tatsuki and Orihimes circle of friends. Kuneida is an extremely bright pupil scoring joint highest in her mid-term exams...(<a href="index.php?page=information/bios/kuneida">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Sado, Yasutora (Chad)</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Sado.jpg" alt="Sado, Yasutora (Chad)" style="width: 50px; height: 50px;" /></font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font size="1" face="Verdana">Chad is a large 15-year-old boy who has an apparent affinity for cute, small things. He is extremely strong; he seems relatively unphased when hit by things such as cars and I-beams. He attends Karakura High School and is friends with Ichigo, Kojima, and Asano. He is very intelligent and ranks highly in the class on exams...(<a href="index.php?page=information/bios/sado">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Shiba, Gangyu</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font size="1" face="Verdana">We first meet Shiba Ganjyu as a cocky, flashy fellow who happens to crash through Elder Dono�fs front door in Soul Society. The reason for his unusual entrance was due to him being thrown off the back of his boar. Nevertheless, he regains his composure long enough to see Ichigo in his shingami garb and rips off his glasses...(<a href="index.php?page=information/bios/ganjyushiba">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Shiba, Kuukaku</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font size="1" face="Verdana">If there ever was anyone as badass as her, Kuukaku surely would have killed them by now. Not only does she design her own houses (tacky and gaudy though they may be), she is missing her right arm but can still whoop Ganjyu and Ichigo into compliance. She is part of the Shiba family, and since she is the oldest known member, she is also the First Class Fireworks Master...(<a href="index.php?page=information/bios/kuukakashiba">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Shihouin, Yoruichi</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Yorichi.jpg" alt="Shihouin, Yoruichi" style="width: 50px; height: 50px" /><img border="0" src="information/bios/images/Yorichi2.jpg" alt="Shihouin, Yoruichi" style="width: 50px; height: 50px" /></font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Taking the form of a black cat, Yoruichi is said to be Urahara�s only relative. She first appears to tell Urahara that Renji and Byakuya have arrived, and they both seem to be expecting this. She trains Chad and Orihime and then enters the Soul Society with the group going to rescue Rukia...(<a href="index.php?page=information/bios/yoruichi">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Shun Shun Rikka</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">The Shun Shun Rikka is a unique soul power utilized by Orihime initially to defeat the hollow that killed Tatsuki. This specific soul power is comprised of three teams in the 6 person group, each of which has their own special power. The first group, which consists of Hinagiku, Baigon, and Lily create an outer shield to repel enemy attacks away from the user....(<a href="index.php?page=information/bios/shunshunrikka">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Sousuke, Aizen</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/aizen.jpg" alt="Sousuke, Aizen" style="width: 50px; height: 50px;" /></font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Aizen Sousuke was the much-loved captain of the 5th division. He was known by everyone for his kindness and sympathy. Once, he was even invited to Hitsugaya's &quot;birthday party&quot; to watch fireworks. There, he congratulated Hitsugaya...(<a href="index.php?page=information/bios/aizen">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Tatsuki, Arisawa</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font size="1" face="Verdana">More as a background character, Tatsuki is popular because of her renowned fighting techniques and absolute loyalty to Orihime. Had she not had been hit by a car during the semi-finals of the Japanese high school karate tournament, she would have most likely have won first place, but was stuck with runner up and a broken arm....(<a href="index.php?page=information/bios/arisawatatsuki">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Tsukabishi, Tessai</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1"><img border="0" src="information/bios/images/Tessai.jpg" alt="Tsukabishi, Tessai" style="width: 50px; height: 50px;" /></font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Despite his towering height and rock hard muscles, Tessai is a rather peaceful and contemplative man. His rectangular glasses pique his intellectual ability and his silence speaks louder than his deep voice. But this calm image should be taken with a grain of salt, for, when called into action, Tessai's powerfully broad fists are just as threatening as his large jaw, trio of braids, and the thick mustache connected to his dark sideburns...(<a href="index.php?page=information/bios/tessai">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><b><font face="Verdana" size="2">Ukitake, Jyuushirou</font></b></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Jyuushiro.jpg" alt="Ukitake, Jyuushirou" style="width: 50px; height: 50px;" /></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Not much is known about the 13th division captain. He has a strong relationship with the 8th division commander, Kyouraku Shunsui, as both are the only two whose Ban Kais are in the form of twin swords. He also seems to suffer from an unknown illness when he enters the story, having coughing fits and tiring easily...(<a href="index.php?page=information/bios/jyuushirou">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Urahara, Kisuke</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Urahara.jpg" alt="Urahara, Kisuke" style="width: 50px; height: 50px;" /></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Urahara is the owner of the aptly named Urahara Shouten. Jinta, Ururu, and Tessai are his three employees. Although his shop is in the living world, it is stocked with goods from the Soul Society. Rukia is seen frequenting his shop when in need of supplies. Urahara is very easy going, although he occasionally shows a more serious side. He is always seen wearing geta (wooden sandals) and a striped hat...(<a href="index.php?page=information/bios/urahara">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Yamada, Hanatarou</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Perhaps one of the most overshadowed characters of the series, Hanatarou Yamada is weak of body but strong of heart.&nbsp; He is typically picked on for being a part of the 4th Division, or the weakest division of the Gotei 13.&nbsp; As if being harassed by other divisions wasn't enough, his own division singles him out and he is the brunt of many harsh pranks.&nbsp; His captain is the usual perpetrator of said pranks and sees Hanatarou as a way to vent...(<a href="index.php?page=information/bios/yamadahanatarou">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Yumichika, Ayasegawa</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Ayasegawa.jpg" alt="Yumichika, Ayasegawa" style="width: 50px; height: 50px;" /></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Like all other  members of the 11th Division, Yumichika has a love for fighting for the sake of fighting, and, appropriately, he greatly respects his captain, Kenpachi, and his friend, Ikkaku. Despite this, however, he also has a certain aesthetic sense and slightly narcissistic...(<a href="index.php?page=information/bios/ayasegawa">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Zangetsu/Kitsuki</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><img border="0" src="information/bios/images/Zangetsu.jpg" alt="Zangetsu" style="width: 50px; height: 50px;" /></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">Zangetsu is the physical manifestation of Ichigo�s soul cutter. He serves as a sort of spiritual guide for Ichigo when he is having problems. Zangetsu first appears to keep Ichigo from turning into hollow during his training with Urahara. His appearance is that of a man with long, dark hair. Ichigo recognizes the man as his uncle Kitsuki...(<a href="index.php?page=information/bios/zangetsu">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2"><b>Zennosuke, Kurumandani</b></font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font size="1" face="Verdana">Zennosuke is the current shinigami replacement for Karakura Town and Kuchiki Rukia. He isn't up to date with the current situation and finds himself to be a �ghero without villains to fight. The reason that the hollows are destroyed before he can even get to them is because of the new hollow fighting force called the Karakura Super Heroes...(<a href="index.php?page=information/bios/zennosuki">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
			</table>
			<p align="center"><font size="1" face="Verdana"><br /></font></p></td>
	</tr>
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana">|<a href="index.php?page=information/bios/0-9">#-9</a>| |<a href="index.php?page=information/bios/a-h">A-H</a>| |<a href="index.php?page=information/bios/i-q">I-Q</a>| |<a href="index.php?page=information/bios/r-z">R-Z</a>|</font></td>
	</tr>
</table>