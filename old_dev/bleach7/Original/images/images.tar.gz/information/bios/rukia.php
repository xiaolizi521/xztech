<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Kuchiki, Rukia</b><br />
<br />
</font><font face="Verdana" size="1"><b>Kuchiki, Rukia</b></font><font face="Verdana" size="1"><br />
<br />
Height: 144 cm (4'9&quot;)<br />
Weight: 33 kg (73 lbs)<br />
DOB: January 14<br />
<br />
- Doesn't like tight clothes<br />
- Likes climbing to high places<br />
- Loves rabbits<br />
- Favorite foods are cucumber and shira-tama (although this could grow)<br />
<i>Theme Song:</i> &quot;Wing Stock&quot; by Ashley MacIsaac on &quot;Hi How Are You Today?&quot;<br />
<br />
Rukia is a shinigami from the Soul Society. She first appears in Ichigo's room while chasing a hollow, but when things go wrong her powers get transferred to Ichigo. Without her abilities, she is unable to return to the Soul Society and is forced to inhabit a gigai, or temporary body. Rukia then attends Karakura High School as a member of Ichigo's class. <br />
<br />
Although her exact age is unknown, she tells Ichigo she has lived at least 10 times as long as him. She has various shinigami accoutrements including a cell phone that receives orders from the Soul Society, a device that can alter memories, and a glove that can separate someone's spirit from their body. Despite her long life, Rukia is rather na�ve about many things in modern society (ie juice boxes). She learns current lingual trends from reliable sources such as horror manga. Rukia resided in Ichigo's closet while in the living world.<br />
<br />
While waiting for her abilities to return, Rukia trained Ichigo in the ways of shinigami. According to her, she got top marks in her demon arts classes. Her personality varies depending on whom she is with. In front of her classmates she is demure and polite. When acting in her official capacity as a shinigami however, she is very decisive and assertive. Nothing is remotely shy about her then. With Ichigo, she often switches between wise sage and argumentative adversary at the blink of an eye. Their usual activity is to fight and yell at each other. Despite this, Rukia seems closest to Ichigo, and she shows a great deal of sympathy for him and his feelings.<br />
<br />
When Rukia realizes she is becoming too attached to the living world, she quickly leaves Ichigo to protect him. Her childhood friend Renji and older brother Byakuya soon confront her. They tell her that she is to be executed by the Soul Society. She tries to prevent Ichigo from fighting them. However, when things go wrong for Ichigo, Rukia seemingly turns on him in an effort to protect him from Byakuya. She feels very guilty for dragging him into the situation, and sacrifices herself in an effort to save Ichigo. While in her various holding cells in the Soul Society awaiting her execution, she seems depressed but accepting of her fate.<br />
<br />
A few things are known about her past. As a child, Rukia lived in one of the poorest parts of the Soul Society, area 78 of Rikongai. It was a very rough place to live, and crime was rampant. One day she helped a group of kids keep out of trouble. She became their spiritual leader and inspiration. One of the young men was Renji, and the two of them grew up together. They vowed to become shinigami together, but were separated 40 years prior to her meeting Ichigo by the Kuchiki family. The Kuchiki family was one of the noble families, and it wanted to adopt her. This would allow her to graduate early and become a member of the 13<sup>th</sup> division. She assented and got the family that she and Renji had wanted. Her relationship with her new older brother Byakuya however was rocky at best.<br />
<br />
The Shiba family and Rukia herself feel she is responsible for the death of a fellow shinigami, Shiba Kaien. Rukia held a great deal of affection for Kaien, but he became possessed by a hollow. Rukia was forced to kill him to destroy the hollow. It is pointed out by Byakuya that Kaien and Ichigo share a certain resemblance.<br />
<br />
Rukia holds a great deal of confidence in Ichigo, but she also feels that she has caused him a great deal of pain and changed his life forever. This causes her a great deal of guilt because she feels she can never make it up to him. As her execution begins, her final request is that Ichigo and the others from the living world be allowed to return safely. During the execution itself, her final thought is of Ichigo. When the smoke clears however Ichigo is standing before her, and it appears that Rukia may have just received a stay of execution.</font>