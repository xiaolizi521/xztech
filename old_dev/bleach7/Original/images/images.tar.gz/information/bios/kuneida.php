<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Ryou, Kuneida</b><br />
<br />
</font><font face="Verdana" size="2"><b>Ryou, Kuneida</b></font><font face="Verdana" size="1"><br />
<br />
A student at Kuraku High, Kuneida is a member of the same class as Ichigo and one of the girls in Tatsuki and Orihimes circle of friends. Kuneida is an extremely bright pupil scoring joint highest in her mid-term exams out of all students in the same grade not only this but she is a member of the Kuraku high track team and can run the 100 metres in 12 seconds flat! </font>