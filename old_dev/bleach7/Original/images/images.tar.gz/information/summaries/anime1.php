<b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Anime Summaried</b><br />
<h2><b>Bleach Anime Summaries:</b></h2>
<table cellspacing="0" cellpadding="0" style="border: none; width: 100%;" class="VerdanaSize1Main">
	<tr>
		<td colspan="2" style="width: 100%; text-align: center; ">
			|<a href="?page=information/summaries/anime1">1-10</a>| 
			|<a href="?page=information/summaries/anime2">11-20</a>| 
			|<a href="?page=information/summaries/anime3">21-30</a>| 
			|<a href="?page=information/summaries/anime4">31-40</a>| 
			|<a href="?page=information/summaries/anime5">41-50</a>| 
			|<a href="?page=information/summaries/anime6">51-60</a>| 
			|<a href="?page=information/summaries/anime7">61-70</a>| 
			|<a href="?page=information/summaries/anime8">71-80</a>| 
			|<a href="?page=information/summaries/anime9">81-90</a>| 
			|<a href="?page=information/summaries/anime10">91-100</a>|
			|<a href="?page=information/summaries/anime11">101-110</a>|<br />			<br /></td>
	</tr>
	<tr>
		<td colspan="2" style="text-align: center;">Click the picture next to the short summary to view more screenshots from that episode.</td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=884&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e001" /></td>
		<td><b>Episode 001: </b>Ichigo Kurosaki is a 15 year old boy who can see spirits. As he tries to protect the spirit of a little girl from a hollow, he witnesses a clash between the malevolent spirit and a shinigami. Later, Ichigo is met by the woman again in his room. She introduces herself as Rukia Kuchiki. The hollow returns, attacking Ichigos home, and Rukia is wounded. In order to save his family, Ichigo takes Rukia's power into himself and becomes a shinigami. <b><a href="index.php?page=information/summaries/a001">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=888&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e002" /></td>
		<td><b>Episode 002: </b>After discovering Rukia has enrolled in his class, she reveals to Ichigo that she has lost her power and tells him to stand in as a substitute. Refusing at first, Ichigo eventually accepts the terms after realizing he cant just turn a blind eye if he encounters a hollow. <b><a href="index.php?page=information/summaries/a002">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=900&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e003" /></td>
		<td><b>Episode 003: </b>Ichigo discovers one of his classmate, Orihime Inoue, is stalked by her older brothers spirit turned hollow. As he is forced to use his power again, Ichigo finally submits to his purpose as a substitute shinigami and agrees to take on Rukias shinigami responsibilities. <b><a href="index.php?page=information/summaries/a003">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=907&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e004" /></td>
		<td><b>Episode 004: </b>Ichigo's friend Chad comes into possession of a cursed cockatiel that is inhabited by the soul of a small boy. The curse, which brings misfortune to anyone who possesses it, is really the acts of a hollow that has been stalking the cockatiel/small boy. Chad is attacked by the hollow, but with Rukias help, they face off against the hollow. <b><a href="index.php?page=information/summaries/a004">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=910&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e005" /></td>
		<td><b>Episode 005: </b>With Rukias help, Chad fights the hollow despite not being able to see it. Ichigo eventually arrives and defeats the hollow, but unlike the previous hollows that simply dissolved and went to Soul Society, the gates of Hell appear and capture the hollow. The spirit that inhabited the cockatiel is released to move on to Soul Society. <b><a href="index.php?page=information/summaries/a005">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=1050&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e006" /></td>
		<td><b>Episode 006: </b>In order for Ichigo to transform into a shinigami when Rukia is not around, she purchases some soul candy from the Urahara Sh?ten for him. Little did they realize the candy is actually a modified soul, an artificial warrior from Soul Society created to destroy hollows. Once inside Ichigos body the modified soul goes on a rampage, ruining Ichigos social image.<b><a href="index.php?page=information/summaries/a006">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=1053&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e007" /></td>
		<td><b>Episode 007: </b>Ichigo confronts the modified soul possessing his body, but is then distracted by an emerging hollow. Together, they defeat the hollow. When Kisuke Urahara comes for the &quot;defective&quot; merchandise, Ichigo takes the modified soul back. He places the modified soul into a stuffed lion plushie and names it &quot;Kon&quot;. In Soul Society, another shinigami is sent to track down Rukia, who has exceeded the time limit in the human world. <b><a href="index.php?page=information/summaries/a007">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=1056&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e008" /></td>
		<td><b>Episode 008: </b>Ichigo and his family visit their mothers grave on the anniversary of her death. While there, the shinigami sent for Rukia attacks them because she broke Soul Society law by giving him her powers. The battle halts when Ichigos sisters Karin and Yuzu are attacked by a hollow. <b><a href="index.php?page=information/summaries/a008">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&amp;g2_itemId=1059&amp;g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e009" /></td>
		<td><b>Episode 009: </b>Ichigo confronts the hollow, who is revealed as the Grand Fisher, the hollow who killed Ichigos mother. Ichigo defeats the hollow, but does not manage to kill it. The shinigami sent after Rukia gives up his search when he witnesses Ichigos strength. <b><a href="index.php?page=information/summaries/a009">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td width="130">
			<img src="http://gallery.bleach7.com/main.php?g2_view=core.DownloadItem&g2_itemId=2306&g2_serialNumber=1" style="text-align: left;" width="128" height="96" alt="e010" /></td>
		<td><b>Episode 010: </b>When popular TV star/spirit medium Don Kanonji transforms a spirit into a hollow during an exorcism, Ichigo is forced to clean up the mess. Upon the hollows defeat, Kanonji is shocked to realize what he has done. With a little cheer-up from Ichigo, Kanonji is back to his old self again, and calls Ichigo (to his objection) his new apprentice. <b><a href="index.php?page=information/summaries/a010">Read Full Summary</a></b></td>
	</tr>
	<tr>
		<td colspan="2"><br />
		<hr />
		<br /></td>
	</tr>
	<tr>
		<td colspan="2" style="width: 100%; text-align: center;">
			|<a href="?page=information/summaries/anime1">1-10</a>| 
			|<a href="?page=information/summaries/anime2">11-20</a>| 
			|<a href="?page=information/summaries/anime3">21-30</a>| 
			|<a href="?page=information/summaries/anime4">31-40</a>| 
			|<a href="?page=information/summaries/anime5">41-50</a>| 
			|<a href="?page=information/summaries/anime6">51-60</a>| <br />
			|<a href="?page=information/summaries/anime7">61-70</a>| 
			|<a href="?page=information/summaries/anime8">71-80</a>| 
			|<a href="?page=information/summaries/anime9">81-90</a>| 
			|<a href="?page=information/summaries/anime10">91-100</a>|
			|<a href="?page=information/summaries/anime11">101-110</a>|</td>
	</tr>
</table>
