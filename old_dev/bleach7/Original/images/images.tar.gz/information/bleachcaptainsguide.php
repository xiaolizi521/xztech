<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br /><b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou Guide</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Zanpaktou Guide</b><br />
<br />
<b>This site is divided between the anime section and the manga section.</b><br />
<br />
Anime section is up to the latest episode and it does not contain any additional spoilers from the manga. Manga section is up to the latest manga chapter and it contains major spoilers.<br> If you are an anime watcher then do not visit the manga section since information there hasn�t been introduced yet in the anime.<br />
<br /></span>
<table id="captain" cellspacing="6" cellpadding="4">
	<tr>
		<td class="captainmain">
			
      <div align="center"><a href="?page=information/guide/animeindex"><span class="CaptainVeranda3"><b><font size="3">Anime 
        Section</font></b></span><br />
				<span class="Veranda1Red">Contains slight spoilers. (Up to the latest non-filler episode)<br />
				<br /></span>
				<img src="/information/guide/animeichigo.jpg" alt="" width="217" height="217" border="0" /></a></b></font>
			</div></td>
		<td class="mangamainbreak1"></td>
		<td class="captainmain">
			
      <div align="center"><a href="?page=information/guide/mangaindex"><span class="CaptainVeranda3"><b><font size="3">Manga 
        Section</font></b></span><br />
				<span class="Veranda1Red">Contains heavy spoilers (Up to the latest chapter).<br />
				<br /></span>
				<img src="/information/guide/mangaichigo.jpg" alt="" width="217" height="217" border="0" /></a></b></font>
			</div></td>
	</tr>
</table>
<p>
 
  
  <br>
  <font size="2">Last updated:<Br>
  </font><font size="1">- <A href="http://www.bleach7.com/?page=information/guide/mangaothers/Visored">Visored Guide</a><Br>
  - <A href="http://www.bleach7.com/?page=information/guide/mangaothers/Arankaru">Arrancar Guide</a><Br><Br>
  <br>
  <br>
Any questions, suggestions, mistakes? Send 
  me a <a href="http://bleach7.com/index.php?page=member/pm_compose&to=remekpl">private message</a>.
<Br><br>
  Thanks goes to : <a href="http://forums.narutofan.com/member.php?find=lastposter&t=34942" target="_blank">Utz</a> 
  from NarutoForums.com for writing Anime Captains descriptions, <a href="http://bleach7.com/index.php?page=member/member&id=Kuroyami" target="_blank">Kuroyami</a> 
  and <a href="http://bleach7.com/index.php?page=member/member&id=aznxenocidei" target="_blank">aznxenocide</a> 
  for writing Vice Captains descriptions, <a href="http://www.lunaranime.org/" target="_blank" >Lunar</a> and <a href="http://bleach-society.com" target="_blank" >Bleach 
  Society</a> for their subs, <a href="http://www.maximum7.com" target="_blank" >Manga7</a> and <a href="http://www.manga-rain.com/" target="_blank" >Manga-Rain</a>
  for their manga scantlations.</font><br>
  <br>
  
<Br><script type="text/javascript"><!--
google_ad_client = "pub-3121363681209965";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "F7F6F1";
google_color_bg = "F7F6F1";
google_color_link = "000000";
google_color_url = "336699";
google_color_text = "333333";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>