<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Item Guide</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Item Guide</b></span><span class="VerdanaSize1Main"><br />
<br />
� <a href="#energy"> Enery Pill</a> (also; <a href="#energy2"> Hanatarou's Energy Pill</a>)<br />
� <a href="#eye"> Eye Patch</a><br />
� <a href="#gigai"> Gigai</a><br />
� <a href="#hojikuzai"> Hojikuzai</a><br />
� <a href="#kanon">Kanon Ball</a><br />
� <a href="#kikanshinki"> Kikanshinki</a><br />
� <a href="#memory"> Memory Chikan</a><br />
� <a href="#mod"> Mod Soul</a><br />
� <a href="#safety"> Safety Charm</a><br />
� <a href="#sanre"> Sanre Gloves, The</a><br />
� <a href="#sekkiseki"> Sekkiseki Walls</a><br />
� <a href="#cell"> Shinigami Cell Phone</a><br />
� <a href="#handcuffs"> Shinigami Handcuffs</a><br />
� <a href="#shinten"> Shinten</a><br />
� <a href="#soul"> Soul Candy</a><br />
� <a href="#soumafixers"> Soumafixers</a><br />
� <a href="#teddy"> Teddy Bear</a><br />
� <a href="#tenshintai"> Tenshintai</a><br />
<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
<br />
<a name="energy" id="energy"></a>Energy Pill <br />
&nbsp;A pill designed to reenergize 4<sup>th</sup> Division members.<br />
<br />
- - - - - - - - - -<br />
<a name="energy2" id="energy2"></a>Energy Pill2 (Hanatarou Special)<br />
&nbsp;A pill Hanatarou's senpai gave to him as a prank. This is a different pill than the ones others get. The main ingrediant in this pill is flower.<br />
<br />
- - - - - - - - - -<br />
<a name="eye" id="eye"></a>Eye Patch (Zaraki Kenpachi's)<br />
&nbsp;Sucks out an unlimited amount of energy to suppress the spiritual pressure of the wearer.<br />
<br />
- - - - - - - - - -<br />
<a name="gigai" id="gigai"></a>Gigai<br />
&nbsp;Temporary bodies for shinigamis to use while living in the living world or while thier powers have been taken away.<br />
<br />
- - - - - - - - - -<br />
<a name="hojikuzai" id="hojikuzai"></a>Hojikuzai (Restore Meat Medicine)<br />
&nbsp;Heals any body part that may have been lost or injured in battle.<br />
<br />
- - - - - - - - - -<br />
<a name="kanon" id="kanon"></a>Kanon Ball <br />
&nbsp;A ball of spiritual energy created by Don Kanonji.<br />
<br />
- - - - - - - - - -<br />
<a name="kikanshinki" id="kikanshinki"></a>Kikanshinki<br />
&nbsp;Information unknown.<br />
<br />
- - - - - - - - - -<br />
<a name="memory" id="memory"></a>Memory Chikan<br />
&nbsp;With a small spark it replaces the memory of a being with ordinary daily memories to fill in for the ones taken out.<br />
<br />
- - - - - - - - - -<br />
<a name="mod" id="mod"></a>Mod-Soul<br />
&nbsp;Artificial souls created to fight hollows. These mod-souls would use the bodies of deseaced humans. Mod-souls each had improved powers such as arm strength, leg strength, etc. Mod-souls were destroyed because a council of shinigami ruled them as immoral.Kon was one of the very few mod-souls to survive.<br />
<br />
- - - - - - - - - -<br />
<a name="safety" id="safety"></a>Safety Charm<br />
&nbsp;A small token on a string given to Ichigo by his father before he leaves to go to the Soul Society. It was a lucky charm that his mother wore.<br />
<br />
- - - - - - - - - -<br />
<a name="sanre" id="sanre"></a>The Sanre Gloves <br />
&nbsp;A quincy artifact. After training for seven days and seven nights with this glove on, a Quincy will reach the limit of his powers. If the quincy takes off the glove after training, he would gain a huge surge of power for a short period of time. After this power surge the Quincy would lose his powers forever.<br />
<br />
- - - - - - - - - -<br />
<a name="sekkeseki" id="sekkeseki"></a>Sekkiseki Walls<br />
&nbsp;Walls that block out Spiritrons and spiritual pressure. These walls are often used in Soul Society prisions.<br />
<br />
- - - - - - - - - -<br />
<a name="shinten" id="shinten"></a>Shinten <br />
&nbsp;One drop of this tranquilizer on the unprotected skin of someone with low spiritual pressure will cause them to faint.<br />
<br />
- - - - - - - - - -<br />
<a name="cell" id="cell"></a>Shinigami Cell Phone<br />
&nbsp;Used to recieve orders or to pinpoint the location of hollows.<br />
<br />
- - - - - - - - - -<br />
<a name="handcuffs" id="handcuffs"></a>Shinigami Handcuffs<br />
&nbsp;Seals the spiritual power of the user.<br />
<br />
- - - - - - - - - -<br />
<a name="soul" id="soul"></a>Soul Candy<br />
&nbsp;A small candy that replaces the soul of the user with a soul that will take care of the body while the users soul is allowed to roam.<br />
<br />
- - - - - - - - - -<br />
<a name="soumafixers" id="soumafixers"></a>Soumafixers<br />
&nbsp;Are used to syncronize Rurika with her Gigai.<br />
<br />
- - - - - - - - - -<br />
<a name="teddy" id="teddy"></a>Teddy Bear <br />
&nbsp;Used to house the soul of Kon, a mod-soul.<br />
<br />
- - - - - - - - - -<br />
<a name="tenshintai" id="tenshintai"></a>Tenshintai<br />
&nbsp;A life-size doll that can draw out the soul of a soul cutter into the realm the user is inhabiting.</span>