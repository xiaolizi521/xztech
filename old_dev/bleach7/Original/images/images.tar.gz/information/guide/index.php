
<br /><span class="VerdanaSize2Main"><b>Bleach Captain & Vice Captain Zanpaktou Guide</b></span></span><span class="VerdanaSize1Main"></span>
<br />
<br />
<br />
<b>This site is divided between the anime section and the manga section. 
Anime section is up to the latest episode and it does not contain any additional spoilers from the the manga.
Manga section is up to the latest manga chapter and it contains major spoilers.
If you are an anime watcher then do not visit the manga section since information there haven't been introduced yet in the anime.<br /><br>
<br />
</span><font size=3 color=red><b>Lastest update for manga readers<font size=1><br />
(highlight to read the spoilers):</b></span> <span class="VerdanaSize1Main">War between Visored, Arankuru, Soul Society and the rest in the manga section.</span>
<br /></span>
<table BGCOLOR=black width="65%" border="0" cellspacing="6" cellpadding="4">
	<tr>&nbsp;
	</tr>
	<tr>
		<td width="45%"><div align="center"><b><a href="animeindex.php"><font size=3>Anime Section</font><br><font size=1>Anime section is updated every Tuesday/Wednesday.</font><br><br><img src="animeichigo.jpg" border="0"></a></div></font></td></b>
		<td width="45%"><div align="center"><b><a href="mangaindex.php"><font size=3>Manga Section<br><font size=1>Contains heavy spoilers (Up to the latest chapter).</font><br><br><img src="mangaichigo.jpg" border="0"></a></font></div></td></b>
	</tr>
</table>
<span class="VerdanaSize1Main"><br />
<br />
Thanks for <a href="http://en.wikipedia.org/wiki/Kubo_Tite" target="_blank" >Kubo Tite</a> for making this masterpiece.<br />
Also I would like you to thank to <a href="http://www.lunaranime.org/" target="_blank" >Lunar</a> and <a href="http://bleach-society.com" target="_blank" >Bleach Society</a> for their subs, as well as <a href="http://www.manga-rain.com/" target="_blank" >Manga-Rain</a> and <a href="http://www.bleachportal.net/bleach/multimedia/direct_manga" target="_blank" >Silhouette</a> for their manga scantlations.<br />
<br />
Latest update: September 16th, 2005. If you would like to contact me: <a href="http://bleach7.com/index.php?page=member/pm_compose&to=remekpl">send a private message</a><br />