<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou&gt; Manga &gt; Captain</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Manga Captain's Zanpaktou Section</b></span><span class="VerdanaSize1Main"> 
<br />
<p><span class="VerdanaSize2Main"><b>This section contains information that has been shown in the manga.</b></span><br />
<span class="VerdanaSize1Main">Hint: Shikai is the  Initial Zanpaktou release, and Ban Kai is the Final Zanpaktou release.</span><span class="Veranda2Redl"><br />
<br />
<b>Click on the Zanpaktous name, Shikai or Bankai name to view the picture.</b></span></p>
<span class="VerdanaSize1Main">&nbsp;'????' means that there is a picture, but the name wasn't revealed yet.<br />
<br /></span>
<table width="483" border=0 cellpadding=2 cellspacing=5 align="center">
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m01"><font size="2"><img src="/information/guide/division/1.jpg" alt="Division 1" border="0" /><span class="CaptainVeranda2"><b> 
      Yamamoto Genryuusai</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/m08"><font size="2"><img src="/information/guide/division/8.jpg" alt="Division 8" border="0" /><span class="CaptainVeranda2"><b> 
      Kyouraku Shunsui</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m02"><font size="2"><img src="/information/guide/division/2.jpg" alt="Division 2" border="0" /><span class="CaptainVeranda2"><b> 
      Soi Fong</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/m09"><font size="2"><img src="/information/guide/division/9.jpg" alt="Division 9" border="0" /><span class="CaptainVeranda2"><b> 
      ??????</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m03"><font size="2"><img src="/information/guide/division/3.jpg" alt="Division 3" border="0" /><span class="CaptainVeranda2"><b> 
      ??????</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/m10"><font size="2"><img src="/information/guide/division/10.jpg" alt="Division 10" border="0" /><span class="CaptainVeranda2"><b> 
      Hitsugaya Toushirou</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m04"><font size="2"><img src="/information/guide/division/4.jpg" alt="Division 4" border="0" /><span class="CaptainVeranda2"><b> 
      Unohana Retsu</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/m11"><font size="2"><img src="/information/guide/division/11.jpg" alt="Division 11" border="0" /><span class="CaptainVeranda2"><b> 
      Zaraki Kenpachi</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m05"><font size="2"><img src="/information/guide/division/5.jpg" alt="Division 5" border="0" /><span class="CaptainVeranda2"><b> 
      ??????</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/m12"><font size="2"><img src="/information/guide/division/12.jpg" alt="Division 12" border="0" /><span class="CaptainVeranda2"><b> 
      Kurotshuchi Mayuri</b></span></font></a>
    <td> 
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m06"><font size="2"><img src="/information/guide/division/6.jpg" alt="Division 6" border="0" /><span class="CaptainVeranda2"><b> 
      Kuchiki Byakuya</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/m13"><font size="2"><img src="/information/guide/division/13.jpg" alt="Division 13" border="0" /><span class="CaptainVeranda2"><b> 
      Ukitake Jyuushiro</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangacaptains/m07"><font size="2"><img src="/information/guide/division/7.jpg" alt="Division 7" border="0" /><span class="CaptainVeranda2"><b> 
      Komamura Sajin</b></span></font></a></td>
    <td><a href="?page=information/guide/mangacaptains/mprevious"><font size="2"><img src="/information/guide/base1.jpg" alt="Division None" border="0" /><span class="CaptainVeranda2"><b> 
      Previous Captains</b></span></font></a></td>
  </tr>
</table>
<br />
<br />
<br />
<p align="center"><span class="CaptainVeranda3c"><a href="javascript:history.back();">&lt;- Go back</a><br /></span>
<span class="VerdanaSize2"><a href="?page=information/guide/animeindex"><b>Anime Section</b></a> | <a href="?page=information/guide/mangaindex"><b>Manga Section</b></a></span></p>