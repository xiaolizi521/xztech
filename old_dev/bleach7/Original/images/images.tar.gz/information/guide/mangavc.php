<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou&gt; Manga &gt; Vice Captain</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Manga Vice Captain's Zanpaktou Section</b></span><span class="VerdanaSize1Main"> 
<br />
<p><span class="VerdanaSize2Main"><b>This section contains information that has been shown in the manga.</b></span><br />
<span class="VerdanaSize1Main">Hint: Shikai is the  Initial Zanpaktou release, and Ban Kai is the Final Zanpaktou release.</span><span class="Veranda2Redl"><br />
<br />
<b>Click on the Zanpaktous name, Shikai or Bankai name to view the picture.</b></span></p>
<span class="VerdanaSize1Main">&nbsp;'????' means that there is a picture, but the name wasn't revealed yet.<br />
<br />
</span> 
<table width="483" border=0 cellpadding=2 cellspacing=5 align="center">
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m01"><font size="2"><img src="/information/guide/division/1.jpg" alt="Division 1" border="0" /><span class="CaptainVeranda2"><b> 
      Sasakibe Choutarou</b></span></font></a></td>
    <td><a href="?page=information/guide/mangavicecaptains/m08"><font size="2"><img src="/information/guide/division/8.jpg" alt="Division 8" border="0" /><span class="CaptainVeranda2"><b> 
      Ise Nanao</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m02"><font size="2"><img src="/information/guide/division/2.jpg" alt="Division 2" border="0" /><span class="CaptainVeranda2"><b> 
      Oomaeda Marechiyo</b></span></font></a></td>
    <td><a href="?page=information/guide/mangavicecaptains/m09"><font size="2"><img src="/information/guide/division/9.jpg" alt="Division 9" border="0" /><span class="CaptainVeranda2"><b> 
      Hisagi Shuuhei</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m03"><font size="2"><img src="/information/guide/division/3.jpg" alt="Division 3" border="0" /><span class="CaptainVeranda2"><b> 
      Kira Izuru</b></span></font></a></td>
    <td><a href="?page=information/guide/mangavicecaptains/m10"><font size="2"><img src="/information/guide/division/10.jpg" alt="Division 10" border="0" /><span class="CaptainVeranda2"><b> 
      Matsumoto Rangiku</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m04"><font size="2"><img src="/information/guide/division/4.jpg" alt="Division 4" border="0" /><span class="CaptainVeranda2"><b> 
      Koutestu Isane</b></span></font></a></td>
    <td><a href="?page=information/guide/mangavicecaptains/m11"><font size="2"><img src="/information/guide/division/11.jpg" alt="Division 11" border="0" /><span class="CaptainVeranda2"><b> 
      Kusajika Yachiru</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m05"><font size="2"><img src="/information/guide/division/5.jpg" alt="Division 5" border="0" /><span class="CaptainVeranda2"><b> 
      Hinamori Momo</b></span></font></a></td>
    <td><a href="?page=information/guide/mangavicecaptains/m12"><font size="2"><img src="/information/guide/division/12.jpg" alt="Division 12" border="0" /><span class="CaptainVeranda2"><b> 
      Kurotshuchi Nemu</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m06"><font size="2"><img src="/information/guide/division/6.jpg" alt="Division 6" border="0" /><span class="CaptainVeranda2"><b> 
      Abarai Renji</b></span></font></a></td>
    <td><a href="?page=information/guide/mangavicecaptains/m13"><font size="2"><img src="/information/guide/division/13.jpg" alt="Division 13" border="0" /><span class="CaptainVeranda2"><b> 
      Shiba Kaien (deceased)</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangavicecaptains/m07"><font size="2"><img src="/information/guide/division/7.jpg" alt="Division 7" border="0" /><span class="CaptainVeranda2"><b> 
      Iba Tetsuzaemon</b></span></font></a></td>
  </tr>
</table>
<p align="center"><span class="CaptainVeranda3c"><a href="javascript:history.back();"><- Go back</a></span><br />
<span class="VerdanaSize2"><a href="?page=information/guide/animeindex"><b>Anime Section</b></a> | <a href="?page=information/guide/mangaindex"><b>Manga Section</b></a></span></p>