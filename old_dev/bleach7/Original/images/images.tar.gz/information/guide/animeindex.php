<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou &gt; Anime</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Anime Zanpaktou Guide</b></span><span class="VerdanaSize1Main"><br />
<br />
<br />
This section is divided between the Captain, the Vice Captain and the other Shinigamis 
guides.<br />
This sections does not contain any additional spoilers from the manga.
<br /></span>
<table cellspacing="6" cellpadding="4" id="mangacaptain">
	<tr>&nbsp; </tr>
	<tr>
		<td>
			
      <div align="center"><a href="?page=information/guide/anime"><b><font size="3"> 
        Captain Guide</font></b><br />
				
				<img src="/information/guide/anime.jpg" alt="" class="mangamain" border="0"></a>
			</div></td>
		
		<td>
			
      <div align="center"><a href="?page=information/guide/animevc"><font size="3"><b>Vice 
        Captain Guide</b><br />
        </font><img src="/information/guide/animevc.jpg" alt="" class="mangamain" border="0"></a> 
      </div>
    </td>
        </tr>
</table>
<center>
	
<p><a href="?page=information/guide/other"><font size="3"><b>Other 
  Shinigamis and their Zanpaktous</b></font><Br>
 <a href="?page=information/guide/other"><img src="/information/guide/other.jpg" alt="" class="mangamain" border="0"></a>
<br />
<br />
<span class="VerdanaSize2Main"><a href="?page=information/bleachcaptainsguide"><- Go back</a></span></p>
<script type="text/javascript"><!--
google_ad_client = "pub-3121363681209965";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "B0E0E6";
google_color_bg = "FFFFFF";
google_color_link = "000000";
google_color_url = "336699";
google_color_text = "333333";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>