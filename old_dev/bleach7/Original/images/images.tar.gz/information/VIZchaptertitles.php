<br />
<span class="VerdanaSize1Main"><b>Bleach7 &gt; Information &gt; Bleach Manga Guide &gt; Viz Chapter Titles</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach VIZ Manga Chapter Titles:</b></span><span class="VerdanaSize1Main"><br />
<br />
<?php
$VIZChapter_sql = mysql_query ( "SELECT `c`.`cid` , `c`.`volume` , `c`.`cVIZtitle` , `v`.`vid` , `v`.`vVIZtitle` FROM chapter_info c, volume_info v WHERE ( ( `c`.`volume` = `v`.`vid` ) AND ( `c`.`cVIZtitle` != \"\" ) ) ORDER BY `c`.`cid` ASC" );
$count = 1;
while ( $show_VIZChapter = mysql_fetch_array ( $VIZChapter_sql ) ) {
	$chapter_title = htmlentities  ( $show_VIZChapter['cVIZtitle'], ENT_QUOTES, ISO-8859-15 );
	$chapter_title = html_entity_decode ( $chapter_title );

	// Place zero's for volume numbers
	if ( $show_VIZChapter['vid'] < 10 ) {
		$volume_numb = "0".stripslashes ( $show_VIZChapter['vid'] );
	}
	else {
		$volume_numb = $show_VIZChapter['vid'];
	}

	// Place zero's for chapter numbers
	if ( $show_VIZChapter['cid'] >= 100 ) {
		$chapter_numb = $show_VIZChapter['cid'];
	}
	elseif ( $show_VIZChapter['cid'] >= 10 ) {
		$chapter_numb = "0".stripslashes ( $show_VIZChapter['cid'] );
	}
	else {
		$chapter_numb = "00".stripslashes ( $show_VIZChapter['cid'] );
	}

	// Display first grouping
	if ( $count == 1 ) {
		$volume = $show_VIZChapter['vid'];
		echo "<b>Volume $volume_numb: $show_VIZChapter[vVIZtitle]</b><br />
<br />
";
		$count++;
	}

	// if a new set of chapters in a volume
	// display chapter info
	// else start new volume grouping
	if ( $volume == $show_VIZChapter['vid'] ) {
		echo "$chapter_numb. $chapter_title<br />
";
	}
	else {
		$volume = $show_VIZChapter['vid'];
		echo "<br />
<b>Volume $volume_numb: $show_VIZChapter[vVIZtitle]</b><br />
<br />
$chapter_numb. $chapter_title<br />
";
	}
}
echo "</span>";
if ( $user_info['type'] == 20 || $user_info['type'] == 21 || $user_info['type'] >= 80 ) {
?>
<span class="VerdanaSize1Main"><br /></span>
<fieldset>
<legend class="main">VIZ Chapter Title Edit Section</legend>
	<form name="VIZChapterTitles_submit" method="post" action="?page=information/info">
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
			  <td style="width: 33%;"><label><input type="radio" name="VIZChapter_edit" value="add" checked />Add</label></td>
				<td style="width: 33%;"><label><input type="radio" name="VIZChapter_edit" value="edit" />Edit</label></td>
			  <td style="width: 34%;"><label><input type="radio" name="VIZChapter_edit" value="delete" />Delete</label></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
			  <td style="width: 50%;"><label><input type="radio" name="VIZChapter_type" value="chapter" checked />Chapter</label></td>
				<td style="width: 50%;"><label><input type="radio" name="VIZChapter_type" value="volume" />Volume</label></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td style="width: 23%">Chapter Number</td> 
				<td style="width: 10%"><input name="cid" type="text" maxlength="4" style="width: 30px;" /></td>
				<td style="width: 17%">Chapter Title</td>
				<td style="width: 50%"><input name="ctitle" type="text" style="width: 95%;" /></td>
			</tr>
			<tr>
				<td style="width: 23%">Volume Number</td>
				<td style="width: 10%"><input name="vid" type="text" maxlength="3" style="width: 30px;" /></td>
				<td style="width: 17%">Volume Title</td>
				<td style="width: 50%"><input name="vtitle" type="text" style="width: 95%;" /></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td align="center"><input type="submit" value="Submit Changes" name="VIZChapterTitles_submit" class="form" /></td>
			</tr>
		</table>
	</form>
</fieldset>
<?php
}
?>