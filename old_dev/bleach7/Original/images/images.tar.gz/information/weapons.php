<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Weapons</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Weapons List:</b> </span><span class="VerdanaSize1Main"><b>[Last Updated: 10/01/05]</b><br />
<br />
� <a href="?page=information/cane">Cane</a>, (Urahara's)<br />
� <a href="?page=information/demonarts"> Demon Arts</a><br />
� <a href="?page=information/leechbombs">Leech Bombs</a><br />
� <a href="?page=information/skullglove">Skull Glove</a>, (Rukia's)<br />
� <a href="?page=information/soulcutters"> Soul Cutters</a></span>