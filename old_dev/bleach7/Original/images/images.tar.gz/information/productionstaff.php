
<br /><b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Production Staff</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>The BleachTV Production Staff:</b></span><span class="VerdanaSize1Main"><br />
<br />
� Director: Abe Noriyuki<br />
� Series Adaption: Sogo Masashi<br />
� Character Design: Kudou Masashi<br />
� Art Director: Takagi Sawako<br />
� Art: Studio Whies<br />
� Color Layout: Kamitani Hideo<br />
� Film Director: Fukushima Toshiyuki<br />
� Filming: T2 Studio<br />
� Editing: Uematsu Junichi<br />
� Recording Studio: Seion Studio<br />
� Sound Production: Zakku Promotion<br />
� Music: Sagisu Shirou