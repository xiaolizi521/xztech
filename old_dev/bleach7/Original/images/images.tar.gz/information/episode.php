﻿<?php

if ( isset ( $_GET[xml] ) && !empty ( $_GET[xml] ) ) {
	$xml = $_GET[xml];
}
else {
	die ('Must contain the section of the xml file you want to view.');
}

$current = "";
$episode_id = "";

//////////////////////////////////////
//		Bleach Episode Titles		//
//////////////////////////////////////

// Change starting tag information
function start_title ( $parser, $name, $attribs ) {
	global $current;
	global $episode_id;
	$current = $name;
	switch ( strtolower ( $name ) ) {
		case 'episode':
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower( $key ) ) {
						case 'id':
							if ( $val < 10 ) {
								$val = '00' . $val;
							}
							else if ( $val < 100 ) {
								$val = '0' . $val;
							}
							$episode_id = $val;
							break;
					}
				}
			}
			break;
		case 'jptitle':
			echo $episode_id, '. ';
			break;
		case 'romanji':
			echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
			break;
		case 'kanji':
			echo '&#12300;';
			break;
	}
}

// Change ending tag information
function end_title ( $parser, $name ) {
	switch ( strtolower ( $name ) ) {
		case 'jptitle':
			echo '<br />
';
			break;
		case 'romanji':
			echo ' ';
			break;
		case 'kanji';
			echo '&#12301;<br />
<br />
';
			break;
	}
}

// Display the contents within the tags
function tag_title ( $parser, $data ) {
	global $current;
	switch ( strtolower ( $current ) ) {
		case 'jptitle':
		case 'romanji':
		case 'kanji':
			$data = html_entity_decode ( $data, ENT_QUOTES, 'EUC-JP' );
			echo $data;
			break;
	}
}	


//////////////////////////////////////
//		Bleach Tokyo-TV Times		//
//////////////////////////////////////

// Change starting tag information
function start_jpdate ( $parser, $name, $attribs ) {
	global $current;
	global $episode_id;
	$current = $name;
	switch ( strtolower ( $name ) ) {
		case 'episode':
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower( $key ) ) {
						case 'id':
							if ( $val < 10 ) {
								$val = '00' . $val;
							}
							else if ( $val < 100 ) {
								$val = '0' . $val;
							}
							$episode_id = $val;
							break;
					}
				}
			}
			break;
		case 'jpdate':
			echo '&#187; TV Tokyo Episode ', $episode_id, '. ';
			break;
	}
}

// Change ending tag information
function end_jpdate ( $parser, $name ) {
	switch ( strtolower ( $name ) ) {
		case 'jpdate':
			echo '<br />
';
			break;
	}
}

// Display the contents within the tags
function tag_jpdate ( $parser, $data ) {
	global $current;
	switch ( strtolower ( $current ) ) {
		case 'jpdate':
			$time = strtotime ( $data );
			$time = date ( 'F dS, Y', $time );
			echo $data;
			break;
	}
}	


//////////////////////////////////////
//		Bleach Canada YTV Times		//
//////////////////////////////////////

// Change starting tag information
function start_ytvdate ( $parser, $name, $attribs ) {
	global $current;
	global $episode_id;
	$current = $name;
	switch ( strtolower ( $name ) ) {
		case 'episode':
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower( $key ) ) {
						case 'id':
							if ( $val < 10 ) {
								$val = '00' . $val;
							}
							else if ( $val < 100 ) {
								$val = '0' . $val;
							}
							$episode_id = $val;
							break;
					}
				}
			}
			break;
		case 'ytvdate':
			echo '&#187; YTV Episode ', $episode_id, '. ';
			break;
	}
}

// Change ending tag information
function end_ytvdate ( $parser, $name ) {
	switch ( strtolower ( $name ) ) {
		case 'ytvdate':
			echo '<br />
';
			break;
	}
}

// Display the contents within the tags
function tag_ytvdate ( $parser, $data ) {
	global $current;
	switch ( strtolower ( $current ) ) {
		case 'ytvdate':
			echo $data;
			break;
	}
}	

//////////////////////////////////////
//		Bleach Adult Swim Times		//
//////////////////////////////////////

// Change starting tag information
function start_asdate ( $parser, $name, $attribs ) {
	global $current;
	global $episode_id;
	$current = $name;
	switch ( strtolower ( $name ) ) {
		case 'episode':
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower( $key ) ) {
						case 'id':
							if ( $val < 10 ) {
								$val = '00' . $val;
							}
							else if ( $val < 100 ) {
								$val = '0' . $val;
							}
							$episode_id = $val;
							break;
					}
				}
			}
			break;
		case 'asdate':
			echo '&#187; Adult Swim Episode ', $episode_id, '. ';
			break;
	}
}

// Change ending tag information
function end_asdate ( $parser, $name ) {
	switch ( strtolower ( $name ) ) {
		case 'asdate':
			echo '<br />
';
			break;
	}
}

// Display the contents within the tags
function tag_asdate ( $parser, $data ) {
	global $current;
	switch ( strtolower ( $current ) ) {
		case 'asdate':
			echo $data;
			break;
	}
}	

header ( 'Content-Type: text/html; charset=utf-8' );

// Create a new XML Parser
$xmlparser = xml_parser_create ( 'UTF-8' );

if  ( $xml == 'title' ) {
?>
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Episode List</b><br />
<br />
<span class="VerdanaSize2Main"><b>Bleach TV Episode List</b></span><span class="VerdanaSize1Main"><br />
<br />
<?php
		xml_set_element_handler ( $xmlparser, 'start_title', 'end_title' );
		xml_set_character_data_handler ( $xmlparser, 'tag_title' );
}
else if ( $xml == 'jpdate' ) {
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; TokyoTV Show Times</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>TokyoTV Show Times</b></span><span class="VerdanaSize1Main"><br />
<br />
<?php
		xml_set_element_handler ( $xmlparser, 'start_jpdate', 'end_jpdate' );
		xml_set_character_data_handler ( $xmlparser, 'tag_jpdate' );
}
else if ( $xml == 'ytvdate' ) {
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; YTV Show Times</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>YTV Show Times</b></span><span class="VerdanaSize1Main"><br />
<br />
<?php
		xml_set_element_handler ( $xmlparser, 'start_ytvdate', 'end_ytvdate' );
		xml_set_character_data_handler ( $xmlparser, 'tag_ytvdate' );
}
else if ( $xml == 'asdate' ) {
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Adult Swim Show Times</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Adult Swim Show Times</b></span><span class="VerdanaSize1Main"><br />
<br />
<?php
		xml_set_element_handler ( $xmlparser, 'start_asdate', 'end_asdate' );
		xml_set_character_data_handler ( $xmlparser, 'tag_asdate' );
}
else {
		echo 'You have input an invalid xml option.  Please make sure you have the correct xml option is set.';
}

// Run through the tags

// Open XML file
$file = 'information/xml/episode.xml';

$data = file_get_contents ( $file );
xml_parse ( $xmlparser, $data );

xml_parser_free( $xmlparser );
if ( isset ( $user_B7 ) && $user_B7->getEdit_Info() == true ) {
	echo '<br />
<a href="?page=xmledit&amp;sec=information&amp;xml=episode">Edit this XML file.</a>';
}

?>
</span>