<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach the Movie &gt; Staff and Cast</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Staff and Cast</b></span><span class="VerdanaSize1Main"><br />
<br /><b>Staff:</b> <br />
Original Work: Kubo Taito<br />
Director: Abe Noriyuki<br />
Script Writer: Sogo Masashi<br />
Character Design: Kudou Masashi<br />
Music: Sagisu Shirou<br /><br />
<b>Cast:</b> <br />
Kurosaki Ichigo: Morita Masakazu<br />
Kuchiki Rukia: Orikasa Fumiko<br />
Abarai Renji: Itou Kentarou<br />
Kuchiki Byakuya: Okiayu Ryoutarou<br />
Hitsugaya Toushirou: Paku Romi<br />
Senna: Saito Chiwa<br />
Ganryuu: Ebara Masashi<br />
</span>