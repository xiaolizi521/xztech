<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach the Movie &gt; General</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>General Information</b></span><br /><br />
<span class="VerdanaSize1Main">Tagline: Execute Hitsugaya Toushirou!<br />
Release date: December 22, 2007<br />
Distributor: Toho Co., Ltd.<br />
Country of Production: Japan<br />
Language: Japanese<br />
Runtime: 90 minutes<br />
</span>
