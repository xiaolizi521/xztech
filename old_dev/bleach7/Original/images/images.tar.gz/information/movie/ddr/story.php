<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach the Movie &gt; Storyline</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Storyline</b></span><span class="VerdanaSize1Main"><br />
<i>From Wikipedia</i><br />
<br />
When an artifact known as the "King's Seal" is stolen during transport from Soul Society, Hitsugaya Toushirou is assigned to retrieve it. Hitsugaya goes missing after a battle with the thieves, leading Seireitei to suspect him of treachery. They order his immediate capture and execution. Unwilling to believe that he is capable of such a crime, Kurosaki Ichigo, Matsumoto Rangiku, Kuchiki Rukia, and Abarai Renji set out to find Hitsugaya and clear his name. Meanwhile, Hitsugaya is still searching for the thieves, and stumbles upon a dark secret involving a shinigami long since dead.
</span>