<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach the Movie &gt; Staff and Cast</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Staff and Cast</b></span><span class="VerdanaSize1Main"><br />
<br /><b>Staff:</b> <br />
Original Work: Kubo Taito<br />
Director: Abe Noriyuki<br />
Screenplay: Yokote Michiko<br />
Character Design: Kudou Masashi<br />
Music: Sagisu Shirou<br /><br />
<b>Cast:</b> <br />
Kurosaki Ichigo: Morita Masakazu<br />
Hitsugaya Toushirou: Paku Romi<br />
Matsumoto Rangiku: Matsutani Kaya<br />
Kuchiki Rukia: Orikasa Fumiko<br />
Abarai Renji: Itou Kentarou<br /><br />
Urahara Kisuke: Miki Shinichiro<br />
Shihouin Yoruichi: Yukino Satsuki<br />
Zaraki Kenpachi: Tachiki Fumihiko<br />
Madarame Ikkaku: Hiyama Nobuyuki<br />
Ayasegawa Yumichika: Fukuyama Jun<br />
Ishida Uryuu: Sugiyama Noriaki<br />
Kuchiki Byakuya: Okiayu Ryoutarou<br />
Inoue Orihime: Matsuoka Yuki<br />
Yasutora Sado: Yasumoto Hiroki<br />
Soi Fong: Kawakami Tomoko<br />
Yamamoto Genryuusai Shigekuni: Tsukada Masaaki<br />
Kon: Madono Mitsuaki<br />
</span>