<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>Edit Chapter Info Test Page</title>
	    <link href="../css/misc.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
<script type="text/javascript">
var chapter = new Array ("Death &amp; Strawberry", "Death &amp; Strawberry", "Headhittin");
var volume = new Array ("Death &amp; Strawberry", "Death &amp; Strawberry", "Headhittin");
function DisplayChapter () {
	var ChapterTitleSelect = document.getElementById("ChapterTitleSelect");
	var ChapterTitleTxt = document.getElementById("ChapterTitleTxt");
	if ( ChapterTitleSelect.size == 0 ) {
		for ( var num = 0; num < chapter.length; num++ ) {
			var number = '';
			if ( num >= 100 ) {
				number = num;
			}
			else if ( num >= 10 ) {
				number = '0' + num;
			}
			else {
				number = '00' + num;
			}
			var ChapterTitleOption = document.createElement('option');
			ChapterTitleOption.text = number;
			ChapterTitleOption.value = num;
			try {
				ChapterTitleSelect.add(ChapterTitleOption, null); // standards compliant; doesn't work in IE
			}
			catch(ex) {
				ChapterTitleSelect.add(ChapterTitleOption); // IE only
			}
		}
		ChapterTitleSelect.style.visibility = "visible";
		ChapterTitleTxt.style.vixibiltiy = "collapse";
	}
}
function RemoveChapter () {
	var ChapterTitleSelect = document.getElementById("ChapterTitleSelect");
	var ChapterTitleTxt = document.getElementById("ChapterTitleTxt");
	for ( var i = ChapterTitleSelect.length; i > 0; i-- ) {
		if (ChapterTitleSelect.length > 0) {
			ChapterTitleSelect.remove(ChapterTitleSelect.length - 1);
		}
	}
	ChapterTitleSelect.style.visibility = "collapse";
	ChapterTitleTxt.style.visibility = "visible";
}

function DisplayVolume () {
	var VolumeTitleSelect = document.getElementById("VolumeTitleSelect");
	var VolumeTitleTxt = document.getElementById("VolumeTitleTxt");
	if ( VolumeTitleSelect.size == 0 ) {
		for ( var num = 0; num < volume.length; num++ ) {
			var number = '';
			if ( num >= 100 ) {
				number = num;
			}
			else if ( num >= 10 ) {
				number = '0' + num;
			}
			else {
				number = '00' + num;
			}
			var VolumeTitleOption = document.createElement('option');
			VolumeTitleOption.text = number;
			VolumeTitleOption.value = num;
			try {
				VolumeTitleSelect.add(ChapterTitleOption, null); // standards compliant; doesn't work in IE
			}
			catch(ex) {
				VolumeTitleSelect.add(ChapterTitleOption); // IE only
			}
		}
		VolumeTitleSelect.style.visibility = "visible";
		VolumeTitleTxt.style.visibility = "collapse";
	}
}

function RemoveVolume () {
	var VolumeTitleSelect = document.getElementById("VolumeTitleSelect");
	var VolumeTitleTxt = document.getElementById("VolumeTitleTxt");
	for ( var i = VolumeTitleSelect.length; i > 0; i-- ) {
		if (VolumeTitleSelect.length > 0) {
			VolumeTitleSelect.remove(VolumeTitleSelect.length - 1);
		}
	}
	VolumeTitleSelect.style.visibility = "collapse";
		VolumeTitleTxt.style.visibility = "visible";
}
function Display () {
	if ( window.document.getElementById("type_chapter").checked ) {
		if ( window.document.getElementById("edit_add").checked ) {
			RemoveChapter();
			DisplayVolume();
		}
		else if ( window.document.getElementById("edit_edit").checked ) {
			DisplayChapter();
			DisplayVolume();
		}
		else if ( window.document.getElementById("edit_delete").checked ) {
			DisplayChapter();
			RemoveVolume();
		}
	}
}
</script>
<fieldset>
<legend class="main">Japanese Chapter Title Edit Section</legend>
	<form name="JPChapterTitles" method="post" action="">
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
			  <td style="width: 50%;"><label><input id="type_chapter" name="JPChapter_type" type="radio" value="chapter" checked />Chapter</label></td>
				<td style="width: 50%;"><label><input id="type_volume" type="radio" name="JPChapter_type" value="volume" />Volume</label></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
			  <td style="width: 33%;"><label><input id="edit_add" name="JPChapter_edit" type="radio" value="add" onchange="DisplayChapter ()" checked />Add</label></td>
				<td style="width: 33%;"><label><input id="edit_edit" type="radio" name="JPChapter_edit" value="edit" onchange="DisplayChapter ()" />Edit</label></td>
			  <td style="width: 34%;"><label><input id="edit_delete" type="radio" name="JPChapter_edit" value="delete" onchange="DisplayChapter ()" />Delete</label></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td style="width: 23%">Chapter Number</td> 
				<td style="width: 15%"><select id="ChapterTitleSelect" name="chapter" class="ChapterTitleList"></select><input id="ChapterTitleTxt" name="cid" type="text" maxlength="4" class="ChapterTitleText" /></td>
				<td style="width: 17%">Chapter Title</td>
				<td style="width: 45%"><input name="ctitle" type="text" style="width: 95%;" /></td>
			</tr>
			<tr>
				<td style="width: 23%">Volume Number</td>
				<td style="width: 15%"><select id="VolumeTitleSelect" name="chapter" class="VolumeTitleList"></select><input id="VolumeTitleTxt"name="vid" type="text" maxlength="3" class="VolumeTitleText" /></td>
				<td style="width: 17%;">Volume Title</td>
				<td style="width: 45%;"><input name="vtitle" type="text" style="width: 95%;" /></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td align="center"><input type="submit" value="Submit Changes" name="JPChapterTitles_submit" class="form" /></td>
			</tr>
		</table>
	</form>
</fieldset>
	</body>
</html>
