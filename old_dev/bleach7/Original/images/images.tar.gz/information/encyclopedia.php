<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Encyclopedia</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Encyclopedia:</b></span><span class="VerdanaSize1Main"><br />

<br /></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" /><br />
<center><span class="VerdanaSize1Main"><a href='#A'><b>A</b></a> <a href='#B'><b>B</b></a> <a href='#C'><b>C</b></a> <a href='#D'><b>D</b></a> <a href='#E'><b>E</b></a> <a href='#F'><b>F</b></a> <a href='#G'><b>G</b></a> <a href='#H'><b>H</b></a> <a href='#I'><b>I</b></a> <a href='#J'><b>J</b></a> <a href='#K'><b>K</b></a> <a href='#L'><b>L</b></a> <a href='#M'><b>M</b></a> <a href='#N'><b>N</b></a> <a href='#O'><b>O</b></a> <a href='#P'><b>P</b></a> <a href='#Q'><b>Q</b></a> <a href='#R'><b>R</b></a> <a href='#S'><b>S</b></a> <a href='#T'><b>T</b></a> <a href='#U'><b>U</b></a> <a href='#V'><b>V</b></a> <a href='#W'><b>W</b></a> <a href='#X'><b>X</b></a> <a href='#Y'><b>Y</b></a> <a href='#Z'><b>Z</b></a></span></center>
<span class="VerdanaSize1Main"><br />

</span><p><a name="A" id="A"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; A</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Asauchi</b>:  Nameless zanpakutou carried by shinigami who can not gain entrance into the Gotei 13.

</span><p><a name="B" id="B"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; B</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Bankai (&quot;Final Release&quot;)</b>: The second possible stage of release of a zanpakutou.  Attaining bankai requires the materialization of the zanpakutou's avatar, and forcing it into submission, which usually takes at least 10 years, even for skilled shinigami. When bankai is achieved, the wielder often gains a 5 to 10 fold increase in fighting strength.  Even after attaining bankai, 10 additional years of training are required to master the zanpakutou.
<br /><br />
<b>Baron</b>: The name Rukia called Ichigo after she drew a Kaiser mustache on his face.
</span><p><a name="C" id="C"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; C</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Cero</b>: The beam Menos Grande fire by concentrating their reiatsu.
<br /><br />
<b>Chappy</b>: One of the characters that enters the body when a gikongan (soul candy) is taken.  There is a large demand for the duck and dog variety, but the most popular is Chappy the rabbit. 

</span><p><a name="D" id="D"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; D</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Dangai</b>: The area between the living world and soul society
<br /><br />
<b>Denreishinki</b>: The cell phone-like device used by shinigami to receive orders from Soul Society.

</span><p><a name="E" id="E"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; E</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Enraku</b>: The name of Orihime's stuffed bear.  The name is thought to come from the person who serves the &quot;shouten's&quot; chairman.

</span><p><a name="F" id="F"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; F</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Fugaiku (lit. district outside the wall)</b>: The place in Soul Society located on the outer edge of Seireitei.  Many souls reside in fugaiku.  The more common name for it is Rukongai.

</span><p><a name="G" id="G"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; G</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Gentei (&quot;Limit&quot;)</b>: When captains and vice-captains come to the living world, in order to prevent unnecessary influence, their power is reduced by 80%, and is symbolized by a patch bearing their squad number.
<br /><br />
<b>Getaboushi</b>: Ichigo's nickname for Urahara because of the wooden sandals and striped hat he always wears.
<br /><br />
<b>Gigai</b>: The temporary physical body given to shinigami.  It was designed by the Shinigami Research Institute (12th squad)
<br /><br />
<b>Gikongan</b>: A pill that forces a soul out of its body.  It was originally used on souls that had died, but refused to leave their body, but then was applied to help shinigami separate from their gigai.  When it is taken, a temporary soul enters the body.  Three years ago, it was renamed &quot;Soul Candy&quot; by the Shinigami Women's Association, led by chairwoman Kusajishi Yachiru.  The three most popular varieties are Chappy (rabbit), Yuki (duck), and Pebbles (dog).  Other kinds available are Diana (snake), Alfred (skeleton), Claudia (bird), Ginnosuke (cat), Gringo (panda), Bruce (monkey), Kaneshiro (frog), and Staina (seal?).
<br /><br />
<b>Gokontekkou</b>: The glove Rukia uses to change Ichigo into shinigami form.

</span><p><a name="H" id="H"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; H</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Hakuda (lit. white strike)</b>: Technique used in hand-to-hand combat.  This type of combat often involves great danger because the shinigami is fighting unarmed.  This technique plays a role in the supreme battle technique known as shunkou, which is executed by compressing a high concentration of kidou into any part of the shinigami's body.
<br /><br />
<b>Hakudou (&quot;Soul Movement&quot;)</b>: The movement and fluctuation of spirit power.
<br /><br />
<b>Hakusuitosaketsu (&quot;Soul Sleep and Chain Link&quot;)</b>: Vital parts of a soul.  When they are shattered, the soul will die.  The soul sleep is the source of spirit power, and the chain link boosts the power of the soul sleep.
<br /><br />
<b>Hohou (lit. walking method)</b>: If a shinigami is attacking using hakuda, this technique is necessary to assist their movement.  It is not a direct offensive technique, however, it can be used to gain the upper hand in a zanpakutou battle.  If this technique is mastered, the shinigami will be able to make high speed movements that can't be traced by the eye, called shunpo.  
<br /><br />
<b>Hueco Mundo</b>: The place where hollows reside.

</span><p><a name="I" id="I"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; I</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Ichinii</b>: Karin's nickname for Ichigo.  It means older brother Ichigo.
<br /><br />
<b>Inganokusari (&quot;Chain of Fate&quot;)</b>: The chain that connects the soul to the physical body.  While it is connected, the soul itself can not die.  When the chain is cut, the chain begins to erode from the severed end.  If it reaches the chest, a hole will form in the body, and the soul will become a hollow.
<br /><br />
<b>Inoshishi Genjin (&quot;Primitive Boar Man&quot;)</b>: Ichigo's nickname for Ganju when they first meet.

</span><p><a name="J" id="J"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; J</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Jigoku (Hell)</b>: Hollows that have committed grave sins before their death will be sent to Hell.  When the hollow is slain, the Gates of Hell appear and swallow the hollow.
<br /><br />
<b>Jigokuchou (Hell butterflies)</b>: Only shinigami can control them.  If you possess one, you can safely pass through the Senkaimon (&quot;World Piercing Gates&quot;)
<br /><br />
<b>Jyuureichi (&quot;The Spiritual Gathering Grounds&quot;)</b>: The spiritual gathering place in the living world.  It is easiest for those who have become spirits to gather there because it is spiritually heterogeneous.  The location of this place changes with time, but as of now, is located in Karakura city.

</span><p><a name="K" id="K"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; K</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<b>Karakura Town Minami Elementary School</b>: The Elementary School Yuzu and Karin attend.
<span class="VerdanaSize1Main"><br /><br />
<b>Karate Style Killer Ape</b>: The name Midoriko gave to one of Tatsuki's attacks.  When translated into Japanese, it means &quot;The homicidal monkey that does karate&quot;
<br /><br />
<b>Kenekikyoku</b>: System blocking those who try to enter from outside the Court of Pure Souls.
<br /><br />
<b>Kenseikan</b>: The white hairpiece Kuchiki Byakuya wears.  It is only to be worn by nobility.
<br /><br />
<b>Kidou (&quot;Demon Arts&quot;)</b>: A noble magic that can only be used by shinigami.  There are two types of spells: bakudou (&quot;binding spell&quot;) and hadou (&quot;blast spell&quot;).  Bakudou are mainly used to restrain a target, however, there are some auxiliary spells that can be used for defense or communication.  Hadou are mainly used for direct attacks on an opponent.  The spells are numbered 1 through 99, and increase in power and difficulty of casting, as the number increases.  Some of the higher order bakudou not only bind the target, but are also capable of attacking offensively.  These spells are classified as fuusatsugata (&quot;deadly binding type&quot;).  When a shinigami masters kidou, they are able to cast spells hastily by bypassing the incantation for the spell.  To gain this high level of power, a shinigami must go through intense training.  A list of known kidou can be found <a href="?page=information/demonarts">here.</a>
<br /><br />
<b>Kikanshinki</b>: A type of kiokuchikan used on humans who have seen a shinigami or hollow.  The cheapest fuel for it is rated &quot;D&quot;  It inputs a random, false memory into the human's mind.
<br /><br />
<b>Kiokuchikan (&quot;Memory Substitute&quot;)</b>: Instrument used by shinigami to manipulate the memory of humans.
<br /><br />
<b>Kishi</b>: The substance that makes up all things in the living world.
<br /><br />
<b>Konpaku</b>: A soul.  The good souls are called &quot;pluses&quot; and the bad sould are called &quot;hollows&quot;
<br /><br />
<b>Konsou (&quot;Soul Burial&quot;)</b>: The process by which a soul is sent to Soul Society by a shinigami.
<br /><br />
<b>Koutotsu</b>: The cleaner that monitors the &quot;dangai&quot; (the area between the living world and Soul Society)  In order to remove intruders, it forms a high density &quot;koutotsu&quot;
<br /><br />
<b>Kuukanyouketsu (&quot;Space freeze&quot;)</b>: The measure that is taken to protect souls when shinigami battle in the human world.
<br /><br />
<b>Kuumon (&quot;Sky Gate&quot;)</b>: When Menos Grande appeared in the living world, the sky gates caused distortion in the living world.  It is believed that their convergence signals the emergence of a Menos.
<br /><br />
<b>Kyoumon (&quot;Mirror Gate&quot;)</b>: A high class barrier that reflects attacks from the outside.

</span><p><a name="L" id="L"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; L</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />

<p><a name="M" id="M"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; M</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Maki Maki</b>: Yachiru's nickname for the 10th seat of 11th squad, Aramaki Makizou.

</span><p><a name="N" id="N"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; N</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Negation</b>: The light Menos Grande use when helping those of the same family.  When it is used, interference from outside the light becomes impossible, and the space inside becomes completely segregated from the outside world.

</span><p><a name="O" id="O"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; O</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Onigoto</b>: Tag.  This is an obsolete word and is probably used because Yoruichi is so old.  It means the same as the word &quot;onigokko&quot; meaning &quot;pretend demons&quot; where the &quot;it&quot; person is a demon and tries to tag another person.

</span><p><a name="P" id="P"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; P</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Pachinko Dama (&quot;Pachinko Ball&quot;)</b>: The insult Yachiru spits at Ikkaku when she sees his skinhead.

</span><p><a name="Q" id="Q"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; Q</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Quincy</b>: A race of humans who gained spiritual awareness and the ability to attack with spirit energy by using destructive arts. These arts are used to form arrows that are created by gathering spirit particles in the air. These arrows kill hollows, rather than cleansing them, which caused an unbalance in the flow of souls between Soul Society and the Human World.  Because of this inbalance, the shinigami were forced to eradicate the Quincy.  Two hundred years after this incident, there are only two remaining Quincy.

</span><p><a name="R" id="R"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; R</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Reiatsu (&quot;Spirit pressure&quot;)</b>: The energy in a soul that can be used to attack.  The amount of reiatsu a soul has is linked with the soul's spiritual awareness, and the strength of its resolve.  As long as the reiatsu and reiryoku of a soul remain strong, the soul will have a constant wave of strength.  Reiatsu can become a shield to deflect attacks from the enemy if the defender's reiatsu is much larger than the attacker's.
<br /><br />
<b>Reihou (&quot;Spirit Laws&quot;)</b>: The laws which shinigami must obey.
<br /><br />
<b>Reiraku (&quot;Spirit Threads&quot;)</b>: The visualization of spiritual auras.  They are created by compressing spiritual auras in the atmosphere into visible &quot;threads&quot; Only high ranked shinigami are able to see or touch them, and it has been shown that Quincy can also obtain this ability.  The reiraku of shinigami are colored crimson, while normal souls' are colored white.
<br /><br />
<b>Reiryoku (&quot;Spirit Power&quot;)</b>: The power obtained when you become a spirit.  It is possible to be born with reiryoku.
<br /><br />
<b>Reishi</b>: The main substance that comprises a soul.

</span><p><a name="S" id="S"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; S</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Sakana Tsura (&quot;Fish Mask&quot;)</b>: The name Ichigo says when he sees the hollow Fishbone D (The first hollow Ichigo fights)
<br /><br />
<b>Senkaimon (&quot;World Piercing Gate&quot;)</b>: The gate that connects Soul Society and the living world.  A zanpakutou has the ability to unlock the gate.  By piling reishihenkanki (spirit exchangers) on top of the senkaimon, kishi can be converted to reishi, allowing entrance to soul society without being in soul form.
<br /><br />
<b>Shihakushou</b>: The shinigami's uniform.
<br /><br />
<b>Shikai (&quot;Initial Release&quot;)</b>:  The first possible stage of release of a zanpakutou.  To attain it, one must achieve interaction and synchronization with their zanpakutou.
<br /><br />
<b>Shinigami (&quot;Death God&quot; or &quot;Souls Reaper&quot;)</b>: The souls responsible for maintaining a balance between Soul Society and the human world.  They exterminate and purify hollows, and lead souls to Soul Society through konsou.  They can change the embodiment of their zanpakutou through their reiryoku.  The four basic battle techniques of shinigami are collectively called zankensouki.  They names of the individual techniques are: hakuda, hohou, kidou, and zanjutsu.  Each of these four combat techniques has a limit.  Once a shinigami has reached the limit in four techniques, they will have reached the limit of their spiritual body, and will not be able to escalate their strength any further.
<br /><br />
<b>Shinketsu (&quot;Pure blood&quot;)</b>: Parents of shinigami.  Their abilities are higher than those of an ordinary shinigami.
<br /><br />
<b>Shutsugekiryou (&quot;Combat Mission Charge&quot;)</b>: A charge for destroying buildings or other property on a mission. 
<br /><br />
<b>Souma Fixer</b>: Solution used to help shinigami align with their gigai.  If overused, it makes it difficult for the shinigami to exit the gigai.

</span><p><a name="T" id="T"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; T</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Tentouken (&quot;Heavenly Gliding Figure&quot;)</b>: An overcoat-like instrument Yoruichi gives to Ichigo.  The wearer gains the ability to fly.
<br /><br />
<b>Tokumori (lit. special prospering, translated as &quot;extra large&quot; by most groups)</b>: The word Kon uses when he refers to Orihime's breasts.
<br /><br />
<b>Touchan's Great Whistle</b>: The whistle Ichigo's dad uses when he calls a family meeting.
<br /><br />
<b>Tsuikakyuukin (Hollow Bounty)</b>: When a dangerous hollow is cleansed, a reward may be given to the shinigami.  The reward for Shrieker (the hollow controlling the boy trapped in the parakeet) was 5000 kan.  However, Fishbone D (first hollow fought), Hexspodus (second hollow in the park), and Acid Wire (Inoue's brother) were not worth anything.
<br /><br />
<b>Tsukitsukinomai (&quot;The Lucky Lucky Dance&quot;)</b>: The dance Ikkaku does when he is excited about getting to fight.

</span><p><a name="U" id="U"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; U</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Ugendou</b>: The name of the 13th squad captain's office.  When Ukitake's health is poor, he often receives medical treatment here.

</span><p><a name="V" id="V"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; V</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />

<p><a name="W" id="W"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; W</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />

<p><a name="X" id="X"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; X</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />

<p><a name="Y" id="Y"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; Y</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Yakka (&quot;Baseball-Soccer&quot;)</b>: The new sport that Orihime created.  It combines soccer and baseball.  It is basically one-on-one, creating a big disadvantage for the defensive side.
<br /><br />
<b>Yaochou (&quot;The Super 800&quot;)</b>: The fruit and vegetable merchant in Karakura city.  The shopkeeper is Kenjii-san.
<br /><br />
<b>Yumisawajidoukouen (&quot;Yumisawa Childrens' Park&quot;)</b>: The park in Karakura City where the hollow Hexspodus appeared.  It is the place where Ichigo finally resolved to help Rukia with her shinigami work.

</span><p><a name="Z" id="Z"></a></p>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize2Main"><b>&raquo; Z</b></span>
<hr noshade="noshade" size="1" style="color: #2B5C85; width: 100%;" />
<span class="VerdanaSize1Main"><b>Zanjutsu (lit. cutting technique)</b>: Combat using a zanpakutou.
<br /><br />
<b>Zankensouki</b>: The name for the 4 basic combat techniques of the shinigami.  The names of the techniques are: hakuda, hohou, kidou, and zanjutsu.
<br /><br />
<b>Zanpakutou (&quot;Soul Slayer&quot;)</b>: Used by shinigami to kill hollows.  It washes away sins committed by the soul after it became a hollow so that it can enter Soul Society through a &quot;soul burial.&quot; All zanpakutou have two possible stages of release.  The first is called shikai (initial release) and The second is called bankai.  The training from shikai to bankai usually exceeds 10 years, even for talented shinigami.  After achieving bankai, at least 10 additional years of training are required to completely master the zanpakutou. The lower class shinigami that do not gain entrance into the Gotei 13 carry nameless zanpakutou called &quot;asauchi&quot;</span>