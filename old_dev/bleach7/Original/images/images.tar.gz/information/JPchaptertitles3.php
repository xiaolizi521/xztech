<?php
// Create a new XML Parser
if ( !( $xmlparser = xml_parser_create() ) )
{ 
   die ("Cannot create parser");
}

// Change starting tag information
function start_tag($parser, $name, $attribs) {
	echo "Current tag : ".$name."<br />";
	if ( is_array( $attribs ) ) {
		echo "Attributes : <br />";
		while ( list( $key, $val ) = each( $attribs ) ) {
			echo "Attribute ".$key." has value ".$val."<br />";
       }
	}
}

// Change ending tag information
function end_tag($parser, $name) {
	echo "Reached ending tag ".$name."<br /><br />";
}

// Display the contents within the tags
function tag_contents($parser, $data) {
	echo "Contents : ".$data."<br />";
}

// Run through the tags
xml_set_element_handler($xmlparser, "start_tag", "end_tag");

// Run through the contents between the tags
xml_set_character_data_handler($xmlparser, "tag_contents");

// Open XML file
$filename = "xml/JPchaptertitles2.xml";
if ( !($fp = fopen( $filename, "r" ) ) ) {
	die("cannot open ".$filename);
}

// Read the XML file and display any erros
while ( $data = fread( $fp, 4096 ) ) {
	$data = eregi_replace( ">"."[[:space:]]+"."<", "><", $data );
	if ( !xml_parse( $xmlparser, $data, feof( $fp ) ) ) {
		$reason = xml_error_string( xml_get_error_code( $xmlparser ) );
		$reason .= xml_get_current_line_number( $xmlparser );
		die($reason);
	}
}
xml_parser_free( $xmlparser );
?>