<?PHP
if ( !isset ( $_COOKIE['user_id'] ) && !isset ( $_COOKIE['password'] ) ) {
header ( "Location: $site_url/$main_filename?$ident=$script_folder/login" );
}?>
<span class="VerdanaSize1Main"><b>Bleach7 &gt; Information &gt; Bleach Manga Guide &gt; Japanese Chapter Titles</b><br />
<br />
<?
$index = mysql_query ( "SELECT * FROM index_info" );
$chapters = mysql_fetch_array($index);
$chapternum = $chapters['manga_sub'];
?>

<table width="100%">
<?PHP
for($i = 1; $i <= $chapternum; $i++)
{
$color = ( $i % 2 == 0 ) ? "#eeeeee" : "";
//Volume covers, and titles. Copy and change as necessary to add new volume. $i is the chapter the volume starts with.
 if($i == 1)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 1</div>"The Death and the Strawberry"<hr /></td></tr>
 <tr><td rowspan="8" width="2"><img src="media/images/covers/v01.gif"></td></tr>';}
 if($i == 8)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 2</div>"Goodbye Parakeet, Goodnite My Sista"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v02.gif"></td></tr>';}
 if($i == 17)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 3</div>"Memories in the Rain"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v03.gif"></td></tr>';}
 if($i == 26)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 4</div>"Quincy Archer Hates You"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v04.gif"></td></tr>';}
 if($i == 35)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 5</div>"Rightarm of the Giant"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v05.gif"></td></tr>';}
 if($i == 44)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 6</div>"The Death Trilogy Overture"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v06.gif"></td></tr>';}
 if($i == 53)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 7</div>"The Broken Coda"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v07.gif"></td></tr>';}
 if($i == 62)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 8</div>"The Blade and Me"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v08.gif"></td></tr>';}
 if($i == 71)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 9</div>"Fourteen Days For Conspiracy"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v09.gif"></td></tr>';}
 if($i == 80)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 10</div>"Tattoo on the Sky"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v10.gif"></td></tr>';}
 if($i == 89)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 11</div>"A Star and a Stray Dog"<hr /></td></tr>
 <tr><td rowspan="11" width="2" valign="top"><img src="media/images/covers/v11.gif"></td></tr>';}
 if($i == 99)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 12</div>"Flower on the Precipice"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v12.gif"></td></tr>';}
 if($i == 108)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 13</div>"The Undead"<hr /></td></tr>
 <tr><td rowspan="9" width="2" valign="top"><img src="media/images/covers/v13.gif"></td></tr>';}
 if($i == 116)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 14</div>"White Tower Rocks"<hr /></td></tr>
 <tr><td rowspan="9" width="2" valign="top"><img src="media/images/covers/v14.gif"></td></tr>';}
 if($i == 124)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 15</div>"Beginning of the Death of Tomorrow"<hr /></td></tr>
 <tr><td rowspan="8" width="2" valign="top"><img src="media/images/covers/v15.gif"></td></tr>';}
 if($i == 131)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 16</div>"Night of Wijnruit"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v16.gif"></td></tr>';}
 if($i == 140)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 17</div>"Rosa Rubicundior, Lilio Candidior"<hr /></td></tr>
 <tr><td rowspan="11" width="2" valign="top"><img src="media/images/covers/v17.gif"></td></tr>';}
 if($i == 150)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 18</div>"The Deathberry Returns"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v18.gif"></td></tr>';}
 if($i == 159)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 19</div>"The Black Moon Rising"<hr /></td></tr>
 <tr><td rowspan="11" width="2" valign="top"><img src="media/images/covers/v19.gif"></td></tr>';}
 if($i == 169)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 20</div>"End of Hypnosise"<hr /></td></tr>
 <tr><td rowspan="11" width="2" valign="top"><img src="media/images/covers/v20.gif"></td></tr>';}
 if($i == 179)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 21</div>"Be My Family or Not"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v21.gif"></td></tr>';}
 if($i == 188)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 22</div>"Conquistadores"<hr /></td></tr>
 <tr><td rowspan="11" width="2" valign="top"><img src="media/images/covers/v22.gif"></td></tr>';}
 if($i == 198)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 23</div>"Mala Suerte!"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v23.gif"></td></tr>';}
 if($i == 206)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 24</div>"Immanent God Blues"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v24.gif"></td></tr>';}
 if($i == 215)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 25</div>"No Shaking Throne"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v25.gif"></td></tr>';}
 if($i == 224)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 26</div>"The Mascaron Drive"<hr /></td></tr>
 <tr><td rowspan="11" width="2" valign="top"><img src="media/images/covers/v26.gif"></td></tr>';}
 if($i == 234)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 27</div>"Goodbye Halcyon Days"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v27.gif"></td></tr>';}
 if($i == 243)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 28</div>"Baron&#39;s Lecture Full-Course"<hr /></td></tr>
 <tr><td rowspan="9" width="2" valign="top"><img src="media/images/covers/v28.gif"></td></tr>';}
 if($i == 251)
 {echo '
 <tr><td colspan="2"><div class="vol">Volume 29</div>"The Slashing Opera"<hr /></td></tr>
 <tr><td rowspan="10" width="2" valign="top"><img src="media/images/covers/v29.gif"></td></tr>';}
 if($i == 260)
 {echo '
 
 <tr><td colspan="2"><div class="vol">No released volume</div><hr /></td></tr>
 <tr><td rowspan="50" width="2" valign="top"><img src="media/images/covers/v00.gif"></td></tr>';}
 
 
$index = mysql_query ( "SELECT * FROM manga_chapters WHERE chapternum ='$i'" );
$chapterinfo = mysql_fetch_array($index);

 
echo '<tr><td bgcolor='.$color.'>Ch'.$i.': <em>'.stripslashes ($chapterinfo['chaptertitle']).'</em></td></tr>';
}
echo '</table>';

?>