<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Miscellaneous &gt; Bounty Rewards</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bounty Rewards</b></span><span class="VerdanaSize1Main"><br />
<br />
A bounty reward is bonus cash given to a shinigami for the cleansing of a hollow. The hollow must have been dangerous enough to be on the bounty list to have a bonus cash reward. Rukia uses the bounty reward from "Shrieker" to buy Soul Candy for Ichigo.<br />
<br />
(<i>Information Found In Volume 2, Chapter 6 of the Bleach Manga</i>)</span>