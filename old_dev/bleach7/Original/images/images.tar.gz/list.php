<?php

foreach(glob('./*') as $key)
{
    $info = pathinfo($key);

    if (in_array(strtolower($info['extension']), array('png', 'jpg', 'jpeg', 'gif', 'bmp')))
    {
        echo '<a href="http://www.rottingturnips.info/forOthers/Bleach7/images/' . $info['basename'] . '"><img style="width: 100px; height: 100px;" src="http://www.rottingturnips.info/forOthers/Bleach7/images/' . $info['basename'] . '" alt="' . $info['basename'] . '" /></a>' . "\n";
    }
}

?>