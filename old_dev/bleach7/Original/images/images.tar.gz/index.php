<?php
header("Location: http://bleach7.com/");
exit;
?> 
