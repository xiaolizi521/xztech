<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Miscellaneous &gt; Hollow Bait</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Hollow Bair</b></span><span class="VerdanaSize1Main"><br />
<br />
Hollow Bait is a small coin shaped object. When crushed hollows	gather to the place where the bait was scattered/crushed.&nbsp;<br />
<br />
<span class="artstitle">Uses:</span><br />
Ishida uses the Hollow Bait to summon hollows for a battle against Ichigo, in which the one who destroys/cleanses the most hollows in 24 hours wins.<br />
<br />
(<i>Information Found In Volume 5, Chapter 2 of the Bleach Manga</i>)</span>