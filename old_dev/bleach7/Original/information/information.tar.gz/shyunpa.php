<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Spell Guide &gt; Shyunpa</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Shyunpa</b></span><span class="VerdanaSize1Main"><br />
<br />
A high level shinigami art that allows the user/shinigami to "warp" one's self (entire body) to another place. It requires long training and to be quite powerful to use easily.</span>