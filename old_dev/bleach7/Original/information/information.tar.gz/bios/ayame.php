<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Ayame</b><br />
<br />
</font><font face="Verdana" size="2"><b>Ayame</b></font><font face="Verdana" size="1"><br />
<br />
One of the six forming the Shun Shun Rikka (Shield of 6 Dancing Flowers), Ayame is a timid spirit (I'm assuming she's timid since she doesn't talk at all) that takes part in Orihime's second technique, where a shield is form to &quot;repel inner damage,&quot; or in everyday terms, to heal; it can reverse damage that has already been done.  The incantation for this is &quot;Souten Kishun, (Return Shield of the Heavenly Duo) I Repel Thee,&quot; but later this can be done without any chant.  Ayame can be distinguished as the tiny (they're all tiny) girl with a flowered covering over her head.</font>