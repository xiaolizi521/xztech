<br /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Character Biographies</b><br />
<br />
</font><font face="Verdana" size="2"><b>Bleach Character Biographies Main</b></font><font face="Verdana" size="1"><br />
<br /></font>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1">|<a href="?page=information/bios/0-9">#-9</a>|
      |<a href="?page=information/bios/a-h">A-H</a>| |<a href="?page=information/bios/i-q">I-Q</a>|
      |<a href="?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1"><br />
      <br />
      <br />
      |Please Choose A Category|<br />
      <br />
      <br />
      <br />
      </font></td>
  </tr>
  <tr>
    <td width="100%">
      <p align="center"><font face="Verdana" size="1">|<a href="?page=information/bios/0-9">#-9</a>|
      |<a href="?page=information/bios/a-h">A-H</a>| |<a href="?page=information/bios/i-q">I-Q</a>|
      |<a href="?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
</table></font>