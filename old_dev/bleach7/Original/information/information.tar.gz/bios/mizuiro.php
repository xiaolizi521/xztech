<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Kojima, Mizuiro</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kojima, Mizuiro</b></font><font face="Verdana" size="1"><br />
<br />
Kojima Mizuiro is a classmate of Kurosaki Ichigo. They are both in Class 3 together. He is also fifteen years old. He is one of Ichigo's closest friends, and he goes by Ichigo's house every morning to walk to school together. Ichigo, Mizuiro, and Asano Kiego always hang out together at school.<br />
<br />
Mizuiro and Kiego do not do very well at school. Neither of them made the top fifty with their midterm scores, although Ichigo did, much to their dismay. Mizuiro tends to be very quiet, shy, and self conscious � the exact opposite of Kiego. He will join forces with Kiego, however, to annoy Ichigo. In chapters 27 and 28 of the manga, we learn that he does the Don Kanonji pose specifically to annoy Ichigo since Ichigo hates Don Kanonji. He seems, however, to be a true friend to Ichigo.<br />
<br />
In chapter 7 of the manga, Ichigo claims that Mizuiro's hobby is womanising Mizuiro is known as the pretty boy at his school. His shyness adds to his cute looks, making him very popular with girls. He is, however, only interested in older girls, claiming that all the girls his age are safe. This leads to Ichigo remarking that Rukia is not safe with Mizuiro. Mizuiro constantly comments on Ichigo's relationship with Rukia and how it's suspicious that they are always together. In chapter 34 of the manga, we find out that Mizuiro is responsible for all the rumours circulating around the school about Ichigo and Rukia. In chapter 58, we also learn that Mizuiro has a girlfriend, Mari-san.<br />
<br />
<br />
(Written by: Esther Kim, aka kimcheese) 9/21/2005</font>