<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Oomaede, Marechiyo</b><br />
<br />
</font><font face="Verdana" size="2"><b>Oomaede, Marechiyo</b></font><font face="Verdana" size="1"><br />
<br />
The Vice-Captain of the 2nd Division. His appearance consist of a gold bracelet, purple scarf, and quite large in size. You can usually find him eating a bag snack, walking behind his Captain, Soi Fong. His personality seems like he is high of himself and no matter what situation he will fallow his Captain's orders. His Zanpakutou's name is Gegetsuburi (Five-form Head), the incantation to release it is, Buttsubuse! (Smash!).</font>