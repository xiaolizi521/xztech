<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Zangetsu</b><br />
<br />
</font><font face="Verdana" size="2"><b>Zangetsu/Kitsuki</b></font><font face="Verdana" size="1"><br />
<br />
Zangetsu is the physical manifestation of Ichigo's soul cutter. He serves as a sort of spiritual guide for Ichigo when he is having problems. Zangetsu first appears to keep Ichigo from turning into hollow during his training with Urahara. His appearance is that of a man with long, dark hair. Ichigo recognizes the man as his uncle Kitsuki. However, he is later given the name Zangetsu.<br />
<br />
Zangetsu often appears to Ichigo when he is injured or in a place where he can no longer fight. Eventually he forces Ichigo to earn his right to use Zangetsu by making Ichigo fight himself. Zangetsu desperately wants Ichigo to succeed, and he teaches Ichigo to listen to his sword. In return, Ichigo offers to let Zangetsu fight with him, and they are much stronger this way.</font>