<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Character Biographies &gt; A-H</b><br />
<br />
</font><font size="2" face="Verdana"><b>Bleach Character Biographies</b></font><font face="Verdana" size="1"><br />
<br /></font>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%" align="center"><font size="1" face="Verdana">|<a href="index.php?page=information/bios/0-9">#-9</a>| |<a href="index.php?page=information/bios/a-h">A-H</a>| |<a href="index.php?page=information/bios/i-q">I-Q</a>| |<a href="index.php?page=information/bios/r-z">R-Z</a>|</font></td>
	</tr>
	<tr>
		<td width="100%" align="center"><font face="Verdana" size="1"><br /></font>
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="100%" colspan="3"><h1 align="center"><font face="Verdana" size="2">Ayame</font></h1></td>
				</tr>
				<tr>
					<td width="21%" align="center"><font face="Verdana" size="1">Image N/A</font></td>
					<td width="15%">&nbsp;</td>
					<td width="64%"><font face="Verdana" size="1">One of the six forming the Shun Shun Rikka (Shield of 6 Dancing Flowers), Ayame is a timid spirit (I'm assuming she's timid since she doesn't talk at all) that takes part in Orihime's second technique, where a shield is form to &quot;repel inner damage,&quot; or in everyday terms, to heal...(<a href="index.php?page=information/bios/ayame">read more</a>)</font></td>
				</tr>
				<tr>
					<td width="100%" colspan="3"><hr style="width: 100%; color:#000000;" noshade size="1" /></td>
				</tr>
			</table>
			<p align="center"><font face="Verdana" size="1"><br /></font></p></td>
	</tr>
  <tr>
    <td width="100%" align="center"><font size="1" face="Verdana">|<a href="index.php?page=information/bios/0-9">#-9</a>| |<a href="index.php?page=information/bios/a-h">A-H</a>| |<a href="index.php?page=information/bios/i-q">I-Q</a>| |<a href="index.php?page=information/bios/r-z">R-Z</a>|</font></td>
  </tr>
</table>