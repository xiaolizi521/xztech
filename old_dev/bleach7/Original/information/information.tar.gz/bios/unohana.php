<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Biographies &gt; Retsu, Unohana</b><br />
<br />
</font><font face="Verdana" size="2"><b>Retsu, Unohana</b></font><font face="Verdana" size="1"><br />
<br />
Unohana Retsu is the leader of the 4th division, known for their remarkable healing prowess. Although they have relatively weak fighting abilities, the 4th division's healing powers are invaluable to the rest of the Gotei 13; however, the other divisions fail to see that, so the 4th division medics are treated as weaker, inferior shinigami.<br />
<br />
Although the 4th division is treated as a substandard team, Unohana Retsu is revered as well as any other captain. She has a more unique, passive ban kai in comparison to the other captains, yet her zanpakutou's power is well-suited for her job. Her ban kai summons a large, one-eyed, flying manta that commands mystical healing powers not yet fully known.<br />
<br />
She is also a very gentle person, and is kind to all who receive her nursing care. Her placid attitude especially extends to her vice captain, Isane Kotetsu, and treats her as younger sister to guide.</font>