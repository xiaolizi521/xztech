
<br /><b>Bleach 7 &gt; Information &gt; Bleach Game Guide</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Game Guide:</b> </span><span class="VerdanaSize1Main"><b>[Last Updated:9/17/04]</b><br />
<br />
Known Information:<br />
&quot;Sony has announced that a Bleach video game is in the works. This game will follow the magna series. Though no precise details have been released, this game will mostly pretain to either the manga fans or just game buyers themselves. More news will follow on this story as soon as anything is released on this game.&quot;<br />
(Game screenshots here)