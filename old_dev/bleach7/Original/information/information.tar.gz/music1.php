<link rel="stylesheet" type="text/css" href="css/transition2.css" />
<p />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Multimedia &gt; Music Downloads</b><br />
<br />
</font><font face="Verdana" size="2"><b>Music Downloads </b></font><font face="Verdana" size="1"><br />
<br />
<b>Bleach Music Direct Downloads</b><br />
At Bleach7.com it is our on-going, fan motivated goal, to strive to be able to distribute the Bleach Music to you, the valued visitor of our site, as well as we possibly can. We have put up every song of the series for you to enjoy. Enjoy the downloads!<br />
<br />
<b>Donate</b><br />
Bleach7.com is a self-funded community that relies solely on user donations to get through the month. Although donations are not mandatory to download manga, every dollar counts and helps us afford the rising bandwith costs as the website gets more populated each and every day. Please consider [<a href="?page=supportus">helping out to support us</a>].<br />
<br />
</font><font face="Verdana" size="2"><b>Bleach Opening Theme Songs</b><br />
<br /></font>
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Opening 1 - Asterisk by ORANGE RANGE</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><span style="text-decoration:line-through">Download</span></td>
					<td class="MangaMirror" align="center"><span style="text-decoration:line-through">Download</span></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_1_Anime_Version_-_Asterisk_by_Orange_Range.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_1_Anime_Version_-_Asterisk_by_Orange_Range.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_1_Full_Version_-_Asterisk_by_Orange_Range.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_1_Full_Version_-_Asterisk_by_Orange_Range.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_1_-_Asterisk_by_Orange_Range.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_1_-_Asterisk_by_Orange_Range.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Opening 2 - D-tecnolife by UVERworld</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_2_Album.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_2_Album.zip">Download</a></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_2_Anime_Version_-_D-tecnolife_by_UVERworld.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_2_Anime_Version_-_D-tecnolife_by_UVERworld.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_2_Full_Version_-_D-tecnolife_by_UVERworld.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_2_Full_Version_-_D-tecnolife_by_UVERworld.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_2_-_D-tecnolife_by_UVERworld.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_2_-_D-tecnolife_by_UVERworld.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Opening 3 - Ichirin no Hana by High and Mighty Color</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_3_Album.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_3_Album.zip">Download</a></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_3_Anime_Version_-_Ichirin_no_Hana_by_High_and_Mighty_Color.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_3_Anime_Version_-_Ichirin_no_Hana_by_High_and_Mighty_Color.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_3_Full_Version_-_Ichirin_no_Hana_by_High_and_Mighty_Color.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_3_Full_Version_-_Ichirin_no_Hana_by_High_and_Mighty_Color.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Opening_3_-_Ichirin_no_Hana_by_High and Mighty Color.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Opening_3_-_Ichirin_no_Hana_by_High and Mighty Color.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<font face="Verdana" size="2"><b>Bleach Closing Theme Songs</b><br />
<br /></font>
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Closing 1 - Life is Like a Boat by Rei Fu</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><span style="text-decoration:line-through">Download</span></td>
					<td class="MangaMirror" align="center"><span style="text-decoration:line-through">Download</span></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_1_Anime_Version_-_Life_is_Like_a_Boat_by_Rei_Fu..zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_1_Anime_Version_-_Life_is_Like_a_Boat_by_Rei_Fu..zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_1_Full_Version_-_Life_is_Like_a_Boat_by_Rei_Fu..zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_1_Full_Version_-_Life_is_Like_a_Boat_by_Rei_Fu..zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_1_-_Life_is_Like_a_Boat_by_Rei_Fu.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_1_-_Life_is_Like_a_Boat_by_Rei_Fu.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Closing 2 - Thank You! by Home Made Kazoku</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><span style="text-decoration:line-through">Download</span></td>
					<td class="MangaMirror" align="center"><span style="text-decoration:line-through">Download</span></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_2_Anime_Version_-_Thank_You!_by_Home_Made_Kazoku.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_2_Anime_Version_-_Thank_You!_by_Home_Made_Kazoku.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_2_Full_Version_-_Thank_You!_by_Home_Made_Kazoku.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_2_Full_Version_-_Thank_You!_by_Home_Made_Kazoku.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_2_-_Thank_You!_by_Home_Made_Kazoku.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_2_-_Thank_You!_by_Home_Made_Kazoku.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Closing 3 - Houkiboshi (Abandoned Star) by Younha</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="17"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Ending_3_Album.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Ending_3_Album.zip">Download</a></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Anime_Version_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Anime_Version_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Full_Version_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Full_Version_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 01</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_01_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_01_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 02</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_02_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_02_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 03</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_03_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_03_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 04</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_04_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_04_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 05</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_05_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_05_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 06</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_06_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_06_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 07</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_07_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_07_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 08</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_08_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_08_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 09</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_09_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_09_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 10</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_10_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_10_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 11</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_11_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_11_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 12</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_12_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_12_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime - Division 13</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_3_Division_13_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_3_Division_13_-_Houkiboshi_(Abandoned_Star)_by_Younha.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Closing 4 - Happy People by Skoop on Somebody</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Ending_4_Album.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Ending_4_Album.zip">Download</a></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_4_Anime_Version_-_Happy_People_by_Skoop_on_Somebody.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_4_Anime_Version_-_Happy_People_by_Skoop_on_Somebody.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_4_Full_Version_-_Happy_People_by_Skoop_on_Somebody.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_4_Full_Version_-_Happy_People_by_Skoop_on_Somebody.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_4_-_Happy_People_by_Skoop_on_Somebody.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_4_-_Happy_People_by_Skoop_on_Somebody.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Closing 5 - Life by Yui</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Ending_5_Album.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Ending_5_Album.zip">Download</a></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_5_Anime_Version_-_Life_by_Yui.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_5_Anime_Version_-_Life_by_Yui.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_5_Full_Version_-_Life_by_Yui.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_5_Full_Version_-_Life_by_Yui.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_5_-_Life_by_Yui.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_5_-_Life_by_Yui.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td><b>- Closing 6 - My Pace by SunSet Swish</b></td>
	</tr>
	<tr>
		<td>
			<table border="0" width="483" cellspacing="0" cellpadding="0">
				<tr>
					<td class="MangaPic" rowspan="5"></td>
					<td class="MangaChapterNumber" align="center">Album</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=OP/Ending_6_Album.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=OP/Ending_6_Album.zip">Download</a></td>
					<td class="MangaDonation" align="center"></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center"><b>Type</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
					<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
					<td class="MangaDonation" align="center"><b>Support Us</b></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">TV Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_6_Anime_Version_-_My_Pace_by_SunSet_Swish.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_6_Anime_Version_-_My_Pace_by_SunSet_Swish.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Full Version</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_6_Full_Version_-_My_Pace_by_SunSet_Swish.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_6_Full_Version_-_My_Pace_by_SunSet_Swish.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
				<tr>
					<td class="MangaChapterNumber" align="center">Anime</td>
					<td	class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=ED/Ending_6_-_My_Pace_by_SunSet_Swish.zip">Download</a></td>
					<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=ED/Ending_6_-_My_Pace_by_SunSet_Swish.zip">Download</a></td>
					<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<font face="Verdana" size="2"><b>Bleach Beat Collection</b><br />
<br /></font>
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Bleach Beat Collection 1 - Kurosaki Ichigo</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="11" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Bleach Beat Collection 1 - Kurosaki Ichigo" style="width: 100px; height: 100px; vertical-align:top; border: none;" /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/Bleach_Beat_Collection_1_-_Kurosaki_Ichigo.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=BBC_Ichigo/Bleach_Beat_Collection_1_-_Kurosaki_Ichigo.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - My Blade As My Pride</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/01_-_My_Blade_As_My_Pride.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/01_-_My_Blade_As_My_Pride.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Tattoos on the Sky</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/02_-_Tattoos_on_the_Sky.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/02_-_Tattoos_on_the_Sky.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - Memories in the Rain</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/03_-_Memories_in_the_Rain.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/03_-_Memories_in_the_Rain.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - My Blade As My Pride (Instrumental Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/04_-_My_Blade_As_My_Pride_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ichigo/04_-_My_Blade_As_My_Pride_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Bleach Beat Collection 2 - Abarai Renji</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="11" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Bleach Beat Collection 2 - Abarai Renji" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/Bleach_Beat_Collection_2_-_Abarai_Renji.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=BBC_Renji/Bleach_Beat_Collection_2_-_Abarai_Renji.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - Rosa Rubicundior, Lilio Candidior</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/01_-_Rosa_Rubicundior,_Lilio_Candidior.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/01_-_Rosa_Rubicundior,_Lilio_Candidior.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Standing To Defend You</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/02_-_Standing_To_Defend_You.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/02_-_Standing_To_Defend_You.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - Gomi Tamemitai na Machi de Oretachi wa Deatta</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/03_-_Gomi_Tamemitai_na_Machi_de_Oretachi_wa_Deatta.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/03_-_Gomi_Tamemitai_na_Machi_de_Oretachi_wa_Deatta.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Rosa Rubicundior, Lilio Candidior (Instrumental Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/04_-_Rosa_Rubicundior,_Lilio_Candidior_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Renji/04_-_Rosa_Rubicundior,_Lilio_Candidior_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Bleach Beat Collection 3 - Ishida Uryu</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="11" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Bleach Beat Collection 3 - Ishida Uryu" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/Bleach_Beat_Collection_3_-_Ishida_Uryu.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=BBC_Ishida/Bleach_Beat_Collection_3_-_Ishida_Uryu.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - Quincy no Hokori ni Kakete</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/01_-_Quincy_no_Hokori_ni_Kakete.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/01_-_Quincy_no_Hokori_ni_Kakete.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Aesthetics and Identity</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/02_-_Aesthetics_and_Identity.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/02_-_Aesthetics_and_Identity.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - Suigintou no Yoru</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/03_-_Suigintou_no_Yoru.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/03_-_Suigintou_no_Yoru.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Quincy no Hokori ni Kakete (Original Karaoke)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/04_-_Quincy_no_Hokori_ni_Kakete_(Original_Karaoke).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Ishida/04_-_Quincy_no_Hokori_ni_Kakete_(Original_Karaoke).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Bleach Beat Collection 4 - Hanataro Yamada &amp; Kon</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="11" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Bleach Beat Collection 4 - Hanataro Yamada &amp; Kon" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/Bleach_Beat_Collection_4_-_Hanataro_Yamada_&amp;_Kon.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=BBC_Hanataro-Kon/Bleach_Beat_Collection_4_-_Hanataro_Yamada_&amp;_Kon.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - Shimpainai Oneesan</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/01_-_Shimpainai_Oneesan.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/01_-_Shimpainai_Oneesan.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Hanataro desu</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/02_-_Hanataro_Desu.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/02_-_Hanataro_Desu.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - LIONS NEVER SURRENDER</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/03_-_Lions_Never_Surrender.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/03_-_Lions_Never_Surrender.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Shimpainai Oneesan (Instrumental Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/04_-_Shimpainai_Oneesan_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Hanataro-Kon/04_-_Shimpainai_Oneesan_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Bleach Beat Collection 5- Gin Ichimaru</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="11" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Volume 01" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/Bleach_Beat_Collection_5_-_Ichigmaru_Gin.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=BBC_Gin/Bleach_Beat_Collection_5_-_Ichigmaru_Gin.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - Sekai wa Sude ni Azamuki no Ue ni</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/01_-_Sekai_wa_Sude_ni_Azamuki_no_Ue_ni.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/01_-_Sekai_wa_Sude_ni_Azamuki_no_Ue_ni.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Fuyu no Hanabi feat RANGIKU</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/02_-_Fuyu_no_Hanabi_feat._Rangiku.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/02_-_Fuyu_no_Hanabi_feat._Rangiku.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - Hyouri</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/03_-_Hyouri.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/03_-_Hyouri.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Sekai wa Sude ni Azamuki no Ue ni (Instrumental Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/04_-_Sekai_wa_Sude_ni_Azamuki_no_Ue_ni_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=BBC_Gin/04_-_Sekai_wa_Sude_ni_Azamuki_no_Ue_ni_(Instrumental_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
</table>
<br />
<font face="Verdana" size="2"><b>Radio DJCD Bleach B Station</b><br />
<br /></font>
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Radio DJCD Bleach B Station Volume 1</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="16" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Radio DJCD Bleach B Station Volume 1" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/Radio_DJCD_Bleach_B_Station_Vol_1.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=RADIO_DJ/Radio_DJCD_Bleach_B_Station_Vol_1.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - Opening Talk</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/01_-_Opening_Talk.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/01_-_Opening_Talk.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Fumiko Orikasa On The Air</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/02_-_Fumiko_Orikasa_On_The_Air.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/02_-_Fumiko_Orikasa_On_The_Air.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - Kentaro Ito On The Air</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/03_-_Kentaro_Ito_On_The_Air.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/03_-_Kentaro_Ito_On_The_Air.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Mitsuaki Madono On The Air</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/04_-_Mitsuaki_Madono_On_The_Air.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/04_-_Mitsuaki_Madono_On_The_Air.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
	<tr>
		<td colspan="4">05 - Bonus Track Intro ~Good Vibrations From Bleach-FM~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/05_-_Bonus_Track_Intro_~Good_Vibrations_From_Bleach-FM~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/05_-_Bonus_Track_Intro_~Good_Vibrations_From_Bleach-FM~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
	<tr>
		<td colspan="4">06 - Gomi Tame Mitai Na Machi De Oretachi Wa Deatta ~Liquid Groove Mix~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/06_-_Gomi_Tame_Mitai_Na_Machi_De_Oretachi_Wa_Deatta_~Liquid_Groove_Mix~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ/06_-_Gomi_Tame_Mitai_Na_Machi_De_Oretachi_Wa_Deatta_~Liquid_Groove_Mix~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
</table>
<br />
<br />
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Radio DJCD Bleach B Station Volume 2</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="14" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Radio DJCD Bleach B Station Volume 2" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/Radio_DJCD_Bleach_B_Station_Vol_2.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=RADIO_DJ2/Radio_DJCD_Bleach_B_Station_Vol_2.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - Opening Talk ~To-Ku no Mori de Yahho~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/01_-_Opening_Talk_~To-Ku_No_Mori_De_Yahho~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/01_-_Opening_Talk_~To-Ku_No_Mori_De_Yahho~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - Fumihiko Tachiki On The Air ~Futari wa Tsuri Tomodachi!~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/02_-_Fumihiko_Tachiki_On_The_Air_~Futari_Wa_Tsuri_Tomodachi!~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/02_-_Fumihiko_Tachiki_On_The_Air_~Futari_Wa_Tsuri_Tomodachi!~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03. Kouki Miyata On The Air ~Bleach Ecchi Hanataro Station~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/03_-_Kouki_Miyata_On_The_Air_~Bleach_Ecchi_Hanataro_Station~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/03_-_Kouki_Miyata_On_The_Air_~Bleach_Ecchi_Hanataro_Station~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Bonus Track Intro ~Zenryaku Gake no Ue Yori Hizou Demo Ryuushutsu~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/04_-_Bonus_Track_Intro_~Zenryaku_Gake_No_Ue_Yori_Hizou_Demo_Ryuushutsu~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/04_-_Bonus_Track_Intro_~Zenryaku_Gake_No_Ue_Yori_Hizou_Demo_Ryuushutsu~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
	<tr>
		<td colspan="4">05 - Hanataro desu ~REMIX desu. Version~</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/05_-_Hanataro_desu_~REMIX_desu._Version~.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=RADIO_DJ2/05_-_Hanataro_desu_~REMIX_desu._Version~.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
</table>
<br />
<font face="Verdana" size="2"><b>Bleach Original Soundtrack (OST)</b><br />
<br /></font>
<table border="0" width="483" cellspacing="0" cellpadding="0">
	<tr>
		<td class="MangaTitle" colspan="5"><b>- Bleach Original Soundtrack 1</b></td>
	</tr>
	<tr>
	<tr>
		<td rowspan="53" class="MangaPic" style="vertical-align: top"><a href="media/images/nopic.jpg"><img src="media/images/nopic_t.jpg" alt="Bleach Original Soundtrack 1" style="width: 100px; height: 100px; vertical-align:top; border: none;"  /></a></td>
		<td class="MangaChapterNumber" align="center">Album</td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/Bleach_Original_Soundtrack_1.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror2&amp;file=Soundtrack/Bleach_Original_Soundtrack_1.zip">Download</a></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"><b>Song Name</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 1</b></td>
		<td class="MangaMirror" align="center"><b>Mirror 2</b></td>
		<td class="MangaDonation" align="center"><b>Support Us</b></td>
	</tr>
	<tr>
		<td class="MangaChapterNumber" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaMirror" align="center"></td>
		<td class="MangaDonation" align="center"></td>
	</tr>
	<tr>
		<td colspan="4">01 - On The Precipice Of Defeat</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/01_-_On_The_Precipice_Of_Defeat.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/01_-_On_The_Precipice_Of_Defeat.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">02 - ~Asterisk (OST Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/02_-_~Asterisk_(OST_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/02_-_~Asterisk_(OST_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">03 - Comical World</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/03_-_Comical_World.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/03_-_Comical_World.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">04 - Oh So Tired</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/04_-_Oh_So_Tired.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/04_-_Oh_So_Tired.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>	
	<tr>
		<td colspan="4">05 - Head In The Clouds</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/05_-_Head_In_The_Clouds.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/05_-_Head_In_The_Clouds.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">06 - Ditty For Daddy</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/06_-_Ditty_For_Daddy.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/06_-_Ditty_For_Daddy.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">07 - Creeping Shadows</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/07_-_Creeping_Shadows.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/07_-_Creeping_Shadows.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">08 - Raw Breath Of Danger</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/08_-_Raw_Breath_Of_Danger.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/08_-_Raw_Breath_Of_Danger.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">09 - Enemy Unseen</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/09_-_Enemy_Unseen.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/09_-_Enemy_Unseen.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">10 - Will Of The Heart</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/10_-_Will_Of_The_Heart.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/10_-_Will_Of_The_Heart.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">11 - Requiem For The Lost Ones</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/11_-_Requiem_For_The_Lost_Ones.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/11_-_Requiem_For_The_Lost_Ones.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">12 - Nothing Can Be Explained (Vocal Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/12_-_Nothing_Can_Be_Explained_(Vocal_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/12_-_Nothing_Can_Be_Explained_(Vocal_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">13 - Burden Of The Past</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/13_-_Burden_Of_The_Past.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/13_-_Burden_Of_The_Past.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">14 - Destiny Awaits</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/14_-_Destiny_Awaits.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/14_-_Destiny_Awaits.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">15 - Catch 22</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/15_-_Catch_22.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/15_-_Catch_22.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">16 - Heat Of The Battle</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/16_-_Heat_Of_The_Battle.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/16_-_Heat_Of_The_Battle.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">17 - Blaze Of The Soul Reaper</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/17_-_Blaze_Of_The_Soul_Reaper.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/17_-_Blaze_Of_The_Soul_Reaper.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">18 - Battle Ignition</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/18_-_Battle_Ignition.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/18_-_Battle_Ignition.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">19 - Never Meant To Belong</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/19_-_Never_Meant_To_Belong.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/19_-_Never_Meant_To_Belong.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">20 - Storm Center</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/20_-_Storm_Center.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/20_-_Storm_Center.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">21 - Number One (Vocal Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/21_-_Number_One_(Vocal_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/21_-_Number_One_(Vocal_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">22 - Going Home</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/22_-_Going_Home.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/22_-_Going_Home.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">23 - Life is Like a Boat (TV Edit Fast Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/23_-_Life_is_Like_a_Boat_(TV_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/23_-_Life_is_Like_a_Boat_(TV_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">24 - Peaceful Afternoon</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/24_-_Peaceful_Afternoon.zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/24_-_Peaceful_Afternoon.zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
	<tr>
		<td colspan="4">25 - Thank You!! (TV Size Version)</td>
	</tr>
	<tr>
		<td></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/25_-_Thank_You!!_(TV_Version).zip">Download</a></td>
		<td class="MangaMirror" align="center"><a href="/download/music.php?id=mirror1&amp;file=Soundtrack/25_-_Thank_You!!_(TV_Version).zip">Download</a></td>
		<td class="MangaDonation" align="center"><a href="https://www.paypal.com/xclick/business=donate@bleach7.com&amp;item_name=Bleach7.com&amp;no_note=1&amp;tax=0&amp;currency_code=USD">Donate</a></td>
	</tr>
</table>