<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Spell Guide</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Spell Guide:</b> </span><span class="VerdanaSize1Main"><b>[Last Updated: 10/01/05]</b><br />
<br />
� <a href="?page=information/demonarts"> Demon Arts</a>, (All)<br />
� <a href="?page=information/destructivearts">Destructive Arts</a>, (All)<br />
� <a href="?page=information/jigokuchos">Jigoku Chos</a>, (aka; butterflies from hell)<br />
� <a href="?page=information/shyunpa">Shyunpa</a><br />
� <a href="?page=information/shyunshin">Shyunshin Yoruichi</a>, (God of Shyunpo)</span>