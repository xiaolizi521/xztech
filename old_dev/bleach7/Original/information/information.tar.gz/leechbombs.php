<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Weapons &gt; Leech Bombs</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Leech Bombs</b></span><span class="VerdanaSize1Main"><br />
<br />
Leech bombs, used by the [hollow] Shrieker, are bombs that consist in the little mini-hollow's that follow him around. They are quite useful in battle, as they mini-hollows attack the opponent and as they get killed, there body sends out these little &quot;leeches&quot;, of which attach themselves directly to the opponent. When there are a desired number attached, Shrieker sticks out his tongue and uses it as an instrument to make the certain noise that will make the leeches explode on the target/opponent.</span>