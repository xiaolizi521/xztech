<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou&gt; Manga</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Manga Zanpaktou Guide</b></span><span class="VerdanaSize1Main"><br />
<br />
<br />
This section is divided between the Captain, the Vice Captain, Arrancar, Visored, 
and other Shingamis guides.<br />

</span> 
<table cellspacing="6" cellpadding="4" id="mangacaptain">
	<tr>&nbsp; </tr>
	<tr>
		<td>
			
      <div align="center"><a href="?page=information/guide/manga"><font size="3"><b> 
        Captain Guide</b></font><br>
        
				<img src="/information/guide/manga.jpg" alt="" class="mangamain" border="0"></a>
			</div></td>
	
		<td>
			
      <div align="center"><a href="?page=information/guide/mangavc"><font size="3"><b> 
        Vice Captain Guide</b></font><br />
        
				<img src="/information/guide/mangavc.jpg" alt="" class="mangamain" border="0"></a>
			</div></td>
	</tr>
</table><Br>
<table cellspacing="6" cellpadding="4" id="mangacaptain">
<tr><td><a href="?page=information/guide/war"><font size="2"><center>
        <b>Other Shinigamis</b><b><br>
      </b></center>
      </font></a> <a href="?page=information/guide/mangaothers/others"><img src="/information/guide/otmanga.jpg" alt="" border="0"></a> 
    </td>
    <td><a href="?page=information/guide/war"><font size="2"><b><center>
        Arrancar<br>
      </center>
      </b></font></a> <a href="?page=information/guide/mangaothers/Arankaru"><img src="/information/guide/ar.jpg" alt="" border="0"></a> 
    </td>
    <td><a href="?page=information/guide/war"><font size="2"><b><center>
        Visored<br>
      </center>
      </b></font></a> <a href="?page=information/guide/mangaothers/Visored"><img src="/information/guide/va.jpg" alt="" border="0"></a> 
    </td>
  </tr></table>

	
  <p><br />
  <span class="VerdanaSize2Main"><center><a href="?page=information/bleachcaptainsguide"><- 
  Go back</a></center></span></p>
  <script type="text/javascript"><!--
google_ad_client = "pub-3121363681209965";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "B0E0E6";
google_color_bg = "FFFFFF";
google_color_link = "000000";
google_color_url = "336699";
google_color_text = "333333";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
  
