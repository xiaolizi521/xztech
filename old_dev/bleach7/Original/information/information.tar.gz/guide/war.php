<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Captain & Vice Captain &gt; Manga &gt; 
War</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Manga War Section</b></span><span class="VerdanaSize1Main"><br />
<br />
If you have read the latest manga chapters, then you are probably aware that there's some kind of war incoming in Bleach. <br />So far, we know that it is going to be a war between Visored, Arankaru and Soul Society. Also it seems like Urahara and Isshin are planning to join as well.<br />
<br />
Click the name of the group below to view their members and information.<br />
<br /></span>
<table width="483" border=0 cellpadding=2 cellspacing=5 align="center">
  <tr> 
    <td><font size="2"><a href="?page=information/guide/mangaothers/Arankaru"><span class="CaptainVeranda2"><b>Allankar</b></span></a></font></td>
    <td><font size="2"><a href="?page=information/guide/mangaothers/Visored"><span class="CaptainVeranda2"><b>Visored/Vizards</b></span></a></font></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/mangaothers/SoulSociety"><span class="CaptainVeranda2"><b><font size="2"> 
      Soul Society</font></b></span></a></td>
    <td><a href="?page=information/guide/mangaothers/UICo"><span class="CaptainVeranda2"><b><font size="2"> 
      Urahara & Isshin Co.</font></b></span></a></td>
  </tr>
</table>
<p>&nbsp;</p>This diagram is only a speculation:
<center>

			<IMG SRC="/information/guide/war/images/Untitled-1_03.jpg"></center><br>
<p align="center"><span class="CaptainVeranda3c"><a href="javascript:history.back();"><- Go back</a></span><br />
<span class="VerdanaSize2"><a href="?page=information/guide/animeindex"><b>Anime Section</b></a> | <a href="?page=information/guide/mangaindex"><b>Manga Section</b></a></span></p>