<script>

// Script Source: CodeLifter.com
// Copyright 2003
// Do not remove this notice.

// SETUPS:
// ===============================

// Set the horizontal and vertical position for the popup

PositionX = 100;
PositionY = 100;

// Set these value approximately 20 pixels greater than the
// size of the largest image to be used (needed for Netscape)

defaultWidth  = 500;
defaultHeight = 500;

// Set autoclose true to have the window close automatically
// Set autoclose false to allow multiple popup windows

var AutoClose = true;

// Do not edit below this line...
// ================================
if (parseInt(navigator.appVersion.charAt(0))>=4){
var isNN=(navigator.appName=="Netscape")?1:0;
var isIE=(navigator.appName.indexOf("Microsoft")!=-1)?1:0;}
var optNN='scrollbars=no,width='+defaultWidth+',height='+defaultHeight+',left='+PositionX+',top='+PositionY;
var optIE='scrollbars=no,width=150,height=100,left='+PositionX+',top='+PositionY;
function popImage(imageURL,imageTitle){
if (isNN){imgWin=window.open('about:blank','',optNN);}
if (isIE){imgWin=window.open('about:blank','',optIE);}
with (imgWin.document){
writeln('<html><head><title>Loading...</title><style>body{margin:0px;}</style>');writeln('<sc'+'ript>');
writeln('var isNN,isIE;');writeln('if (parseInt(navigator.appVersion.charAt(0))>=4){');
writeln('isNN=(navigator.appName=="Netscape")?1:0;');writeln('isIE=(navigator.appName.indexOf("Microsoft")!=-1)?1:0;}');
writeln('function reSizeToImage(){');writeln('if (isIE){');writeln('window.resizeTo(100,100);');
writeln('width=100-(document.body.clientWidth-document.images[0].width);');
writeln('height=100-(document.body.clientHeight-document.images[0].height);');
writeln('window.resizeTo(width,height);}');writeln('if (isNN){');       
writeln('window.innerWidth=document.images["George"].width;');writeln('window.innerHeight=document.images["George"].height;}}');
writeln('function doTitle(){document.title="'+imageTitle+'";}');writeln('</sc'+'ript>');
if (!AutoClose) writeln('</head><body bgcolor=000000 scroll="no" onload="reSizeToImage();doTitle();self.focus()">')
else writeln('</head><body bgcolor=000000 scroll="no" onload="reSizeToImage();doTitle();self.focus()" onblur="self.close()">');
writeln('<img name="George" src='+imageURL+' style="display:block"></body></html>');
close();		
}}

</script>
<script language="JavaScript">
  function pop_window() {
  
    window.open('http://bleach7.com', 'popup', 'width=500, height=500, top=100, left=100, menubar=0, scrollbars=0, location=0, toolbar=0,  resizable=0, status=0');
    
  }
</script>

<script type="text/javascript">

/***********************************************
* Switch Content script- � Dynamic Drive (www.dynamicdrive.com)
* This notice must stay intact for legal use. Last updated April 2nd, 2005.
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

var enablepersist="on" //Enable saving state of content structure using session cookies? (on/off)
var collapseprevious="no" //Collapse previously open content when opening present? (yes/no)

var contractsymbol=' ' //HTML for contract symbol. For image, use: <img src="whatever.gif">
var expandsymbol=' ' //HTML for expand symbol.


if (document.getElementById){
document.write('<style type="text/css">')
document.write('.switchcontent{display:none;}')
document.write('</style>')
}

function getElementbyClass(rootobj, classname){
var temparray=new Array()
var inc=0
var rootlength=rootobj.length
for (i=0; i<rootlength; i++){
if (rootobj[i].className==classname)
temparray[inc++]=rootobj[i]
}
return temparray
}

function sweeptoggle(ec){
var thestate=(ec=="expand")? "block" : "none"
var inc=0
while (ccollect[inc]){
ccollect[inc].style.display=thestate
inc++
}
revivestatus()
}


function contractcontent(omit){
var inc=0
while (ccollect[inc]){
if (ccollect[inc].id!=omit)
ccollect[inc].style.display="none"
inc++
}
}

function expandcontent(curobj, cid){
var spantags=curobj.getElementsByTagName("SPAN")
var showstateobj=getElementbyClass(spantags, "showstate")
if (ccollect.length>0){
if (collapseprevious=="yes")
contractcontent(cid)
document.getElementById(cid).style.display=(document.getElementById(cid).style.display!="block")? "block" : "none"
if (showstateobj.length>0){ //if "showstate" span exists in header
if (collapseprevious=="no")
showstateobj[0].innerHTML=(document.getElementById(cid).style.display=="block")? contractsymbol : expandsymbol
else
revivestatus()
}
}
}

function revivecontent(){
contractcontent("omitnothing")
selectedItem=getselectedItem()
selectedComponents=selectedItem.split("|")
for (i=0; i<selectedComponents.length-1; i++)
document.getElementById(selectedComponents[i]).style.display="block"
}

function revivestatus(){
var inc=0
while (statecollect[inc]){
if (ccollect[inc].style.display=="block")
statecollect[inc].innerHTML=contractsymbol
else
statecollect[inc].innerHTML=expandsymbol
inc++
}
}

function get_cookie(Name) { 
var search = Name + "="
var returnvalue = "";
if (document.cookie.length > 0) {
offset = document.cookie.indexOf(search)
if (offset != -1) { 
offset += search.length
end = document.cookie.indexOf(";", offset);
if (end == -1) end = document.cookie.length;
returnvalue=unescape(document.cookie.substring(offset, end))
}
}
return returnvalue;
}

function getselectedItem(){
if (get_cookie(window.location.pathname) != ""){
selectedItem=get_cookie(window.location.pathname)
return selectedItem
}
else
return ""
}

function saveswitchstate(){
var inc=0, selectedItem=""
while (ccollect[inc]){
if (ccollect[inc].style.display=="block")
selectedItem+=ccollect[inc].id+"|"
inc++
}

document.cookie=window.location.pathname+"="+selectedItem
}

function do_onload(){
uniqueidn=window.location.pathname+"firsttimeload"
var alltags=document.all? document.all : document.getElementsByTagName("*")
ccollect=getElementbyClass(alltags, "switchcontent")
statecollect=getElementbyClass(alltags, "showstate")
if (enablepersist=="on" && ccollect.length>0){
document.cookie=(get_cookie(uniqueidn)=="")? uniqueidn+"=1" : uniqueidn+"=0" 
firsttimeload=(get_cookie(uniqueidn)==1)? 1 : 0 //check if this is 1st page load
if (!firsttimeload)
revivecontent()
}
if (ccollect.length>0 && statecollect.length>0)
revivestatus()
}

if (window.addEventListener)
window.addEventListener("load", do_onload, false)
else if (window.attachEvent)
window.attachEvent("onload", do_onload)
else if (document.getElementById)
window.onload=do_onload

if (enablepersist=="on" && document.getElementById)
window.onunload=saveswitchstate

</script>


<script language="javascript">
function fetch(url) {
		window.open(url,'VideoWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=600,height=320');
		}
</script>
<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<p><span class="VerdanaSize1Main"> <br />
  <b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou&gt; Manga &gt; Arrancar</b><br />
  <br />
  </span><span class="VerdanaSize2Main"><b><font size="2">Arrancar</font></b></span> 
  <br />
  <br />
  <br />
  <span class="VerdanaSize1Main">&nbsp; Arrancar are a group 
  of hollows who remove their masks in order to obtain Shinigamis powers; Arrancar are hollow-shinigami hybrids. The Arrancar who removed 
  their masks and obtained the power of a Shinigami have been few in numbers. </span></p>
<p><span class="VerdanaSize1Main">Previous captain of the 5th division, Aizen 
  Sousuke, after obtaining Hougyoku was taken along with Ichimaru Gin and Tousen 
  to the hollow's place (Hueco Mundo). By using Hougyoku powers, now he is trying 
  to create more powerful Arrancar.</span><br>
  <span class="VerdanaSize1Main"><Br>
  The existing hollows (Menos) could be divided into three categories:
  <br>
  </span><span class="VerdanaSize1Main">&nbsp;&nbsp;- <a href="javascript:popImage('/information/guide/war/gillan.jpg','Gillan')">Gillian 
  (Menos Grandes)</a> - They are no match for captain level shinigami since they 
  relay on a primitive intellect</span><br>
  &nbsp;&nbsp;- Ajuukaru - Smaller than Gillian but far superior both intellectually 
  and in combat. Not many of them exist.<Br>
  &nbsp;&nbsp;- Vastoorode - Most humanoid and the most powerful type of hollow. 
  Only few of them exists and they've manifested only in Hueco Mundo. 10 of them 
  would bring a total chaos to the Soul Society. </p>
<p>It is unclear whether Aizen Sousuke transformed any Vastoorodes into Arrancars

<p>The most deadly Arrancars are numbered from 1 to 10. They have the most amazing 
  and destructive abilities. The chosen ten are called Espada and they order around the rest of  Arrancars.</p>

So far we know the following members:
<p><b>Leader</b>: <a href="javascript:fetch('/information/guide/mangaothers/ar/aiz.php')">Aizen Sousuke</a> followed by <a href="javascript:fetch('/information/guide/mangaothers/ar/ich.php')">Ichimaru Gin</a> and <a href="javascript:fetch('/information/guide/mangaothers/ar/tou.php')">Tousen Kaname</a>. 


<p><b>Espada (1-10):</b> <a href="javascript:fetch('/information/guide/mangaothers/ar/ul.php')">Ulquiorra</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/grim.php')">Grimmjow</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/yam.php')"> Yamii</a>
  <br>
 
  <b>Other Arrancars (11-20):</b> <a href="javascript:fetch('/information/guide/mangaothers/ar/wan.php')">Wonderweiss Marujera</a>    <Br>
  <b>Deceased Arrancars:</b> <a href="javascript:fetch('/information/guide/mangaothers/ar/rup.php')"> Luppi</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/dei.php')"> Deiroy</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/sha.php')"> Shaolon</a>, 
  <a href="javascript:fetch('/information/guide/mangaothers/ar/id.php')"> Idolad</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/ill.php')"> Illfort</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/nak.php')"> Nakim</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/grand.php')"> Grand Fisher</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/ice.php')"> Iceringer</a>, <a href="javascript:fetch('/information/guide/mangaothers/ar/dem.php')"> Demoura</a>
  <br>
  <br><center><img src="/information/guide/mangaothers/arpic.jpg"><B> Espada</b><Br></center>
  