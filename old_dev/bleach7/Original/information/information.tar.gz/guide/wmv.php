<?php
$download_source = "http://38.101.154.66/~bleach7/wmv";
$download_id = $_GET[id];
$download_url = "$download_source/$download_id.wmv";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html><head><title>Video Preview</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="3_files/theme.htm" type="text/css"></head>

<body leftmargin="0" topmargin="0" bgcolor="#333333" marginheight="0" marginwidth="0">

<embed src="<?php echo "$download_url" ?>"

    type="video/x-ms-wvx"
    name="MediaPlayer1"
    http://www.microsoft.com/windows/windowsmedia/download/AllDownloads.aspx?displang=en&qstechnology=showstatusbar="1" 
	id='mediaPlayer' 
	name='mediaPlayer' 
	displaysize='4' 
	autosize='-1' 
	bgcolor='darkblue' 
	showcontrols="true" 
	showtracker='-1' 
	showdisplay='0' 
	showstatusbar='-1' 
	videoborder3d='-1' 
	width="320" 
	height="285"
	autostart="true" 
	designtimesp='5311' 
	loop="false">

</embed>  
</body></html>
