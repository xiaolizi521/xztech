<?php
####################################################################
# AR Download Manager 			 	                               #
# Created By: Thomas of Anime Reporter - http://animereporter.com  #
#  Copyright Anime Reporter. All Rights Reserved.                   #
# THIS IS A FREE SCRIPT BUT THIS HEADER ALONG  WITH ANY COPYRIGHT   #
# NOTICES REGARDING THIS SCRIPT SHOULD STAY INTACT AT ALL TIMES    #
####################################################################

// ****** VARIABLES ******
//These are all  variables that are used throughout the script.
//Input the appropriate values in between the double quotes - "like  this"


// This is the url of your website and used to prevent leechers from downloading your files.
// It should  be in this format: http://yoursiteurl
$download_site = "bleach7.com";


// This is the number of seconds that are  allowed for each download. This means that a user can only download a file every x seconds.
$download_timeout =  30;


// These are the urls of the files to be downloaded from. These urls should be owned by you as leeching from  another site is prohibited.
// URLS should be full paths so it should start with: http:// BUT it must not end in  a "/".
// To add new urls, put this on a new line per url: $download[variablename] = "someurl";
// You can put  anything in the "variablename" part and in turn, the download url would be like:  http://yoursite.com/download/download.php?id=variablenamehere&file=somefile
//$download[mirror1] = "http://66.90.118.110/~bleach7/volume";
$download[mirror1] = "http://38.101.154.66/~bleach7/volume";
$download[mirror2] = "http://67.159.5.68/~bleach7/volume";




// ****** DO NOT EDIT PAST THIS POINT ******

include (  "functions.php" );
$download_id = $_GET[id];
$download_file = $_GET[file];
$download_source =  $download[$download_id];
$download_url = "$download_source/$download_file";
$time_countdown = ( $download_timeout  - ( time() - $_SESSION[download_time] ) );
$referer_site_parse = parse_url ( $GLOBALS[HTTP_REFERER] );
$referer_site = ereg_replace ( "http://|http://www.|www.", "", $referer_site_parse[host] );

$error_msg = "<font  face='Times New Roman'><h1>Error</h1><p> File does not exist or hasn't been specified.</font>";

$error_msg_leecher = "<font face='Times New Roman'><h1>Leeching Site -  $referer_site_parse[scheme]://$referer_site_parse[host]</h1><p> The site that you have attempted to download this  file from is leeching this file from <a href='$download_site' target='_blank'>$download_site</a><p>
The leeching  site has been logged and will be notified to the leeched site.<p>
Sorry for the inconvenience.<p>
In order to  download this file, <a href='$GLOBALS[PHP_SELF]?$GLOBALS[QUERY_STRING]'>click here</a></font>";

if ( isset (  $GLOBALS[HTTP_REFERER] ) ) {
if ( !ereg ( $referer_site, $download_site ) ) {
LogLeecher();
echo  "$error_msg_leecher";
exit();
}
}

if ( $_COOKIE[type] != 3 ) {
TimeLimit( "$download_timeout" );
}

if ( ( !isset  ( $download_id ) || empty ( $download_id ) ) || ( !isset ( $download_file ) || empty ( $download_file ) ) ) {
echo  $error_msg;
exit();
} elseif ( !$fp = @fopen ( $download_url, 'r' ) ) {
echo $error_msg;
exit();
} else {

$download_path = $download_url;


// Fixed to stop server bandwidth usage going through the roof....

header  ("Location: {$download_url}");
die();

////

$download_filename = basename ( $download_path );

//The code below  is a slightly modified version of Chad Lieberman's "Remote File Size" found here:  http://px.sklar.com/code.html?id=730&fmt=pl
$url = "$download_path";
$url = parse_url ( $url );
$fp = fsockopen (  $url[host], 80, $errno, $errstr, 30 );
socket_set_blocking( $fp, TRUE );
fwrite ( $fp, "HEAD $url[path]  HTTP/1.0\r\nHost: $url[host]\r\n\r\n" );
for ( $result = ""; !feof ( $fp ); $result .= fread ( $fp, 1000000 ) );
fclose ( $fp );
if ( preg_match ( "/content-length:\\s?(\\d+)/i", $result, $match ) ) {
$download_filesize =   $match[1];
} else {
$download_filesize =  0;
}

header ( "Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
header (  "Last-Modified: ".gmdate ( "D, d M Y H:i:s" )."GMT" );
header ( "Pragma: no-cache" );
header ( "Cache-Control:  no-store, no-cache, must-revalidate" );
header ( "Cache-Control: post-check=0, pre-check=0", false );
header (  "Content-Type: application/download" );
header ( "Content-Disposition: attachment;  filename=".$download_filename."" );
header ( "Content-Transfer-Encoding: binary" );
header ( "Content-Length:  ".$download_filesize."" );
header ( "Location: $download_url" );

fclose ( $fp );

exit();
}

?>
