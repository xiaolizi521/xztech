<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou &gt; Anime &gt; Others</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Other Shinigamis and their Zanpaktous.</b></span> <span class="VerdanaSize1Main"> 
<br />
<p><span class="VerdanaSize2Main"></a>This section contains information that have 
  been shown in the anime.</b></span><span class="VerdanaSize1Main"><br />
Hint: Shikai is the  Initial Zanpaktou release, and Ban Kai is the Final Zanpaktou release.<br />
Not everyones Zanpaktou have been introduced yet in the anime, and we don't like to spoil anime watchers :).<br />
<br />
<br />
</span><span class="Veranda2Redl"><b>Click on the Zanpaktous name, Shikai or Bankai name to view the picture/video. Please be patient while the video loads.</b><br /></span></p>
<span class="VerdanaSize1Main">&nbsp;<img src="/information/guide/jpg.gif" alt="" border="0" /> - picture  |  <img src="/information/guide/wmv.gif" alt="" border="0" /> - video <br />
&nbsp;'????' means that there is a picture, but the name wasn't revealed yet.<br />
<br /></span>
<table width="483" border=0 cellpadding=2 cellspacing=5 align="center">
  <tr> 
    <td><a href="?page=information/guide/animeothers/Ichigo"><span class="CaptainVeranda2"><b><font size="2"> 
      Kurosaki Ichigo</font></b></span></a></td>
    <td><a href="?page=information/guide/animeothers/Ikkaku"><span class="CaptainVeranda2"><b><font size="2"> 
      Madarame Ikkaku</font></b></span></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animeothers/Rukia"><span class="CaptainVeranda2"><b><font size="2"> 
      Kuchiki Rukia</font></b></span></a></td>
    <td><a href="?page=information/guide/animeothers/Jiroubo"><span class="CaptainVeranda2"><b><font size="2"> 
      Ikkanzaka Jiroubo</font></b></span></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animeothers/Yumichika"><span class="CaptainVeranda2"><b><font size="2"> 
      Ayasegawa Yumichika</font></b></span></a></td>
  </tr>
</table>
<br />
<br />
<br />
<p align="center"><span class="CaptainVeranda3c"><a href="javascript:history.back();">&lt;- Go back</a><br /></span>
<span class="VerdanaSize2"><a href="?page=information/guide/animeindex"><b>Anime Section</b></a> | <a href="?page=information/guide/mangaindex"><b>Manga Section</b></a></span></p>