<link href="/css/transition2.css" rel="stylesheet" type="text/css">
<span class="VerdanaSize1Main">
<br />
<b>Bleach 7 &gt; Information &gt; Bleach Zanpaktou &gt; Anime &gt; Vice Captain</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Anime Vice Captain's Zanpaktou Section</b></span><span class="VerdanaSize1Main"> 
<br />
<p><span class="VerdanaSize2Main"><b>This section contains information that has been shown in the anime.</b></span><span class="VerdanaSize1Main"><br />
Hint: Shikai is the  Initial Zanpaktou release, and Ban Kai is the Final Zanpaktou release.<br />
Not everyones Zanpaktou have been introduced yet in the anime, and we don't like to spoil anime watchers :).<br />
<br />
</span><span class="Veranda2Redl"><b>Click on the Zanpaktous name, Shikai or Bankai name to view the picture/video. Please be patient while the video loads.</b><br /></span></p>
<span class="VerdanaSize1Main">&nbsp;<img src="/information/guide/jpg.gif" alt="" border="0" /> - picture  |  <img src="/information/guide/wmv.gif"  alt="" border="0" /> - video <br />
&nbsp;'????' means that there is a picture, but the name wasn't revealed yet.<br />
<br /></span>
<table width="483" border=0 cellpadding=2 cellspacing=5 align="center">
  <tr> 
    <td><a href="?page=information/guide/animevicecaptains/a01"><font size="2"><img src="/information/guide/division/1.jpg" alt="Division 1" border="0" /><span class="CaptainVeranda2"><b> 
      Sasakibe Choutarou</b></span></font></a></td>
    <td><a href="?page=information/guide/animevicecaptains/a08"><font size="2"><img src="/information/guide/division/8.jpg" alt="Division 8" border="0" /><span class="CaptainVeranda2"><b> 
      Ise Nanao</b></span></font></a></td>
  </tr>
  <td><a href="?page=information/guide/animevicecaptains/a02"><font size="2"><img src="/information/guide/division/2.jpg" alt="Division 2" border="0" /><span class="CaptainVeranda2"><b> 
    Oomaeda Marechiyo</b></span></font></a></td>
  <td><a href="?page=information/guide/animevicecaptains/a09"><font size="2"><img src="/information/guide/division/9.jpg" alt="Division 9" border="0" /><span class="CaptainVeranda2"><b> 
    Hisagi Shuuhei</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animevicecaptains/a03"><font size="2"><img src="/information/guide/division/3.jpg" alt="Division 3" border="0" /><span class="CaptainVeranda2"><b> 
      Kira Izuru</b></span></font></a></td>
    <td><a href="?page=information/guide/animevicecaptains/a10"><font size="2"><img src="/information/guide/division/10.jpg" alt="Division 10" border="0" /><span class="CaptainVeranda2"><b> 
      Matsumoto Rangiku</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animevicecaptains/a04"><font size="2"><img src="/information/guide/division/4.jpg" alt="Division 4" border="0" /><span class="CaptainVeranda2"><b> 
      Koutestu Isane</b></span></font></a></td>
    <td><a href="?page=information/guide/animevicecaptains/a11"><font size="2"><img src="/information/guide/division/11.jpg" alt="Division 11" border="0" /><span class="CaptainVeranda2"><b> 
      Kusajika Yachiru</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animevicecaptains/a05"><font size="2"><img src="/information/guide/division/5.jpg" alt="Division 5" border="0" /><span class="CaptainVeranda2"><b> 
      Hinamori Momo</b></span></font></a></td>
    <td><a href="?page=information/guide/animevicecaptains/a12"><font size="2"><img src="/information/guide/division/12.jpg" alt="Division 12" border="0" /><span class="CaptainVeranda2"><b> 
      Kurotshuchi Nemu</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animevicecaptains/a06"><font size="2"><img src="/information/guide/division/6.jpg" alt="Division 6" border="0" /><span class="CaptainVeranda2"><b> 
      Abarai Renji</b></span></font></a></td>
    <td><a href="?page=information/guide/animevicecaptains/a13"><font size="2"><img src="/information/guide/division/13.jpg" alt="Division 13" border="0" /><span class="CaptainVeranda2"><b> 
      Shiba Kaien (deceased)</b></span></font></a></td>
  </tr>
  <tr> 
    <td><a href="?page=information/guide/animevicecaptains/a07"><font size="2"><img src="/information/guide/division/7.jpg" alt="Division 7" border="0" /><span class="CaptainVeranda2"><b> 
      Iba Tetsuzaemon</b></span></font></a></td>
    <font size="2"></td></font>
</table>
<br />
<br />
<br />
<p align="center"><span class="CaptainVeranda3c"><a href="javascript:history.back();">&lt;- Go back</a><br /></span>
<span class="VerdanaSize2"><a href="?page=information/guide/animeindex"><b>Anime Section</b></a> | <a href="?page=information/guide/mangaindex"><b>Manga Section</b></a></span></p>