<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Spell Guide &gt; Shyunshin Yoruichi</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Shyunshin Yoruichi (God of Shyunpo)</b></span><span class="VerdanaSize1Main"><br />
<br />
A very high level shyunpa. Allows user/shinigami to &quot;warp&quot; themselves much further than that of just a basic Shyunpa spell/technique. This requires the user to train much harder and longer, as well as be much more powerful than if he was just able to use the basic Shyunpa spell(s).</span>