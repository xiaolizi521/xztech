<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach the Movie &gt; General</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>General Information</b></span>
<p style="text-align:center"><img src="http://www.bleach7.com/information/movie/mon.png" alt="mon" style="width: 297px; height: 99px; text-align: center; border: none;" /></p>
<span class="VerdanaSize1Main">Tagline: One hour until the collapse of the world.
<br />
<br />
Release date: December 16, 2006<br />
Theme Song: "Sen no Yoru wo Koete" by Aqua Timez<br />
Distributor: Toho Co., Ltd.<br />
Country of Production: Japan<br />
Language: Japanese<br />
Runtime: 90 minutes<br />
</span>
