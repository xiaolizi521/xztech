<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach the Movie &gt; Characters</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Movie Original Characters</b></span><span class="VerdanaSize1Main"><br />
<br /></span>
<table cellpadding="0" cellspacing="0" style="width: 100%; border: none;" class="VerdanaSize1Main">
	<tr>
		<td style="width: 50%; text-align: center;"><img src="http://www.bleach7.com/information/movie/senna.png" alt="senna" style="width: 125px; height: 309px; border: none;" /><br />
			<b>Senna</b></td>
		<td style="height: 400px; width: 50%; text-align: center;"><img src="http://www.bleach7.com/information/movie/ganryuu.png" alt="ganryuu" style="width: 184px; height: 377px; border: none;" /><br />
			<b>Ganryuu</b><br /></td>
	</tr>
	<tr>
		<td><i>Detailed information coming soon</i></td>
		<td><i>Detailed information coming soon</i></td>
	</tr>
</table>
