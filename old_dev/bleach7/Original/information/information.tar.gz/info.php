<?php
if ( isset ( $_POST['JPChapterTitles_submit'] ) ) {
	$JPChapter_edit = mysql_real_escape_string ( $_POST['JPChapter_edit'] );
	$JPChapter_type = mysql_real_escape_string ( $_POST['JPChapter_type'] );
	// A Volume number is necessary
	if ( empty ( $_POST['vid'] ) ) {
		echo "<script>alert('You must have a Volume Number.  If volume number is not shown, please Add at least the Volume number first.')</script>";
		echo "<script>document.location='?page=information/JPchaptertitles2'</script>";
	}
	else {
		$vid = $_POST['vid'];
	}
	// Encode Volume Titles
	if ( !empty ( $_POST['vtitle'] ) ) {
		// Look for HTML ENTITY ENCODE
		$vtitle = htmlentities ( $_POST['vtitle'], ENT_COMPAT, ISO-8859-1 );
	}
	if ( !empty ( $_POST['cid'] ) ) {
		$cid = $_POST['cid'];
	}
	// Encode Chapter Titles
	if ( !empty ( $_POST['ctitle'] ) ) {
		// Look for HTML ENTITY ENCODE
		$ctitle = htmlentities ( $_POST['ctitle'], ENT_COMPAT, ISO-8859-1 );
	}
	// Choose between "Add", "Edit", or "Delete
	switch ( $JPChapter_edit ) {
		// Add Section
		case "add":
			// Choosing between Chapter or Volume
			switch ( $JPChapter_type ) {
				// When Adding a Chapter
				case "chapter":
					// Test to see if Chapter is in table or not
					$JPChapterTitles_test = mysql_query ( "SELECT `cid` FROM chapter_info WHERE `cid` = $cid" );
					// If not, then add the chapter
					if ( mysql_num_rows ( $JPChapterTitles_test ) == 0 ) {
						$JPChapterTitles_statement = "INSERT INTO `chapter_info` ( `cid`, `volume`, `cJPtitle`, `cVIZtitle` ) VALUES ( $cid, $vid, \"$ctitle\", \"\" );
";
					}
					// If it is, then why either why add, or incorrect chapter number
					else {
						echo "<script>alert('Chapter number already exists. Please select a new number.')</script>";
						echo "<script>document.location='?page=information/JPchaptertitles2'</script>";
					}
					break;
				//When Adding a Volume
				case "volume":
					// Test to see if Volume is in table or not
					$JPChapterTitles_test = mysql_query ( "SELECT `vid` FROM volume_info WHERE `vid` = $vid" );
					echo mysql_num_rows ( $JPChapterTitles_test );
					// If not, then add the volume
					if ( mysql_num_rows ( $JPChapterTitles_test ) == 0 ) {
						$JPChapterTitles_statement = "INSERT INTO `volume_info` (`vid`, `vJPtitle` ) VALUES ( $vid, \"$vtitle\" )";
					}
					// If it is, then why either why add, or incorrect Volume number
					else {
						echo "<script>alert('Volume number already exists. Please select a new number.')</script>";
						echo "<script>document.location='?page=information/JPchaptertitles2'</script>";
					}
					break;
			}
			break;
		// Edit Section
		case "edit":	
			// Choosing between Chapter or Volume
			switch ( $JPChapter_type ) {
				case "chapter":
					$JPChapterTitles_statement = "UPDATE `chapter_info` SET `volume` = \"$vid\", `cJPtitle` = \"$ctitle\" WHERE `cid` = $cid";
					break;
				case "volume":
					$JPChapterTitles_statement = "UPDATE `volume_info` SET `vJPtitle` = \"$vtitle\" WHERE `vid` = $vid";
					break;
			}
			break;
		case "delete":
			switch ( $JPChapter_type ) {
				case "chapter":
					$JPChapterTitles_statement = "DELETE FROM `chapter_info` WHERE `cid` = \"$cid\"";
					break;
				case "volume":
					$JPChapterTitles_statement = "DELETE FROM `volume_info` WHERE `vid` = \"$vid\"";
					break;
			}
			break;
	}
	$JPChapterTitles_sql = mysql_query ( $JPChapterTitles_statement );
	echo "<script>alert('Japanese Chapter/Volume info has been updated')</script>";
	echo "<script>document.location='?page=information/JPchaptertitles2'</script>";
}
if ( isset ( $_POST['VIZChapterTitles_submit'] ) ) {

	$VIZChapter_edit = mysql_real_escape_string ( $_POST['VIZChapter_edit'] );
	$VIZChapter_type = mysql_real_escape_string ( $_POST['VIZChapter_type'] );

	if ( !empty ( $_POST['vid'] ) ) {
		$vid = $_POST['vid'];
	}

	// Encode Volume Titles
	if ( !empty ( $_POST['vtitle'] ) ) {
		// Look for HTML ENTITY ENCODE
		$vtitle = htmlentities ( $_POST['vtitle'], ENT_COMPAT, ISO-8859-1 );
	}

	if ( !empty ( $_POST['cid'] ) ) {
		$cid = $_POST['cid'];
	}

	// Encode Chapter Titles
	if ( !empty ( $_POST['ctitle'] ) ) {
		// Look for HTML ENTITY ENCODE
		$ctitle = htmlentities ( $_POST['ctitle'], ENT_COMPAT, ISO-8859-1 );
	}

	// Choose between "Add", "Edit", or "Delete
	switch ( $VIZChapter_edit ) {
		// Add Section
		case "add":
		// Edit Section
		case "edit":	
			// Choosing between Chapter or Volume
			switch ( $VIZChapter_type ) {
				case "chapter":
					$VIZChapterTitles_statement = "UPDATE `chapter_info` SET `cVIZtitle` = \"$ctitle\" WHERE `cid` = $cid";
					break;
				case "volume":
					$VIZChapterTitles_statement = "UPDATE `volume_info` SET `vVIZtitle` = \"$vtitle\" WHERE `vid` = $vid";
					break;
			}
			break;
		case "delete":
			switch ( $VIZChapter_type ) {
				case "chapter":
					$VIZChapterTitles_statement = "UPDATE `chapter_info` SET `cVIZtitle` = \"\" WHERE `cid` = $cid";
					break;
				case "volume":
					$VIZChapterTitles_statement = "UPDATE `volume_info` SET `vVIZtitle` = \"\" WHERE `vid` = $vid";
					break;
			}
			break;
	}
	$VIZChapterTitles_sql = mysql_query ( $VIZChapterTitles_statement );
	echo "<script>alert('VIZ Chapter/Volume info has been updated')</script>";
	echo "<script>document.location='?page=information/VIZchaptertitles2'</script>";
}
?>