<br />
<b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Episode List</b><br />
<br />
<span class="VerdanaSize2Main"><b>Bleach TV Episode List</b></span><span class="VerdanaSize1Main"><br />
<br />
001. The Day I Became A Shinigami<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinigami ni natchatta hi &#12300;&#27515;&#31070;&#12395;&#12394;&#12387;&#12385;&#12419;&#12387;&#12383;&#26085;&#12301;<br />
<br />
002. A Shinigami's Work<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinigami no oshigoto &#12300;&#27515;&#31070;&#12398;&#12362;&#20181;&#20107;&#12301;<br />
<br />
003. The Older Brother's Wish, the Younger Sister's Wish<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ani no omoi, imouto no omoi &#12300;&#20804;&#12398;&#24819;&#12356;&#12289;&#22969;&#12398;&#24819;&#12356;&#12301;<br />
<br />
004. Cursed Parakeet<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Noroi no inko &#12300;&#21610;&#12356;&#12398;&#12452;&#12531;&#12467;&#12301;<br />
<br />
005. Beat the Invisible Enemy!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mienai teki wo nagure! &#12300;&#35211;&#12360;&#12394;&#12356;&#25973;&#12434;&#27572;&#12428;&#65281;&#12301;<br />
<br />
006. Fight to the Death! Ichigo vs. Ichigo<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shitou! Ichigo vs Ichigo &#12300;&#27515;&#38360;&#65281;&#19968;&#35703;VS&#12452;&#12481;&#12468;&#12301;<br />
<br />
007. Greetings From a Stuffed Toy<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nuigurumi kara KONnichiwa &#12300;&#12396;&#12356;&#12368;&#12427;&#12415;&#12363;&#12425;&#12467;&#12531;&#12395;&#12385;&#12399;&#12301;<br />
<br />
008. June 17, A Memory Of Rain<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rokugatsu juunananichi, ame no kioku &#12300;6&#26376;17&#26085;&#12289;&#38632;&#12398;&#35352;&#25014;&#12301;<br />
<br />
009. Unbeatable Enemy<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Taosenai teki &#12300;&#20498;&#12379;&#12394;&#12356;&#25973;&#12301;<br />
<br />
010. Assault on Trip At Sacred Ground!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Burari reiba totsugeki no tabi! &#12300;&#12406;&#12425;&#12426;&#38666;&#22580;&#31361;&#25731;&#12398;&#26053;!&#12301;<br />
<br />
011. The Legendary Quincy<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Densetsu no Kuinshii &#12300;&#20253;&#35500;&#12398;&#12463;&#12452;&#12531;&#12471;&#12540;&#12301;<br />
<br />
012. A Gentle Right Arm<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yasashii migiude &#12300;&#12420;&#12373;&#12375;&#12356;&#21491;&#33109;&#12301;<br />
<br />
013. Flower and Hollow<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hana to horou &#12300;&#33457;&#12392;&#12507;&#12525;&#12454;&#12301;<br />
<br />
014. Back to Back, A Fight to the Death!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Senaka awase no shitou! &#12300;&#32972;&#20013;&#21512;&#12431;&#12379;&#12398;&#27515;&#38360;&#65281;&#12301;<br />
<br />
015. Kon's Great Plan<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kon no UHAUHA daisakusen &#12300;&#12467;&#12531;&#12398;&#12454;&#12495;&#12454;&#12495;&#22823;&#20316;&#25126;&#12301;<br />
<br />
016. Encounter: Abarai Renji!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abarai Renji, misan! &#12300;&#38463;&#25955;&#20117;&#24651;&#27425;&#12289;&#35211;&#21442;&#65281;&#12301;<br />
<br />
017. Ichigo Dies!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ichigo, shisu! &#12300;&#19968;&#35703;&#12289;&#27515;&#12377;&#65281;&#12301;<br />
<br />
018. Reclaim! The Power of the Shinigami<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Torimodose! Shinigami no chikara! &#12300;&#21462;&#12426;&#25147;&#12379;&#65281;&#27515;&#31070;&#12398;&#21147;!&#12301;<br />
<br />
019. Ichigo Becomes a Hollow!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ichigo, horou ni ochiru! &#12300;&#19968;&#35703;&#12289;&#12507;&#12525;&#12454;&#12395;&#22684;&#12385;&#12427;!&#12301;<br />
<br />
020. The Shadow of Ichimaru Gin<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ichimaru Gin no kage &#12300;&#24066;&#20024;&#12462;&#12531;&#12398;&#24433;&#12301;<br />
<br />
021. Enter! The World of the Shinigami<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Totsunyuu! Shinigami no sekai &#12300;&#31361;&#20837;&#65281;&#27515;&#31070;&#12398;&#19990;&#30028;&#12301;<br />
<br />
022. The Man Who Hates Shinigamis<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinigami wo nikumu otoko &#12300;&#27515;&#31070;&#12434;&#24974;&#12416;&#30007;&#12301;<br />
<br />
023. The Sentence of Rukia, Before the 14th Day<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rukia shokei, juuyokka mae &#12300;&#12523;&#12461;&#12450;&#20966;&#21009;&#12289;14&#26085;&#21069;&#12301;<br />
<br />
024. Assemble! The 13 Divisions<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kesshuu! Gotei 13 tai &#12300;&#32080;&#38598;&#65281;&#35703;&#24311;13&#38538;&#12301;<br />
<br />
025. Penetrate the Centre With an Enormous Bombshell?<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kyodai houdan de chuuou toppa? &#12300;&#24040;&#22823;&#30770;&#24382;&#12391;&#20013;&#22830;&#31361;&#30772;&#65311;&#12301;<br />
<br />
026. Formation! The Worst Tag<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kessei! Saiaku no taggu &#12300;&#32080;&#25104;&#65281;&#26368;&#24746;&#12398;&#12479;&#12483;&#12464;&#12301;<br />
<br />
027. Release the Death Blow!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hisatsu no ichigeki wo hanatsu! &#12300;&#24517;&#27578;&#12398;&#19968;&#25731;&#12434;&#25918;&#12390;&#65281;&#12301;<br />
<br />
028. Orihime is Being Targeted<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nerawareta Orihime &#12300;&#29401;&#12431;&#12428;&#12383;&#32340;&#23019;&#12301;<br />
<br />
029. Breakthrough! The Shinigamis' Encompassing Net<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Toppaseyo! Shinigami houimou &#12300;&#31361;&#30772;&#12379;&#12424;&#65281;&#27515;&#31070;&#21253;&#22258;&#32178;&#12301;<br />
<br />
030. Renji's Confrontation<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tachihadagaru Renji &#12300;&#31435;&#12385;&#12399;&#12384;&#12363;&#12427;&#24651;&#27425;&#12301;<br />
<br />
031. The Resolution to Kill<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kiru tame no kakugo &#12300;&#26028;&#12427;&#28858;&#12398;&#35226;&#24735;&#12301;<br />
<br />
032. Stars and the Stray<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hoshi to noraken &#12300;&#26143;&#12392;&#37326;&#33391;&#29356;&#12301;<br />
<br />
033. Miracle! The Mysterious New Hero<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kiseki! Nazo no shin hiro &#12300;&#22855;&#36321;&#65281;&#35598;&#12398;&#26032;&#12498;&#12540;&#12525;&#12540;&#12301;<br />
<br />
034. Tragedy of Dawn<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yoake no sangeki &#12300;&#22812;&#26126;&#12369;&#12398;&#24808;&#21127;&#12301;<br />
<br />
035. Assasination of Aizen! The Darkness Which Approaches<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Aizen ansatsu! Shinobiyoru yami &#12300;&#34253;&#26579;&#26263;&#27578;&#65281;&#24525;&#12403;&#23492;&#12427;&#38343;&#12301;<br />
<br />
036. Zaraki Kenpachi Approaches!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zaraki Kenpachi semaru! &#12300;&#26356;&#26408;&#21091;&#20843;&#12289;&#36843;&#12427;&#65281;&#12301;<br />
<br />
037. Reason of the Fist<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ken no riyuu &#12300;&#25331;&#12398;&#29702;&#30001;&#12301;<br />
<br />
038. Desperation! The Brokened Zangetsu<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zettai zetsumei! Orareta Zangetsu &#12300;&#32118;&#20307;&#32118;&#21629;&#65281;&#25240;&#12425;&#12428;&#12383;&#26028;&#26376;&#12301;<br />
<br />
039. The Man of Immortality<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fushijin no Otoko &#12300;&#19981;&#27515;&#36523;&#12398;&#30007;&#12301;<br />
<br />
040. The Shinigami Whom Ganju Met<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ganju no mita shinigami &#12300;&#12460;&#12531;&#12472;&#12517;&#12398;&#35211;&#12383;&#27515;&#31070;&#12301;<br />
<br />
041. Reunion, Ichigo and Rukia<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Saikai, Ichigo to Rukia &#12300;&#20877;&#20250;&#12289;&#19968;&#35703;&#12392;&#12523;&#12461;&#12450;&#12301;<br />
<br />
042. Yoruichi, God of Flash, Dances!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shunjin Yoruichi, mau! &#12300;&#30636;&#31070;&#22812;&#19968;&#12289;&#33310;&#12358;&#65281;&#12301;<br />
<br />
043. The Despicable Shinigami<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hiretsu na Shinigami &#12300;&#21329;&#21155;&#12394;&#27515;&#31070;&#12301;<br />
<br />
044. Ishida, Power of Limits!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ishida, kyugen no chikara! &#12300;&#30707;&#30000;&#12289;&#26997;&#38480;&#12398;&#21147;&#65281;&#12301;<br />
<br />
045. Overcome the Limits!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Genkai wo koero! &#12300;&#38480;&#30028;&#12434;&#36234;&#12360;&#12429;&#65281;&#12301;<br />
<br />
046. Authentication! The School of Shinigami<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jitsuroku! Shinigami no gakkou &#12300;&#23455;&#37682;&#65281;&#27515;&#31070;&#12398;&#23398;&#26657;&#12301;<br />
<br />
047. The Avengers<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adautsu monotachi &#12300;&#20167;&#35342;&#12388;&#32773;&#12383;&#12385;&#12301;<br />
<br />
048. Hitsugaya roars!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hitsugaya, hoeru! &#12300;&#26085;&#30058;&#35895;&#12289;&#21564;&#12360;&#12427;&#65281;&#12301;<br />
<br />
049. Rukia's Nightmare<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rukia no akumu &#12300;&#12523;&#12461;&#12450;&#12398;&#24746;&#22818;&#12301;<br />
<br />
050. The Awakening Lion<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yomigaru shishi &#12300;&#12424;&#12415;&#12364;&#12360;&#12427;&#29509;&#23376;&#12301;<br />
<br />
051. Morning of the Sentence<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shokei no asa &#12300;&#20966;&#21009;&#12398;&#26397;&#12301;<br />
<br />
052. Renji, Oath of the Soul! Death Match with Byakuya<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Renji, tamashii no chikai! Byakuya to no shitou &#12300;&#24651;&#27425;&#12289;&#39746;&#12398;&#35475;&#12356;&#65281;&#30333;&#21705;&#12392;&#12398;&#27515;&#38360;&#12301;<br />
<br />
053. Ichimaru Gin's Temptation, Resolution of Destruction<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ichimaru Gin no yuuwake, kuzusareta kakugo &#12300;&#24066;&#20024;&#12462;&#12531;&#12398;&#35480;&#24785;&#12289;&#23849;&#12373;&#12428;&#12383;&#35226;&#24735;&#12301;<br />
<br />
054. An Accomplished Oath! Get back Rukia!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hatasareru chikai! Rukia dakkan naruka! &#12300;&#26524;&#12383;&#12373;&#12428;&#12427;&#35475;&#12356;&#65281;&#12523;&#12461;&#12450;&#22890;&#36996;&#12394;&#12427;&#12363;&#65281;&#12301;<br />
<br />
055. The Strongest Shinigami! Ultimate confrontation between teacher and student<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Saikyou no shinigami! Kyuukyoku no shitei taiketsu &#12300;&#26368;&#24375;&#12398;&#27515;&#31070;&#65281;&#31350;&#26997;&#12398;&#24107;&#24351;&#23550;&#27770;&#12301;<br />
<br />
056. Supersonic Battle! Determine the Goddess of Chilvary<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chousoku no tatakai! Bu no megami, kessu &#12300;&#36229;&#36895;&#12398;&#25126;&#12356;&#65281;&#27494;&#12398;&#22899;&#31070;&#12289;&#27770;&#12377;&#12301;<br />
<br />
057. One thousand cherrry blossoms, crushed! Zangetsu thrusts through the sky<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Senbonzakura, funsai! Ten wo tsuku zangetsu &#12300;&#21315;&#26412;&#26716;&#12289;&#31881;&#30741;&#65281;&#22825;&#12434;&#34909;&#12367;&#26028;&#26376;&#12301;<br />
<br />
058. Unseal! The Black Blade, the Miraculous Power<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kaigai! Kuroki yaiba, kiseki no chikara &#12300;&#38283;&#25918;&#65281;&#40658;&#12365;&#20995;&#12289;&#22855;&#36321;&#12398;&#21147;&#12301;<br />
<br />
059. Conclusion of the Death Match! White pride and black desire<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shitou kecchaku! Shiroki hokori to kuroki omoi &#12300;&#27515;&#38360;&#27770;&#30528;&#65281;&#30333;&#12365;&#35463;&#12426;&#12392;&#40658;&#12365;&#24819;&#12356;&#12301;<br />
<br />
060. Reality of the Despair, the Assassin's Dagger is Swung<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zetsubou no Shinjitsu, Furiorosareta Kyoujin &#12300;&#32118;&#26395;&#12398;&#30495;&#23455;&#12289;&#25391;&#12426;&#19979;&#12429;&#12373;&#12428;&#12383;&#20982;&#20995;&#12301;<br />
<br />
061. Aizen Stands! Horrible Ambitions<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Aizen, Tatsu! Okorubeki Yabou &#12300;&#34253;&#26579;&#12289;&#31435;&#12388;&#65281;&#24656;&#12427;&#12409;&#12365;&#37326;&#26395;&#12301;<br />
<br />
062. Gather Together! Group of the Strongest Shinigami!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shuuketsuseyo! Saikyou no Shinigami Shuudan &#12300;&#38598;&#32080;&#12379;&#12424;&#65281;&#26368;&#24375;&#12398;&#27515;&#31070;&#38598;&#22243;&#12301;<br />
<br />
063. Rukia's Decision, Ichigo's Feelings<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rukia no ketsui, Ichigo no omoi &#12300;&#12523;&#12461;&#12450;&#12398;&#27770;&#24847;&#12289;&#19968;&#35703;&#12398;&#24819;&#12356;&#12301;<br />
<br />
064. New School Term, Renji has come to the Material world?!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shingakki, Renji ni koi tsuga yatte kita !? &#12300;&#26032;&#23398;&#26399;&#12289;&#29694;&#19990;&#12395;&#24651;&#27425;&#12364;&#12420;&#12387;&#12390;&#26469;&#12383;&#65281;&#65311;&#12301;<br />
<br />
065. Creeping Terror, the Second Victim<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinobi yoru kyoufu, 2 banme no giseisha &#12300;&#24525;&#12403;&#23492;&#12427;&#24656;&#24598;&#12289;&#65298;&#30058;&#30446;&#12398;&#29344;&#29298;&#32773;&#12301;<br />
<br />
066. Break Through! The Trap Hidden in the Labyrinth<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Toppa seyo! Meikyuu ni hisomu wana &#12300;&#31361;&#30772;&#12379;&#12424;&#65281;&#36855;&#23470;&#12395;&#28508;&#12416;&#32608;&#12301;<br />
<br />
067. Game of Death! The Classmate Disappearance<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shi no GEEMU! Kieru KURASUMEITO &#12300;&#27515;&#12398;&#12466;&#12540;&#12512;&#65281;&#28040;&#12360;&#12427;&#12463;&#12521;&#12473;&#12513;&#12452;&#12488;&#32;&#12301;<br />
<br />
068. The Demon's True Form, The Secret Revealed<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Akuma no shotai, akasareta himitsu &#12300;&#24746;&#39764;&#12398;&#27491;&#20307;&#12289;&#26126;&#12363;&#12373;&#12428;&#12383;&#31192;&#23494;&#12301;<br />
<br />
069. BOUNT! The Ones Who Protect Souls<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BAUNTO! Tamashii wo kariru monotachi &#12300;&#12496;&#12454;&#12531;&#12488;&#65281;&#39746;&#12434;&#29417;&#12427;&#32773;&#12383;&#12385;&#12301;<br />
<br />
070. Rukia's Return! Revival of the Team Acting as Agents!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rukia no kikan! Daikou CHIIMU fukukatsu &#12300;&#12523;&#12461;&#12450;&#12398;&#24112;&#36996;&#65281;&#20195;&#34892;&#12481;&#12540;&#12512;&#24489;&#27963;&#12301;<br />
<br />
071. The Moment of Collision!! An Evil Hand Draws Near to the Quincy<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gekitotsu no toki! Kuinshii ni semaru ma no te &#12300;&#28608;&#31361;&#12398;&#26178;&#65281;&#12463;&#12452;&#12531;&#12471;&#12540;&#12395;&#36843;&#12427;&#39764;&#12398;&#25163;&#12301;<br />
<br />
072. Water assult! Escape from the closed hospital<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mizu no kougeki! Tozasa re ta byouin kara no dasshutsu  &#12300;&#27700;&#12398;&#25915;&#25731;&#65281;&#38281;&#12374;&#12373;&#12428;&#12383;&#30149;&#38498;&#12363;&#12425;&#12398;&#33073;&#20986;&#12301;<br />
<br />
073. Gathering at the Place of Fortune! The Man who makes his Move<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Baunto shuuketsu! Ugokidasu otoko &#12300;&#22580;&#36939;&#12392;&#38598;&#32080;&#65281;&#21205;&#12365;&#20986;&#12377;&#30007;&#12301;<br />
<br />
074. Memories of an Eternally Living Clan<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Eien wo ikiru ichizoku no kioku &#12300;&#27704;&#36960;&#12434;&#29983;&#12365;&#12427;&#19968;&#26063;&#12398;&#35352;&#25014;&#12301;<br />
<br />
075. Earth-Shattering Event at 11th Squad! The Shinigami who Rises Again<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jouuichiban tai gekishin! Yomigaetta shinigami &#12300;&#21313;&#19968;&#30058;&#38538;&#28608;&#38663;&#65281;&#12424;&#12415;&#12364;&#12360;&#12387;&#12383;&#27515;&#31070;&#12301;<br />
<br />
076. Crashing force! Frido vs Zangetsu<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chikara no gekitotsu! Furido vs Zangetsu &#12300;&#21147;&#12398;&#28608;&#31361;&#65281;&#12501;&#12522;&#12540;&#12489;&#86;&#83;&#26028;&#26376;&#12301;<br />
<br />
077. Unquellable Hatred! The Shinigami that Kenpachi Cut Down<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kie nu onnen! Kenpachi ga kitta shinigami &#12300;&#28040;&#12360;&#12396;&#24616;&#24565;&#65281;&#21091;&#20843;&#12364;&#26028;&#12387;&#12383;&#27515;&#31070;&#12301;<br />
<br />
078. The Gotei 13, Shocked!! Truth Buried by History<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gotei juusan tai kyougaku!! Rekishi ni uzumore ta shinjitsu &#12300;&#35703;&#24311;&#21313;&#19977;&#38538;&#39514;&#24853;&#33;&#33;&#27508;&#21490;&#12395;&#22475;&#12418;&#12428;&#12383;&#30495;&#23455;&#12301;<br />
<br />
079. Yoshino, and the Decision of Death<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yoshino, shi o kake ta omoi &#12300;&#33459;&#37326;&#12289;&#27515;&#12434;&#12363;&#12369;&#12383;&#24819;&#12356;&#12301;<br />
<br />
080. Assault by a Formidable Friend! A Tiny Last Self-Defense Line?!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kyouteki no kyuushuu! Chiisana saishuu bouei sen!? &#12300;&#24375;&#25973;&#12398;&#24613;&#35186;&#65281;&#23567;&#12373;&#12394;&#26368;&#32066;&#38450;&#34907;&#32218;&#33;&#63;&#12301;<br />
<br />
081. Hitsugaya moves! The Attack on the Street<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hitsugaya ugoku! Osowa re ta machi &#12300;&#26085;&#30058;&#35895;&#21205;&#12367;&#65281;&#35186;&#12431;&#12428;&#12383;&#12301;<br />
<br />
082. Ichigo vs. Daruku! The Arrival of the Faded Darkness<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ichigo VS Daruku! Shiroki yami no shutsugen &#12300;&#19968;&#35703;&#86;&#83;&#12480;&#12523;&#12463;&#65281;&#30333;&#12365;&#38343;&#12398;&#20986;&#29694;&#12301;<br />
<br />
083. Grey Shadow, the Secret of the Doll<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Haiiro no kage, DOORU no himitsu &#12300;&#28784;&#33394;&#12398;&#24433;&#12289;&#12489;&#12540;&#12523;&#12398;&#31192;&#23494;&#12301;<br />
<br />
084. Division of the Substitute Team? The Betrayal of Rukia<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Daikou CHIIMU bunretsu? Uragitta Rukia &#12300;&#20195;&#34892;&#12481;&#12540;&#12512;&#20998;&#35010;&#65311;&#35023;&#20999;&#12387;&#12383;&#12523;&#12461;&#12450;&#12301;<br />
<br />
085. Death Match of Tears! Rukia vs. Orihime<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Namida no shitou! Rukia vs Orihime &#12300;&#28057;&#12398;&#27515;&#38360;&#65281;&#12523;&#12461;&#12450;vs&#32340;&#23019;&#12301;<br />
<br />
086. Rangiku dances! Cut down the invisible enemy<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rangiku mau! Mie nai teki o kire &#12300;&#20081;&#33738;&#33310;&#12358;&#65281;&#35211;&#12360;&#12394;&#12356;&#25973;&#12434;&#26028;&#12428;&#12301;<br />
<br />
087. Byakuya Assembles! The Gotei 13 Mobilizes<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Byakuya shoushuu! Ugokidasu Gotei juusan tai &#12300;&#30333;&#21705;&#21484;&#38598;&#65281;&#21205;&#12365;&#20986;&#12377;&#35703;&#24311;&#21313;&#19977;&#38538;&#12301;<br />
<br />
088. Annihilation of the Vice-Captains!? Trap in the Underground Cave<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fuku taichou zenmetsu!? Chikadoukutsu no wana &#12300;&#21103;&#38538;&#38263;&#20840;&#28357;&#33;&#63;&#22320;&#19979;&#27934;&#31391;&#12398;&#32608;&#12301;<br />
<br />
089. Rematch?! Ishida vs. Nemu<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Saisen!? Ishida VS Nemu &#12300;&#20877;&#25126;&#33;&#63;&#32;&#30707;&#30000;&#32;&#86;&#83;&#32;&#12493;&#12512;&#12301;<br />
<br />
090. Abarai Renji, Bankai of the Soul!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Abarai Renji, tamashii no bankai! &#12300;&#38463;&#25955;&#20117;&#24651;&#27425;&#12289;&#39746;&#12398;&#21325;&#35299;&#65281;&#12301;<br />
<br />
091. Shinigami and Quincy, the Resurrected Strength<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinigami to Kuinshii, Yomigaeru Chikara &#12300;&#27515;&#31070;&#12392;&#12463;&#12452;&#12531;&#12471;&#12540;&#12289;&#12424;&#12415;&#12364;&#12360;&#12427;&#21147;&#12301;<br />
<br />
092. Invasion of the Shinigami World, again<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shinigami Sekai heno Totsunyuu, Futatabi &#12300;&#27515;&#31070;&#19990;&#30028;&#12408;&#12398;&#31361;&#20837;&#12289;&#20877;&#12403;&#12301;<br />
<br />
093. The Bount Assault! The Gotei 13 Falls Into Turmoil<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bounto Kyoushuu! Gekishin no Gotei Juusan tai &#12300;&#12496;&#12454;&#12531;&#12488;&#24375;&#35186;&#65281;&#28608;&#38663;&#12398;&#35703;&#24311;&#21313;&#19977;&#38538;&#12301;<br />
<br />
094. Hitsugaya's Decision! The Clash Approaches<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hitsugaya no Ketsui! Gekitotsu no Tokisemaru &#12300;&#26085;&#30058;&#35895;&#12398;&#27770;&#24847;&#65281;&#28608;&#31361;&#12398;&#26178;&#36843;&#12427;&#12301;<br />
<br />
095. Byakuya Moves to the Front! Dance of the Wind Tearing Cherry Blossoms<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Byakuya Shutsujin! Kaze wo Saku Sakura no Mai &#12300;&#30333;&#21705;&#20986;&#38499;&#65281;&#39080;&#12434;&#35010;&#12367;&#26716;&#12398;&#33310;&#12301;<br />
<br />
096. Ichigo, Byakuya, Kariya, Battle of the Three Extremes!<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ichigo&bull;Byakuya&bull;Kariya, Sankyoku no Tatakai! &#12300;&#19968;&#35703;&#12539;&#30333;&#21705;&#12539;&#29417;&#30690;&#65380; &#19977;&#26997;&#12398;&#25126;&#12356;!&#12301;<br />
<br />
097. Hitsugaya Retaliates! Cut the Enemy in the Forest<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hitsugaya Shutsugeki! Mori no Naka no Teki wo Kire &#12300;&#26085;&#30058;&#35895;&#20986;&#25731;&#65281;&#26862;&#12398;&#20013;&#12398;&#25973;&#12434;&#26028;&#12428;&#12301;<br /></span>