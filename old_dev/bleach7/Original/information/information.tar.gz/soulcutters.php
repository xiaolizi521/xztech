<br />
<font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Weapons &gt; Soul Cutters</b><br />
<br />
</font><font face="Verdana" size="2"><b>Soul Cutters</b></font><font face="Verdana" size="1"><br />
<br />
<b>Soul Cutters</b> - Soul Cutters are the swords of the shinigami. They are used to cleanse or destroy hollows. soul cutters have three forms: normal, initial (name) release, and ban release. Lower level to some middle class shinigami do not know the names of their soul cutters and therefore cannot release them. To release a soul cutter you must shout its name. You can only learn the swords name by talking to it and trusting it.<br />
<br />
<br />
<u><b><i>List of known soul cutters and their masters:</i></b></u> [Last
Updated: 9/9/04]<br />
<br />
<i>Kurosaki Ichigo - Kitsuki (Zangetsu)</i><br />
&nbsp;Ichigo's soul cutter Kitsuki is always on name release and never transforms back to normal mode.<br />
<br />
- - - - -<br />
<br />
<i>Urahara Kisuke - Kurenaihime</i><br />
&nbsp;Can form a shield and has an explosion attack.<br />
<br />
- - - - -<br />
<br />
<i>Ichimaru Gin - Shinsou</i><br />
&nbsp;Can use a "shooting" technique in which his soul cutter greatly expands in 		length thus shooting out toward his opponent.<br />
<br />
- - - - -<br />
<br />
<i>Ikkaku Madarame - Hoozukimaru</i><br />
&nbsp;Transforms into a spear that can break into many sections forming a sansetsukon or a 3 piece nunchuck.<br />
<br />
- - - - -<br />
<br />
<i>Yumichika - Fuzikuzyaku</i><br />
&nbsp;Can split into 3 blades. Other abilities unknown.<br />
<br />
- - - - -<br />
<br />
<i>Kamaitachi Ziroubou - Tsunzakigarasu</i><br />
&nbsp;Splits into many small airborne shuriken-like objects which attck opponents by quickly flying at them.<br />
<br />
- - - - -<br />
<br />
<i>Abari Renji - Zambimaru</i><br />
&nbsp;Splits into an endlessly segmented sword with great strength. Takes the form of a baboon with a snake as its tail.<br />
<br />
- - - - -<br />
<br />
<i>Hinamori - Tobiume</i><br />
&nbsp;Can release spheres of energy that explode on contact. Also has a close range 		explosion technique.<br />
<br />
- - - - -<br />
<br />
<i>Kiba - Wabasuke</i><br />
&nbsp;Abilities unknown.<br />
<br />
- - - - -<br />
<br />
<i>Kuchiki Byakuya - Senbonzakura</i><br />
&nbsp;Scatters into cherry blossom petals and slices the target of the attack multiple times.<br />
<br />
- - - - -<br />
<br />
<i>Kurotsuchi Mayuri - Ashisogi Jizou</i><br />
&nbsp;The technique Ashisogizisou  severs the nerves of the targets body making him or her immobile. After Ban release Mayuri can preform the Golden Ashisogizisou technique which takes the users blood and turns it into deadly poisonous fog which is spread in a 100 km radius. Everyone in this radius will be killed with the exception of the user.<br />
<br />
- - - - -</font>