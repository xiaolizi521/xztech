<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Miscellaneous</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Miscellaneous List:</b></span><span class="VerdanaSize1Main"><b> [Last Updated: 10/01/05]</b><br />
<br />
� <a href="?page=information/bountyreward">Bounty Rewards</a><br />
� <a href="?page=information/hollowbait">Hollow Bait</a></span>