<?php
if ( isset ( $_GET[xml] ) && !empty ( $_GET[xml] ) ) {
	$xml = $_GET[xml];
	switch ( $xml ) {
		case 'jp':
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach7 &gt; Information &gt; Bleach Manga Guide &gt; Japanese Chapter Titles</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Japanese Manga Chapter Titles:</b></span><span class="VerdanaSize1Main"><br />
<?php
			break;
		case 'viz':
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach7 &gt; Information &gt; Bleach Manga Guide &gt; Viz Chapter Titles</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach VIZ Manga Chapter Titles:</b></span><span class="VerdanaSize1Main"><br />
<?php
			break;
	}

	$xml .= 'chaptertitles';
}
else {
	die ('Must contain the filename of the xml file');
}



// Create a new XML Parser
if ( !( $xmlparser = xml_parser_create() ) )
{ 
   die ('Cannot create parser');
}

$current = '';
// Change starting tag information
function start_tag( $parser, $name, $attribs ) {
	global $current;
	$current = $name;
	switch ( strtolower ( $name ) ) {
		case 'volume':
				echo '<br />
';
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower ( $key ) ) {
						case 'vid':
							if ( $val < 10 ) {
								$val = '0' . $val;
							}
							echo '<b>Volume ', $val, ': ';
							break;
					}
				}
			}
			break;
		case 'chapter':
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower ( $key ) ) {
						case 'cid':
							if ( $val >= 100 ) {
								echo $val, '. ';
							}
							else if ( $val >= 10 ) {
								echo '0', $val, '. ';
							}
							else {
								echo '00', $val, '. ';
							}
							break;
						case 'exid':
							echo $val, '. ';
							break;
					}
				}
			}
			break;
	}
}

// Change ending tag information
function end_tag( $parser, $name ) {
	switch ( strtolower ( $name ) ) {
		case 'vname':
			echo '</b><br />
<br />
';
			break;
		case 'chapter':
			echo '<br />
';
			break;
	}
}

// Display the contents within the tags
function tag_contents( $parser, $data ) {
	global $current;
	switch ( strtolower ( $current ) ) {
		case 'vname':
			echo htmlentities ($data, ENT_QUOTES);
			break;
		case 'chapter':
			$data = htmlentities ($data, ENT_QUOTES);
			$data = str_replace( 'bull;', '&bull;', $data );
			echo $data;
			break;
	}
}

// Run through the tags
xml_set_element_handler( $xmlparser, 'start_tag', 'end_tag' );

// Run through the contents between the tags
xml_set_character_data_handler( $xmlparser, 'tag_contents' );

// Open XML file
$filename = 'information/xml/' . $xml . '.xml';
if ( !($fp = fopen( $filename, 'r' ) ) ) {
	die( 'Cannot open ' . $filename);
}

// Read the XML file and display any errors
while ( $data = fread( $fp, 4096 ) ) {
	$data = eregi_replace( '>'."[[:space:]]+".'<', '><', $data );
	if ( !xml_parse( $xmlparser, $data, feof( $fp ) ) ) {
		$reason = xml_error_string( xml_get_error_code( $xmlparser ) );
		$reason .= xml_get_current_line_number( $xmlparser );
		die($reason);
	}
}
xml_parser_free( $xmlparser );

if ( isset ( $user_B7 ) && $user_B7->getEdit_Info() == true ) {
	echo '<br />
<a href="?page=xmledit&amp;sec=information&amp;xml=', $xml, '">Edit this XML file.</a>';
}
echo '</span>';
?>