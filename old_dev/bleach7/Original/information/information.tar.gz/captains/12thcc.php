<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Kurotshuchi Nemu</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kurotshuchi Nemu</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/12th-cc.gif" alt="Kurotshuchi Nemu" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Kurotshuchi Nemu<br />
      Division: 12th<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      She was created by Kurotsuchi Mayuri and is totally devoted to him.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>