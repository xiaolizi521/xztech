<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Kira Izuru</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kira Izuru</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/3rd-cc.gif" alt="Kira Izuru" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Kira Izuru<br />
      Division: 3rd<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He doesn�t look as bad as his captain but if the latter is in danger, he will still protect him. His soul cutter is <i>Wabusuke</i>, to release it, he says "Lift your face".</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>