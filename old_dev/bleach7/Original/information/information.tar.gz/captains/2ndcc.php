<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Oomaeda Marechiyo</b><br />
<br />
</font><font face="Verdana" size="2"><b>Oomaeda Marechiyo</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/2nd-cc.gif" alt="Oomaeda Marechiyo" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Oomaeda Marechiyo<br />
      Division: 2nd<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He is pretty big and seems to like eating.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>