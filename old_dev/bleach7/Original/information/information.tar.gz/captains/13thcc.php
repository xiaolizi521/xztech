<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Shiba Kaien</b><br />
<br />
</font><font face="Verdana" size="2"><b>Shiba Kaien</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/13th-cc.gif" alt="Shiba Kaien" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Shiba Kaien<br />
      Division: 13th<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He's the eldest son of the Shiba family, brother of Ganju and Kuukaku. He was married to the 3<sup>rd</sup> seat of the 13<sup>th</sup> division but his wife was killed by a hollow. He wanted to avenge her so he fought the hollow alone but lost and the hollow possessed his body, Rukia had to finish him. His soul cutter is <i>Nejibama</i>, to release it, he says "Reverse swirl." We can notice that he looks a lot like Kurosaki Ichigo.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>