<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Ichimaru Gin</b><br />
<br />
</font><font face="Verdana" size="2"><b>Ichimaru Gin</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/3rd-c.gif" alt="Ichimaru Gin" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Ichimaru Gin<br />
      Division: 3rd<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He always has a smile on his face and we have never seen his eyes. His soul cutter is <i>Shinsou</i>, it looks like a knife but it seems that it can extend once released. To release it: &quot;Shoot him&quot; He looks like the bad guy but we don�t know his aims.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)<br />
</font></p>

</body>

</html>
