<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Zaraki Kenpachi</b><br />
<br />
</font><font face="Verdana" size="2"><b>Zaraki Kenpachi</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/11th-c.gif" alt="Zaraki Kenpachi" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Zaraki Kenpachi<br />
      Division: 11th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He comes from Area 80 of North Alley. Zaraki is the only captain of Gotei 13 who didn't take an entry exam to become a shinigami: he won the duel against the former 11th division captain. His hairstyle consists of spikes, with little bells at the end of each. He has no sense of direction and is always seen accompanied by his cheerful vice-captain. He lives to fight, he loves fighting to death. It�s said that you can�t cut him, his spiritual pressure is so strong that he has to wear an eye patch that sucks his energy: when he removes it, the pressure is even stronger. His soul cutter hasn�t a name and only has one form: a simple sword.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>