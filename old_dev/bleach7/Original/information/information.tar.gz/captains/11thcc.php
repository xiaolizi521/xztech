<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Kusajika Yachiru</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kusajika Yachiru</b></font><font face="Verdana" size="1"><br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/11th-cc.gif" alt="Kusajika Yachiru" width="199" height="276" /></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Kusajika Yachiru<br />
      Division: 11th<br />
      Rank: Co-Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      She is the shortest and lightest member of Gotei 13 and comes from Area 79 of North Alley, Kusajishi. She was found by Zaraki when she was still a baby, like him, she had no name so he gave her the name Yachiru. As Zaraki, she is the only vice-captain who became a shinigami without taking the entry exam. Her sword is not very long so instead of tying it to her waist, she drags it around with a rope. She may look weak but she has a scary aura when she's pissed and actually, she can carry her captain� She has the habit of calling everyone by horrible nicknames invented by her.</font></td>
  </tr>
</table>
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>