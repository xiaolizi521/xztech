<p /><font face="Verdana" size="1"><b>Bleach 7 &gt; Information &gt; Bleach Captains Guide &gt; Kuchiki Byakuya</b><br />
<br />
</font><font face="Verdana" size="2"><b>Kuchiki Byakuya</b></font><font face="Verdana" size="1"><br />
<br />
<br />
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%"><font face="Verdana" size="1"><img border="0" src="images/6th-c.gif" alt="Kuchiki Byakuya" width="199" height="276"></font></td>
    <td width="78%" valign="top"><font face="Verdana" size="1"><br />
      <br />
      Name: Kuchiki Byakuya<br />
      Division: 6th<br />
      Rank: Captain<br />
      Special Rank: None<br />
      <br />
      Short Info:<br />
      He�s from the noble family Kuchiki, the Kenseikaan on his head is the proof of it: it�s a head-dress only nobles can wear. His powerful soul cutter is <i>Senbonzakura</i>, and to release it, he says "Scatter". The first form of his soul cutter consists of thousand invisible blades. Its second form, the <b>Ban Kai</b>, is called <i>Senbonzakura Kageyoshi</i>, it is very impressive, more than thousand of blades are lined up, it�s impossible to dodge and it cuts the opponent into pieces. He can move very fast using <b>Shyunpo</b>, his favorite Shyunpo attack is <i>Senka</i>, where he moves to the enemy�s back and kill him in one blow. Byakuya Kuchiki doesn�t talk a lot and seems pretty arrogant, it's said that he�s the strongest master in the Kuchiki history; however, the Kuchiki family is still unknown. The only other member we know is Rukia, his little sister by adoption. The other woman in his life is the mysterious Hisana who appeared only once in a picture, it seems that she's dead but she looks like Rukia a lot.</font></td>
  </tr>
</table>
<br />
<br />
*Note: These are not detailed biographies. Just a short guide to help you<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; learn the different captains and co-captains.<br />
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -<br />
<br />
(*All pictures courtesy of '<a href="http://www.livejournal.com/users/kurosaki_kon/">kurosaki_kon</a>' of Soul_Society LJ)</font>