<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Spell Guide &gt; Jigoku Chos</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Jigoku Chos (Butterflies From Hell)</b></span><span class="VerdanaSize1Main"><br />
<br />
Quite Simply; captures and kills the designated target/person.<br /></span>