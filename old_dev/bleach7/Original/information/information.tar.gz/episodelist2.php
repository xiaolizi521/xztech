<b>Bleach 7 &gt; Information &gt; Bleach Anime Guide &gt; Episode List</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach TV Episode List</b></span><span class="VerdanaSize1Main"><br />
<br />
<?php
$EpisodeList_sql = mysql_query ( "SELECT `id`, `Title`, `Romanji`, `Kanji` FROM `anime_info` ORDER BY `id` ASC" );

while ( $show_EpisodeList = mysql_fetch_array ( $EpisodeList_sql ) ) {
	if ( $show_EpisodeList['id'] >= 100 ) {
		$id = $show_EpisodeList['id'];
	}
	elseif ( $show_EpisodeList['id'] >= 10 ) {
		$id = "0".$show_EpisodeList['id'];
	}
	else {
		$id = "00".$show_EpisodeList['id'];
	}
	
	echo "$id. $show_EpisodeList['Title']<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$show_EpisodeList['Romanji'] $show_EpisodeList['Kanji']<br />
<br />
";
}
if ( $user_info['type'] == 20 || $user_info['type'] == 21 || $user_info['type'] >= 80 ) {
?>
<br />
<fieldset>
<legend class="main">Japanese Chapter Title Edit Section</legend>
	<form name="EpisodeList" method="post" action="?page=information/info">
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
			  <td style="width: 33%;"><label><input name="JPChapter_edit" type="radio" tabindex="1" value="add" checked />Add</label></td>
				<td style="width: 33%;"><label><input name="JPChapter_edit" type="radio" tabindex="2" value="" value\="edit" />Edit</label></td>
			  <td style="width: 34%;"><label><input name="JPChapter_edit" type="radio" tabindex="3" value="delete" />Delete</label></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td style="width: 23%">Episode Number</td> 
				<td style="width: 10%"><input name="id" type="text" style="width: 30px;" tabindex="4" maxlength="3" /></td>
				<td style="width: 17%">Title</td>
				<td style="width: 50%"><input name="Title" type="text" style="width: 95%;" tabindex="5" /></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td style="width: 25%">Romanji</td>
				<td style="width: 75%"><input name="Romanji" type="text" style="width: 95%;" tabindex="6" /></td>
			</tr>
			<tr>
				<td style="width: 25%">Kanji</td>
				<td style="width: 75%"><input name="Kanji" type="text" style="width: 95%;" tabindex="7" lang="ja" /></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td style="width: 25%">TokyoTV Date</td>
				<td style="width: 75%"><input name="JPDate" type="text" style="width: 95%;" tabindex="8" value="0000-00-00" maxlength="10" /></td>
			</tr>
			<tr>
				<td style="width: 25%">Cartoon Network Date</td>
				<td style="width: 75%"><input name="CNDate" type="text" style="width: 95%;" tabindex="9" value="0000-00-00" maxlength="10" /></td>
			</tr>
		</table>
		<table cellpadding="0" cellspacing="0" style="border: none; width: 100%;">
			<tr>
				<td align="center"><input name="EpisodeList_submit" type="submit" class="form" tabindex="10" value="Submit Changes" /></td>
			</tr>
		</table>
	</form>
</fieldset>
<?php
}
?>