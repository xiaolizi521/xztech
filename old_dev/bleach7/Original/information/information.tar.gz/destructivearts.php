<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Spell Guide &gt; Destructive Arts</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Destructive Arts</b></span><span class="VerdanaSize1Main"><br />
<br />
Destructive Arts are to Quincy, as Demon Arts are to Shinigami, the difference being that Destructive Arts are as they say, they destroy the hollows/targets.&nbsp;<br />
<br />
<span class="artstitle">Known Destructive Arts:</span><br />
Destructive Art #4 - A spell that uses spiritons to form an arrow shot out, for the bow of a Quincy.<br />
<br />
<span class="artstitle">Uses:</span><br />
(Ishida, Uryuu) uses it quite often whenever he uses his bow.</span>