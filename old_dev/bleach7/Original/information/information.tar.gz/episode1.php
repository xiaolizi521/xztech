<?php
/*if ( isset ( $_GET[xml] ) && !empty ( $_GET[xml] ) ) {
	$xml = $_GET[xml];
}
else {
	die ("Must contain the filename of the xml file");
}*/

$kanji_array = array ();
$romanji_array = array ();
$current = "";
$episode_id = "";

// Change starting tag information
function start_title ( $parser, $name, $attribs ) {
	global $current;
	global $episode_id;
	$current = $name;
	switch ( strtolower ( $name ) ) {
		case "episode":
			if ( is_array( $attribs ) ) {
				while ( list( $key, $val ) = each( $attribs ) ) {
					switch ( strtolower( $key ) ) {
						case "id":
							if ( $val < 10 ) {
								$val = "00$val";
							}
							else if ( $val < 100 ) {
								$val = "0$val";
							}
							$episode_id = $val;
							break;
					}
				}
			}
			break;
		case "jptitle":
			echo "$episode_id. ";
			break;
		case "romanji":
			echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
			break;
		case "kanji":
			echo "&#12300;";
			break;
	}
}

// Change ending tag information
function end_title ( $parser, $name ) {
	switch ( strtolower ( $name ) ) {
		case "jptitle":
			echo "<br />
";
			break;
		case "romanji":
			echo " ";
			break;
		case "kanji";
			echo "&#12301;<br />
<br />
";
			break;
	}
}

// Display the contents within the tags
function tag_title ( $parser, $data ) {
	global $current;
			$data = htmlentities ( $data, ENT_QUOTES );
	switch ( strtolower ( $current ) ) {
		case "jptitle":
			echo "$data";
			break;
		case "romanji":
		case "kanji":
			echo "$data";
			break;
	}
}	


function load_data( $file ) {
   $f = fopen ($file, 'r');
   $data = fread ( $f, filesize( $file ) );
   return $data;
} 


// Create a new XML Parser
//$xmlparser = xml_parser_create ( "ISO-8859-1" );

// Run through the tags
//xml_set_element_handler ( $xmlparser, "start_title", "end_title" );

// Run through the contents between the tags
//xml_set_character_data_handler ( $xmlparser, "tag_title" );

// Open XML file
$file = "./xml/episode.xml";

$data = load_data ( $file );
$kanji_array = split ( "<kanji>&#[0-9]</kanji>", $data );
echo "$kanji_array[0]";
//echo "$data";
//xml_parse ( $xmlparser, $data );

// Read the XML file and display any errors
/*while ( $data = fread ( $fp, 4096 ) ) {
	$data = eregi_replace ( ">"."[[:space:]]+"."<", "><", $data );
	if ( !xml_parse ( $xmlparser, $data, feof( $fp ) ) ) {
		$reason = xml_error_string ( xml_get_error_code( $xmlparser ) );
		$reason .= xml_get_current_line_number ( $xmlparser );
		die ( $reason );
	}
}*/

//xml_parser_free( $xmlparser );
?>
