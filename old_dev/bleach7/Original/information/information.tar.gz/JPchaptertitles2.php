<?php
if ( isset ( $_GET[xml] ) && !empty ( $_GET[xml] ) ) {
	$xml = $_GET[xml];
	switch ( $xml ) {
		case "JP":
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach7 &gt; Information &gt; Bleach Manga Guide &gt; Japanese Chapter Titles</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Japanese Manga Chapter Titles:</b></span><span class="VerdanaSize1Main"><br />
<?php
			break;
		case "VIZ":
?>
<br />
<span class="VerdanaSize1Main"><b>Bleach7 &gt; Information &gt; Bleach Manga Guide &gt; Viz Chapter Titles</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach VIZ Manga Chapter Titles:</b></span><span class="VerdanaSize1Main"><br />
<?php
			break;
	}

	$xml .= "chaptertitles";
}
else {
	die ("Must contain the filename of the xml file");
}



// Create a new XML Parser
if ( !( $xmlparser = xml_parser_create() ) )
{ 
   die ("Cannot create parser");
}

$current = "";
// Change starting tag information
function start_tag( $parser, $name, $attribs ) {
	global $current;
	$current = $name;
	switch ( $name ) {
		case "VOLUME":
			if ( is_array( $attribs ) ) {
				echo "<br />
";
				while ( list( $vid, $val ) = each( $attribs ) ) {
					if ( $val >= 10 ) {
						echo "<b>Volume $val: ";
					}
					else {
						echo "<b>Volume 0$val: ";
					}
				}
			}
			break;
		case "CHAPTER":
			if ( is_array( $attribs ) ) {
				while ( list( $cid, $val ) = each( $attribs ) ) {
					$val = str_replace( "107.5", "0.8", $val );
					if ( $val >= 100 ) {
						echo "$val. ";
					}
					else if ( $val >= 10 ) {
						echo "0$val. ";
					}
					else if ( $val == "0.8" ) {
						echo "$val. ";
					}
					else {
						echo "00$val. ";
					}
				}
			}
			break;
	}
}

// Change ending tag information
function end_tag( $parser, $name ) {
	switch ( $name ) {
		case "VNAME":
			echo "</b><br />
<br />
";
			break;
		case "CHAPTER":
			echo "<br />
";
			break;
	}
}

// Display the contents within the tags
function tag_contents( $parser, $data ) {
	global $current;
	switch ( $current ) {
		case "VNAME":
			echo "".htmlentities ($data, ENT_QUOTES)."";
			break;
		case "CHAPTER":
			$data = htmlentities ($data, ENT_QUOTES);
			$data = str_replace( "#8226;", "&bull;", $data );
			echo "$data";
			break;
	}
}

// Run through the tags
xml_set_element_handler( $xmlparser, "start_tag", "end_tag" );

// Run through the contents between the tags
xml_set_character_data_handler( $xmlparser, "tag_contents" );

// Open XML file
$filename = "information/xml/$xml.xml";
if ( !($fp = fopen( $filename, "r" ) ) ) {
	die("cannot open ".$filename);
}

// Read the XML file and display any errors
while ( $data = fread( $fp, 4096 ) ) {
	$data = eregi_replace( ">"."[[:space:]]+"."<", "><", $data );
	if ( !xml_parse( $xmlparser, $data, feof( $fp ) ) ) {
		$reason = xml_error_string( xml_get_error_code( $xmlparser ) );
		$reason .= xml_get_current_line_number( $xmlparser );
		die($reason);
	}
}
xml_parser_free( $xmlparser );

echo "</span>";
?>