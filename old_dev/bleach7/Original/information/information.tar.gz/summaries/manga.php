<br />
<span class="VerdanaSize1Main"><b>Bleach 7 &gt; Information &gt; Bleach Manga Guide &gt; Manga Summaries</b><br />
<br />
</span><span class="VerdanaSize2Main"><b>Bleach Manga Summaries:</b> </span><span class="VerdanaSize1Main"><b>[Last Updated: 10/18/04]</b><br />
<br />
<b>Volume #1 - Complete</b><br />
<a href="index.php?page=information/summaries/m001">Chapter 001 - Death &amp; Strawberry</a><br />
<a href="index.php?page=information/summaries/m002">Chapter 002 - Starter</a><br />
<a href="index.php?page=information/summaries/m003">Chapter 003 - Headhittin'</a><br />
<a href="index.php?page=information/summaries/m004">Chapter 004 - Why do you eat it?</a><br />
<a href="index.php?page=information/summaries/m005">Chapter 005 - Binda Blinda</a><br />
<a href="index.php?page=information/summaries/m006">Chapter 006 - Microcrack</a><br />
<a href="index.php?page=information/summaries/m007">Chapter 007 - The Pink Cheeked Parakeet<br />
<br />
</a><b>Volume #2 - In Progress</b><br />
<a href="index.php?page=information/summaries/m008">Chapter 008 - Chase Chad Around</a><br />
<a href="index.php?page=information/summaries/m009">Chapter 009 - Monster and a Transfer [Struck Down]</a></span>