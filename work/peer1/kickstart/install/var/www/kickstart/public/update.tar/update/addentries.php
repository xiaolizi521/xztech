<?php
	$conn = pg_connect("host=127.0.0.1 dbname=kickstart user=kickstart password=l33tNix");
			$id = $_POST['id'];
         $prn = $_POST['private_network'];
         $pub = $_POST['public_network'];

	$add = "INSERT INTO vlans VALUES ( '$id' , '$pub' , '$prn' )";
		
		
	if (($id == "") || ($prn == "") || ($pub == "")) {
		die("Please enter in all fields! Hit the back button.");
		}
	else {
		pg_query($conn, $add);
		}
		header( 'Location: added.html' ) ;
?>


